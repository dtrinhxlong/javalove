import java.util.List;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import vn.com.paysmart.common.uis.utils.GsonUtil;
import vn.com.paysmart.uis.mafc.entity.ContractList;

public class TestJSON {

	public static void main(String[] args) {
		try {
		Gson gson = new Gson();
		String decodeData = "{\"result\":[{\"v_agreeid\":\"1002463\",\"v_custname\":\"PHẠM THỊ BÍCH HẠNH\",\"v_net_receivable\":0.0000,\"v_instlamt\":1919538.0000,\"v_duedate\":\"2020-07-10T00:00:00\"}]}";
        ContractList contractList = gson.fromJson(decodeData, ContractList.class);
        System.out.println(gson.toJson(contractList.getResult().get(0)));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
