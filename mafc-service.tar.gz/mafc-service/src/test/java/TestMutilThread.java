import vn.com.paysmart.common.queue.producer.QueueProducer;
import vn.com.paysmart.common.uis.common.LogUtil;
import vn.com.paysmart.uis.mafc.utils.StaticConfig;

public class TestMutilThread {

	public static void main(String[] args) {
		try {
			LogUtil.init();
			StaticConfig.initClassLoader();

			String dataQueue = "{\"data\":\"eyJBZ3JlZUlkIjoiMTAwMjQ2MyIsIkN1c3ROYW1lIjoiUEjhuqBNIFRI4buKIELDjUNIIEjhuqBOSCIsIk5ldFJlY2VpdmFibGUiOjAsIkluc3RsQW10IjoxOTE5NTM4LCJEdWVEYXRlIjoiMjAyMC0wNy0xMFQwMDowMDowMCIsIlN0YXR1cyI6IkRFTElWRVIiLCJXYWxsZXRJZCI6IjgyIiwiQ3VzdG9tZXJQaG9uZSI6IjA5ODgzMDMwMzUiLCJUcmFuc0lkIjoiMTIzNDU2Nzg5IiwiVHJhbnNBbW91bnQiOjUwMDAwLCJUcmFuc1RpbWUiOjE1MzQ1Njc3LCJSZXF1ZXN0SWQiOiIxNTk2NzAzMDc2IiwiUGhvbmVObyI6IjA5ODgzMDMwMzUiLCJQYXJ0bmVyQ29kZSI6Ik1BRkMiLCJNaW5BbW91bnQiOjMwMDAwLCJDYXNoQmFjayI6ZmFsc2UsIlJybiI6IjEyMzQ1In0=\",\"signature\":\"5df5f62ad403829b9db2df045f39c0218cc204bb2d0aa7bd08185d519964adae\"}";

			for (int i = 0; i < 20; i++) {
				QueueProducer producer = new QueueProducer(StaticConfig.RABBIT_MQ_INSTANCE_NAME,
						"MAFC_REPAYMENT_DELIVER");
				producer.sendMessage(dataQueue);
			}
			System.out.println("Done.");
			System.exit(1);
		} catch (Exception e) {
			e.printStackTrace(System.out);
		}

	}

}
