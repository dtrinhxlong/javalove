package vn.com.paysmart.uis.mafc.stream;

import org.apache.commons.lang3.StringUtils;
import vn.com.paysmart.common.queue.producer.QueueProducer;
import vn.com.paysmart.common.redis.JedisSentinelClient;
import vn.com.paysmart.common.uis.common.Config;
import vn.com.paysmart.common.uis.entity.Response;
import vn.com.paysmart.common.uis.json.JsonObject;
import vn.com.paysmart.common.uis.profiler.ProfilerLog;
import vn.com.paysmart.common.uis.utils.CryptoUtil;
import vn.com.paysmart.common.uis.utils.GsonUtil;
import vn.com.paysmart.uis.mafc.client.thread.log.oData;
import vn.com.paysmart.uis.mafc.constant.ConfigName;
import vn.com.paysmart.uis.mafc.constant.FieldName;
import vn.com.paysmart.uis.mafc.entity.ContractInfo;
import vn.com.paysmart.uis.mafc.entity.ContractList;
import vn.com.paysmart.uis.mafc.entity.OperationName;
import vn.com.paysmart.uis.mafc.entity.ResponseCode;
import vn.com.paysmart.uis.mafc.utils.CommonUtil;
import vn.com.paysmart.uis.mafc.utils.StaticConfig;

public class PayBillMAFC {
    private static final String JEDIS_SERVER = "jedis_server";
    
    public static Response streamACT(JedisSentinelClient jedisClient, JsonObject data, String requestId, ProfilerLog profilerLog) throws Exception {
        String dataQueue = null;
        String REDIS_PREFIX = Config.getParam(JEDIS_SERVER, "prefix") + "." + data.getString(FieldName.WALLETID) + ".";

        String cacheContractInfo = (String) jedisClient
                .get(REDIS_PREFIX + StaticConfig.PARTNER_CODE + "." + data.getString(FieldName.AC_NO));
        ContractInfo contractInfo = GsonUtil.fromJson(cacheContractInfo, ContractInfo.class);
        long ttl = Config.getLongParam("config-data", "contract_info_expired");

        if (contractInfo == null) {
            JsonObject again = new JsonObject();
            again.addProperty(FieldName.AGN_ID, data.getString(FieldName.AC_NO));
            again.addProperty(FieldName.WALLETID, data.getString(FieldName.WALLETID));
            again.addProperty(FieldName.PHONE_NO, data.getString(FieldName.PHONE_NO));

            // query again
            String resp2 = CommonUtil.getResponse(StaticConfig.MAFC_CONNECTOR_URL + "/" + OperationName.COLLECTION_MAFC,
                    CommonUtil.genBase64(again.toString()), requestId, profilerLog);

            if (StringUtils.isEmpty(resp2)) {
                return new Response(ResponseCode.FAIL.name()).setMessage("not response connector");
            }

            String REDIS_PREFIX_TRANS = Config.getParam(JEDIS_SERVER, "prefix-trans") + "."
                    + data.getString(FieldName.WALLETID) + ".";
            String keyRedisTrans = REDIS_PREFIX_TRANS + StaticConfig.PARTNER_CODE + "."
                    + data.getString(FieldName.AC_NO);

            String respData = JsonObject.parse(resp2).getString(FieldName.DATA);
            String code = JsonObject.parse(respData).getString(FieldName.CODE);
            if (!code.equals(ResponseCode.SUCCESS.name())) {
            	StaticConfig.LOGMANAGER.submit(new oData("cache_expired_query", JsonObject.parse(respData).toString()));
                return new Response(ResponseCode.FAIL.name())
                        .setMessage(JsonObject.parse(respData).getString(FieldName.MESSAGE));
            }

            String decodeData = CommonUtil.decodeBase64(JsonObject.parse(respData).getString(FieldName.DATA));
            ContractList contractList = GsonUtil.fromJson(decodeData, ContractList.class);
            if (contractList.getResult().isEmpty()) {
                return new Response(ResponseCode.FAIL.name()).setMessage(JsonObject.parse(resp2).getString(FieldName.MESSAGE));
            }
            contractInfo = contractList.getResult().get(0);

            String sData = GsonUtil.toJsonString(contractInfo);
            jedisClient.set(keyRedisTrans, sData, ttl * 60 * 24);
        }

        contractInfo.setRequestId(requestId);
        contractInfo.setWalletId(data.getString(FieldName.WALLETID));
        contractInfo.setCustomerPhone(data.getString(FieldName.CUSTOMER_PHONE));
        contractInfo.setPhoneNo(data.getString(FieldName.PHONE_NO));
        contractInfo.setTransId(data.getString(FieldName.TRAN_ID));
        contractInfo.setTransAmount(data.getInt(FieldName.TRANS_AMOUNT));
        String tt = data.getString(FieldName.TRANS_TIME);
        contractInfo.setTransTime(Long.parseLong(tt));
        contractInfo.setPartnerCode(StaticConfig.PARTNER_CODE);
        contractInfo.setMinAmount(Config.getIntParam("messages", ConfigName.MINTAMOUNT));
        contractInfo.setStatus("DELIVER");
        contractInfo.setRrn(data.getString(FieldName.RRN));

        dataQueue = GsonUtil.toJsonString(contractInfo);

        if (!StringUtils.isEmpty(dataQueue)) {
        	StaticConfig.LOGMANAGER.submit(new oData("push_deliver", dataQueue));
            String reminderQueue = StaticConfig.RABBIT_MQ_QUEUENAME_DELIVER;

            // encrypt data
            String dataEncrypt = CommonUtil.genBase64(dataQueue);
            String secretKey = Config.getParam("rabbitmq", "secret-key");
            String signature = CryptoUtil.sha256(dataEncrypt + "|" + secretKey);

            Response queueMsg = new Response().setData(dataEncrypt).setSignature(signature);
            dataQueue = GsonUtil.toJsonString(queueMsg);

            // push to queue
            QueueProducer producer = new QueueProducer(StaticConfig.RABBIT_MQ_INSTANCE_NAME, reminderQueue);
            producer.sendMessage(dataQueue);

            return new Response(ResponseCode.SUCCESS.name()).setMessage("ASYNC payment");
        } else {
        	StaticConfig.LOGMANAGER.submit(new oData("push_deliver_is_empty", Boolean.TRUE.toString()));
            return new Response(ResponseCode.SYSTEM_ERROR.name());
        }
    }
}
