package vn.com.paysmart.uis.mafc.controller;

import com.google.gson.Gson;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import vn.com.paysmart.common.redis.JedisSentinelClient;
import vn.com.paysmart.common.uis.common.Config;
import vn.com.paysmart.common.uis.entity.Response;
import vn.com.paysmart.common.uis.json.JsonObject;
import vn.com.paysmart.common.uis.profiler.ProfilerLog;
import vn.com.paysmart.common.uis.utils.GsonUtil;
import vn.com.paysmart.uis.mafc.client.MAFCConnectorClient;
import vn.com.paysmart.uis.mafc.client.thread.db.bData;
import vn.com.paysmart.uis.mafc.client.thread.log.oData;
import vn.com.paysmart.uis.mafc.constant.FieldName;
import vn.com.paysmart.uis.mafc.entity.ContractInfo;
import vn.com.paysmart.uis.mafc.entity.ContractList;
import vn.com.paysmart.uis.mafc.entity.OperationName;
import vn.com.paysmart.uis.mafc.entity.ResponseCode;
import vn.com.paysmart.uis.mafc.entity.ServiceRequest;
import vn.com.paysmart.uis.mafc.utils.StaticConfig;

/**
 *
 * @author longdo
 */
public class CollectionMAFC implements ServiceController {
    private static final String JEDIS_SERVER = "jedis_server";
    @Override
    public Response processRequest(String type, String requestId, JsonObject data, String rawData, String caller,
          ProfilerLog profilerLog) throws Exception {
    	
        // call Connector API
        StaticConfig.LOGMANAGER.submit(new oData(FieldName.NAN_ID, data.getString(FieldName.NAN_ID)));
        StaticConfig.LOGMANAGER.submit(new oData(FieldName.AC_NO, data.getString(FieldName.AC_NO)));
        StaticConfig.LOGMANAGER.submit(new oData(FieldName.CONTRACT_NO, data.getString(FieldName.CONTRACT_NO)));
        StaticConfig.LOGMANAGER.submit(new oData(FieldName.WALLETID, data.getString(FieldName.WALLETID)));
        StaticConfig.LOGMANAGER.submit(new oData(FieldName.PHONE_NO, data.getString(FieldName.PHONE_NO)));
        
        if (!StringUtils.isEmpty(data.getString(FieldName.CUSTOMER_PHONE))) {
        	StaticConfig.LOGMANAGER.submit(new oData(FieldName.CUSTOMER_PHONE, data.getString(FieldName.CUSTOMER_PHONE)));
        }

        profilerLog.doStartLog(OperationName.COLLECTION_MAFC);
        ServiceRequest req = null;
        try {
            req = GsonUtil.fromJson(data.toString(), ServiceRequest.class);
        } catch (Exception ex) {
        	StaticConfig.LOGMANAGER.submit(new oData("collectionMAFC_processRequest_ex1", ExceptionUtils.getStackTrace(ex)));
            // no have this exception because have layer valid before
            return new Response(ResponseCode.ERR_INVALID_REQUEST_DATA.name()).setMessage("process message Fail");
        }
        
        // get from redis
        // get contract info from cache
        String REDIS_PREFIX = Config.getParam(JEDIS_SERVER, "prefix") + "." + req.getWalletId() + ".";
        // get from redis
        ContractList contractList = createInfo(type, REDIS_PREFIX, req, StaticConfig.JEDIS_CLIENT);
        // get from redis
		if (Config.getIntParam(JEDIS_SERVER, "enable_use") == 1) {
			// resp in cache
			// status complete collectionAmount has changed, pls query again
			if (contractList != null && contractList.getResult() != null) {
				// insert db
				return this.processCache(type, requestId, req, REDIS_PREFIX, contractList, data,
						caller, StaticConfig.JEDIS_CLIENT, profilerLog);
			}
		}
		StaticConfig.LOGMANAGER.submit(new oData("not_use_cache", Boolean.TRUE.toString()));

		return MAFCConnectorClient.collectionMAFC(requestId, ((type.equals("acc")) ? ((req.getAccNo() == null) ? req.getContractNo() : req.getAccNo()) : req.getNanId()),
                req.getWalletId(), req.getPhoneNo(), req.getCustomerPhone(), caller, profilerLog, StaticConfig.JEDIS_CLIENT);
    }
    
    private ContractList createInfo(String type, String REDIS_PREFIX, ServiceRequest req, JedisSentinelClient jedisClient) {
        String keyRedis = "";
    	Gson gson = new Gson();
    	ContractInfo contractInfo = null;
        ContractList contractList = null;
    	try {
            if (type.equals("acc")) {
                keyRedis = REDIS_PREFIX + StaticConfig.PARTNER_CODE + "." + ((req.getAccNo()!=null)?req.getAccNo():req.getContractNo());
                contractList = new ContractList();

                String cacheContractInfo = (String) jedisClient.get(keyRedis);
                StaticConfig.LOGMANAGER.submit(new oData("get_cache_contract_info", cacheContractInfo));
                if (cacheContractInfo != null) {
                    contractList.setResult(new ArrayList<>());

                    contractInfo = gson.fromJson(cacheContractInfo, ContractInfo.class);
                    contractList.getResult().add(contractInfo);
                }
            } else {
                keyRedis = REDIS_PREFIX + StaticConfig.PARTNER_CODE + "." + req.getNanId();
                String cacheContractInfo = (String) jedisClient.get(keyRedis);
                StaticConfig.LOGMANAGER.submit(new oData("get_cache_contract_info", cacheContractInfo));
                if (cacheContractInfo != null) {
                    contractList = gson.fromJson(cacheContractInfo, ContractList.class);
                }
            }
        } catch (Exception e) {
            StaticConfig.LOGMANAGER.submit(new oData("collectionMAFC_processRequest_ex2", ExceptionUtils.getStackTrace(e)));
        } finally {
        	StaticConfig.LOGMANAGER.submit(new oData("find_redisKey", keyRedis));
		}
    	
    	return contractList;
    }

    private Response processCache(String type, String requestId, ServiceRequest req, String REDIS_PREFIX,
            ContractList contractList, JsonObject data, String caller,
            JedisSentinelClient jedisClient, ProfilerLog profilerLog) {

        Gson gson = new Gson();
        // update custPhone in cache
        String custPhone = data.getString(FieldName.CUSTOMER_PHONE);
        if (!StringUtils.isEmpty(custPhone)) {
            contractList.setCustomerPhone(custPhone);
        }

        StaticConfig.LOGMANAGER.submit(new oData("redis_cache", GsonUtil.toJsonString(contractList)));

        // update list with cashback
        List<ContractInfo> contractListTemp = new ArrayList<>();
        for (int i = 0; i < contractList.getResult().size(); i++) {
            String cashbacked = Config.getParam(JEDIS_SERVER, "prefix") + ".cashbacked." + StaticConfig.PARTNER_CODE
                    + "." + req.getAccNo();
            String cacheContractInfo = (String) jedisClient.get(cashbacked);

            ContractInfo temp = contractList.getResult().get(i);
            temp.setCashBack((cacheContractInfo == null));

            contractListTemp.add(temp);

            String keyRedis = REDIS_PREFIX + StaticConfig.PARTNER_CODE + "." + temp.getAgreeId();
            String cacheContractInfoTemp = (String) jedisClient.get(keyRedis);
            if (cacheContractInfoTemp != null) {
                ContractInfo contractInfoTemp = gson.fromJson(cacheContractInfoTemp, ContractInfo.class);
                if (contractInfoTemp.getStatus().equals("COMPLETE")) {
                    i = contractList.getResult().size(); // out for
                    StaticConfig.LOGMANAGER.submit(new oData("collection_mafc", Boolean.TRUE.toString()));

                    return MAFCConnectorClient.collectionMAFC(requestId,
                            ((type.equals("acc")) ? req.getAccNo() : req.getNanId()), req.getWalletId(),
                            req.getPhoneNo(), req.getCustomerPhone(), caller, profilerLog, jedisClient);
                }
            }
        }

        if (contractListTemp.isEmpty()) {
            return new Response(ResponseCode.FAIL.name()).setMessage("no data response");
        }

        for (int i = 0; i < contractList.getResult().size(); i++) {
            ContractInfo contractInfo = contractList.getResult().get(i);
            // insert reminder
            StaticConfig.DBMANAGER.submit(new bData("insertReminder", data.getString(FieldName.WALLETID), StaticConfig.PARTNER_CODE, contractInfo.getAgreeId(),
                  "", contractInfo.getCustName(), String.valueOf(contractInfo.getInstlAmt()), contractInfo.getDueDate(),
                  contractInfo.getPhoneNo(), contractInfo.getCustomerPhone()));
        }
        if (!StringUtils.isEmpty(contractList.getCustomerPhone())) {
            // insert tracking insider
        	StaticConfig.DBMANAGER.submit(new bData("insertCustomerPhone", contractList.getCustomerPhone(), contractList.getResult().get(0).getCustName(),
                  contractList.getResult().get(0).getPartnerCode()));
        }

        String encodeData = vn.com.paysmart.uis.mafc.utils.CommonUtil.genResponse(contractList);
        return new Response(ResponseCode.SUCCESS.name()).setData(encodeData);
    }
}