package vn.com.paysmart.uis.mafc.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import vn.com.paysmart.common.databaseadapter.DatabaseAdapter;
import vn.com.paysmart.common.databaseadapter.SqlHelper;
import vn.com.paysmart.common.databaseadapter.model.DatabaseTypeEnum;
import vn.com.paysmart.common.uis.common.Config;
import vn.com.paysmart.uis.mafc.client.thread.log.oData;
import vn.com.paysmart.uis.mafc.utils.StaticConfig;

/**
 *
 * @author longdo
 */
public class DbCient {
    private static DatabaseAdapter DB_ADAPTER;

    static {
        try {
            StaticConfig.LOGMANAGER.submit(new oData("init_database_adapter", Boolean.TRUE.toString()));
            String dbSec = "config_db";
            DB_ADAPTER = new DatabaseAdapter();
            DB_ADAPTER.init(
                    DatabaseTypeEnum.fromValue(Config.getParam(dbSec, "database_db_type")),
                    Config.getParam(dbSec, "database_db_host"),
                    Config.getParam(dbSec, "database_db_port"),
                    Config.getParam(dbSec, "database_db_name"),
                    Config.getParam(dbSec, "database_db_user"),
                    Config.getParam(dbSec, "database_db_pwd")
            );
        } catch (Exception e) {
        	StaticConfig.LOGMANAGER.submit(new oData("exception_stack_trace_init_database", ExceptionUtils.getStackTrace(e)));
        }
    }

    public static void insertReminder(
            String walletId, String partnerCode, String contractNo, String contractType,
            String borrowerName, String loanAmount, String dueDate, String phoneNo, String customerPhone) {
        try {
            SqlHelper sqlhelper = new SqlHelper(false, DB_ADAPTER);
            sqlhelper.addParameterIn(walletId, java.sql.Types.VARCHAR);
            sqlhelper.addParameterIn(partnerCode, java.sql.Types.VARCHAR);
            sqlhelper.addParameterIn(contractNo, java.sql.Types.VARCHAR);
            sqlhelper.addParameterIn(contractType, java.sql.Types.VARCHAR);

            sqlhelper.addParameterIn(borrowerName, java.sql.Types.VARCHAR);
            sqlhelper.addParameterIn(loanAmount, java.sql.Types.VARCHAR);
            sqlhelper.addParameterIn(dueDate, java.sql.Types.VARCHAR);
            sqlhelper.addParameterIn(phoneNo, java.sql.Types.VARCHAR);
            sqlhelper.addParameterIn(customerPhone, (customerPhone == null) ? java.sql.Types.NULL : java.sql.Types.VARCHAR);

            DBConnector connector = new DBConnector(sqlhelper, DB_ADAPTER, "call sp_insert_mafc_loan(?,?,?,?,?,?,?,?,?)");
            int rowInsert = -1;

            JsonArray arr = connector.execute();
            if (arr == null || arr.size() <= 0) {
                rowInsert = 0;
            } else {
                JsonObject obj = arr.get(0).getAsJsonObject();
                rowInsert = obj.get("result").getAsInt();
            }
            StaticConfig.LOGMANAGER.submit(new oData("insert_reminder", String.valueOf(rowInsert)));
        } catch (Exception e) {
        	StaticConfig.LOGMANAGER.submit(new oData("insertReminder_ex", ExceptionUtils.getStackTrace(e)));
        }
    }

    public static void insertCustomerPhone(String customerPhone,
            String customerName, String fromPartner) {
        try {
            SqlHelper sqlhelper = new SqlHelper(false, DB_ADAPTER);
            sqlhelper.addParameterIn(customerPhone, java.sql.Types.VARCHAR);
            sqlhelper.addParameterIn(customerName, java.sql.Types.VARCHAR);
            sqlhelper.addParameterIn(fromPartner, java.sql.Types.VARCHAR);

            DBConnector connector = new DBConnector(sqlhelper, DB_ADAPTER, "call sp_insert_repayment_customer_phone(?,?,?)");
            int rowInsert = -1;

            JsonArray arr = connector.execute();
            if (arr == null || arr.size() <= 0) {
                rowInsert = 0;
            } else {
                JsonObject obj = arr.get(0).getAsJsonObject();
                rowInsert = obj.get("result").getAsInt();
            }
            StaticConfig.LOGMANAGER.submit(new oData("insert_customer_phone", String.valueOf(rowInsert)));
        } catch (Exception e) {
        	StaticConfig.LOGMANAGER.submit(new oData("insert_customer_phone_ex", ExceptionUtils.getStackTrace(e)));
        }
    }
}