package vn.com.paysmart.uis.mafc.constant;

public final class ConfigName {
    public static final String APPLICATION_NAME = "application.name";
    public static final String SERVICE = "service";
    public static final String VERSION = "version";
    public static final String ENABLE_PROFILER = "enable-profiler";
    public static final String ENABLE_DEBUG = "enable-debug";
    public static final String SERVICE_CALLER = "service_caller";
    public static final String JETTY = "jetty";
    public static final String MINTHREADS = "minthreads";
    public static final String MAXTHREADS = "maxthreads";
    public static final String KAFKA = "kafka";
    public static final String SERVERS = "servers";
    public static final String CLIENT_ID = "client-id";
    public static final String MAFC_CONNECTOR = "mafc_connector";
    public static final String BASE_URL = "base_url";
    public static final String CALLER = "caller";
    public static final String SECRETKEY = "secret-key";
    public static final String GIT_PROPERTIES = "git.properties";
    public static final String GIT_BRANCH = "git.branch";
    public static final String GIT_COMMIT_ID = "git.commit.id";

    public static final String PARTNERNAME = "partnerName";
    public static final String PARTNERDES = "partnerDes";
    public static final String PARTNERCODE = "partnerCode";
    
    public static final String LOGOURL = "logoUrl";
    public static final String HINTAMOUNTINPUT = "hintAmountInput";
    public static final String MINTAMOUNT = "minAmount";
    public static final String MAXAMOUNT = "maxAmount";
    public static final String USERPHONENUMBER = "userPhoneNumber";

    public static final String CASHBACKAMOUNT = "cashbackAmount";
    public static final String ACCNO = "accNo";
    public static final String ACCNAME = "accName";
    public static final String DUEDATE = "dueDate";
    public static final String COLLECTIONAMOUNT = "collectionAmount";
    public static final String OVERDUEAMT = "overdueAmt";
    public static final String COLLECTIONMAXAMOUNT = "collectionMaxAmount";
    public static final String COLLECTIONMAXAMOUNTHINT = "collectionMaxAmountHint";
    public static final String PAYMENTAMOUNT = "paymentAmount";
    public static final String PAYMENTAMOUNTHINT = "paymentAmountHint";
    
    public static final String CONTRACTNO = "contractNo";
    public static final String CUSTOMERNAME = "customerName";
}
