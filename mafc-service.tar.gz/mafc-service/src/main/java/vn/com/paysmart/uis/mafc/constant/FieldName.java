package vn.com.paysmart.uis.mafc.constant;

/**
*
* @author longdo
*/
public final class FieldName {
	public static final String RRN = "rrn";
	public static final String AC_NO = "accNo";
	public static final String CONTRACT_NO = "contractNo";
	public static final String NAN_ID = "nanId";
	public static final String AGN_ID = "agnId";
	public static final String ACC_NAME = "AccName";
	public static final String TRAN_ID = "transId";
	public static final String WALLETID = "walletId";
	public static final String CUSTOMER_PHONE = "customerPhone";
	public static final String CUSTOMER_NAME = "customerName";
	public static final String PHONE_NO = "phoneNo";
	public static final String CLIENT_ID_NO = "client_id_no";
	public static final String TRANS_AMOUNT = "transAmount";
	public static final String TRANS_TIME = "transTime";
	public static final String BEF_TRANS_DEBT = "bef_trans_debt";
	public static final String AFF_TRANS_DEBT = "aff_trans_debt";
	public static final String ACCOUNT_TYPE = "account_type";
	public static final String ORDER_ID = "order_id";
	
	public static final String CODE = "code";
	public static final String CALLER = "caller";
	public static final String DATA = "data";
	public static final String MESSAGE = "message";
	public static final String CHECK_SUM = "checksum";
	public static final String SIGNATURE = "signature";
	
	//for request
	public static final String REQUEST_ID = "request_id";
	public static final String X_REQUEST_ID = "X-Request-ID";
	public static final String X_CALLER = "X-Caller";
	
	public static final String QUEUE_INSTANCE = "repaymentQueue";
	
	public static final String PAY = "PAY";
}
