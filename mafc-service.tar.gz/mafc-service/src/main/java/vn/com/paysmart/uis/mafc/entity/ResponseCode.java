package vn.com.paysmart.uis.mafc.entity;

/**
*
* @author longdo
*/
public enum ResponseCode {
	OK,
	SUCCESS,
	FAIL,
	TIME_OUT,
	INVALID_AUTHEN,
	ERR_INVALID_REQUEST_DATA,
	ERR_INVALID_RESPONSE_DATA,
	API_NOT_SUPPORTED,
	SYSTEM_ERROR,
	ERROR;
	
	private String message = "";
    public ResponseCode addMessage(String message) {
        this.message = message;
        return this;
    }
	public String getMessage() {
		return message;
	}
}
