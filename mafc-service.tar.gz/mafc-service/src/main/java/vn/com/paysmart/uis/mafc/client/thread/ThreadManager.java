package vn.com.paysmart.uis.mafc.client.thread;

import java.util.ArrayList;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public abstract class ThreadManager {
	public final int BATCH_SIZE = 10;// Chương trình sẽ thực hiện doProcess khi hàng đợi vượt quá 10 phần tử
	public final long WAIT_TIME_OUT = 1000; // ms
	public final long TIME_OUT = 2 * 1000; // ms. Chương trình sẽ thực hiện doProcess với chu kỳ 2 giây
	private static final Logger logger = LogManager.getLogger(ThreadManager.class);
	private final BlockingQueue sourceQueue = new LinkedBlockingQueue();
	protected ArrayList items = new ArrayList(BATCH_SIZE);
	protected AtomicBoolean shouldWork = new AtomicBoolean(true);
	protected AtomicBoolean isRunning = new AtomicBoolean(true);
	private boolean listening = false;
	private String name = "THREAD MANAGER PROCESS";
	protected ExecutorService executorService = Executors.newFixedThreadPool(5);
	protected Thread mainThread;

	public ThreadManager() {
		mainThread = new Thread(new Runnable() {
			@Override
			public void run() {
				isRunning.set(true);
				int recNum = 0;
				long lgnStart = System.currentTimeMillis();
				while (shouldWork.get()) {
					recNum = doWork(recNum);

					if (recNum >= BATCH_SIZE || timedOut(lgnStart)) {
						if (items.size() > 0) {
							doProcess(items);
							items = new ArrayList(BATCH_SIZE);
							lgnStart = System.currentTimeMillis();
							recNum = 0;
						}
					}
					
					isRunning.set(false);
				}
				logger.info("Taskmanager " + name + " is stopped!!");
			}

			private boolean timedOut(Long startTime) {
				return System.currentTimeMillis() - startTime > TIME_OUT;
			}
		});

	}

	private int doWork(int recNum) {
		int cnt = recNum;
		try {
			Object item = sourceQueue.poll(WAIT_TIME_OUT, TimeUnit.MILLISECONDS);
			if (item != null) {
				items.add(item);
				cnt++;
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return cnt;
	}

	/**
	 * abstract method xử lý nghiệp vụ
	 * 
	 * @param items
	 */
	public abstract void doProcess(ArrayList items);

	/**
	 * Bắt đầu lắng nghe dữ liệu cần xử lý từ hàng đợi
	 */
	public synchronized void listen() {
		logger.info("Init Thread Manager process");
		if (!listening) {
			mainThread.start();
			listening = true;
		}
	}

	public BlockingQueue getSourceQueue() {
		return sourceQueue;
	}

	public void stop() {
		logger.info(String.format("%s received a termination signal, stopping ... ", name));
		this.shouldWork.set(false);
		int tryTime = 0;
		while (isRunning.get() && tryTime < 50) {
			try {
				Thread.currentThread().sleep(50L);
			} catch (Exception ex) {

			}
			tryTime++;
		}
	}

	/**
	 * Submit một đối tượng cần xử lý vào hàng đợi
	 * 
	 * @param item
	 */
	// public void submit(Object item) {
	public void submit(Object item) {
		sourceQueue.offer(item);
	}
}