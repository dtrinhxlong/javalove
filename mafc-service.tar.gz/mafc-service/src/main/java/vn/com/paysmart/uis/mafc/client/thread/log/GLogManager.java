package vn.com.paysmart.uis.mafc.client.thread.log;

import java.util.ArrayList;
import vn.com.paysmart.common.uis.log.DefaultLogBuilder;
import vn.com.paysmart.common.uis.log.LogBuilder;
import vn.com.paysmart.logging.SimpleLogMessage;
import vn.com.paysmart.uis.mafc.client.thread.ThreadManager;
import vn.com.paysmart.uis.mafc.utils.StaticConfig;

public class GLogManager extends ThreadManager {
	
	public GLogManager() {
		mainThread.setName("graylog_thread");
	}
	
	protected SimpleLogMessage.Builder simpleLogBuilder = new SimpleLogMessage.Builder()
			.setModule(StaticConfig.APPLICATION_NAME).setCaller("sys").setOperation("mafc_service")
			.setOperationVersion("1.0").setRequestId(Long.toString(System.nanoTime()));

	public SimpleLogMessage.Builder getSimpleLogBuilder() {
		return simpleLogBuilder;
	}

	public void setSimpleLogBuilder(SimpleLogMessage.Builder simpleLogBuilder) {
		this.simpleLogBuilder = simpleLogBuilder;
	}

	protected LogBuilder logBuilder = new DefaultLogBuilder();

	public LogBuilder getLogBuilder() {
		return logBuilder;
	}

	public void setLogBuilder(LogBuilder logBuilder) {
		this.logBuilder = logBuilder;
	}

	@Override
	public void doProcess(ArrayList items) {
		GLogThread logThread = new GLogThread();
		logThread.setItems(items);
		logThread.setLogBuilder(logBuilder);
		logThread.setSimpleLogBuilder(simpleLogBuilder);

		executorService.submit(logThread);
	}
}
