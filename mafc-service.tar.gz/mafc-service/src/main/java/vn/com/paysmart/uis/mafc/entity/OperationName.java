package vn.com.paysmart.uis.mafc.entity;

/**
*
* @author longdo
*/
public final class OperationName {
	public static final String COLLECTION_MAFC = "collectionmafc";
    public static final String PAY_BILL_MAFC = "paybillmafc";
}
