package vn.com.paysmart.uis.mafc.client.thread.db;

import java.util.ArrayList;
import vn.com.paysmart.uis.mafc.client.thread.ThreadManager;

public class DBManager extends ThreadManager {
	
	public DBManager() {
		mainThread.setName("mysql_thread");
	}
	
	@Override
	public void doProcess(ArrayList items) {
		DBThread logThread = new DBThread();
		logThread.setItems(items);

		executorService.submit(logThread);
	}
}
