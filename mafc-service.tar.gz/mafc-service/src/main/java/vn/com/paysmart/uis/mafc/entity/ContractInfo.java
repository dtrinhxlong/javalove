package vn.com.paysmart.uis.mafc.entity;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author longdo
 *
 * deserialize map fromJson
 *
 * serialize map toJson
 */
public class ContractInfo {
	
	@SerializedName(value = "AgreeId", alternate = {"v_agreeid"})
    @Expose(serialize = true, deserialize = true)
    public String agreeId;

	@SerializedName(value = "CustName", alternate = {"v_custname"})
    @Expose(serialize = true, deserialize = true)
    public String custName;
    
	@SerializedName(value = "NetReceivable", alternate = {"v_net_receivable"})
    @Expose(serialize = true, deserialize = true)
    public long netReceivable;
    
	@SerializedName(value = "InstlAmt", alternate = {"v_instlamt"})
    @Expose(serialize = true, deserialize = true)
    public long instlAmt;
    
	@SerializedName(value = "DueDate", alternate = {"v_duedate"})
    @Expose(serialize = true, deserialize = true)
    public String dueDate;
    
	@SerializedName(value = "Status")
    @Expose(serialize = true, deserialize = true)
    public String status;
	
	@SerializedName(value = "WalletId")
    @Expose(serialize = true, deserialize = true)
    public String walletId;

	@SerializedName(value = "CustomerPhone")
    @Expose(serialize = true, deserialize = true)
    public String customerPhone;
	
	@SerializedName(value = "TransId")
    @Expose(serialize = true, deserialize = true)
    public String transId;
	
	@SerializedName(value = "TransAmount")
    @Expose(serialize = true, deserialize = true)
    public int transAmount;
	
	@SerializedName(value = "TransTime")
    @Expose(serialize = true, deserialize = true)
    public long transTime;

	@SerializedName(value = "RequestId")
    @Expose(serialize = true, deserialize = true)
    public String requestId;

	@SerializedName(value = "PhoneNo")
    @Expose(serialize = true, deserialize = true)
    public String phoneNo;

	@SerializedName(value = "PartnerCode")
    @Expose(serialize = true, deserialize = true)
    public String partnerCode;
	
	@SerializedName(value = "MinAmount")
    @Expose(serialize = true, deserialize = true)
    public int minAmount;
    
	@SerializedName(value = "CashBack")
    @Expose(serialize = true, deserialize = true)
    public boolean cashBack;
	
	@SerializedName(value = "Rrn")
    @Expose(serialize = true, deserialize = true)
	public String rrn;

	public String getRrn() {
		return rrn;
	}

	public void setRrn(String rrn) {
		this.rrn = rrn;
	}

	public long getTransTime() {
		return transTime;
	}

	public void setTransTime(long transTime) {
		this.transTime = transTime;
	}

	public int getMinAmount() {
		return minAmount;
	}

	public void setMinAmount(int minAmount) {
		this.minAmount = minAmount;
	}

	public String getAgreeId() {
		return agreeId;
	}

	public void setAgreeId(String agreeId) {
		this.agreeId = agreeId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public long getNetReceivable() {
		return netReceivable;
	}

	public void setNetReceivable(long netReceivable) {
		this.netReceivable = netReceivable;
	}

	public long getInstlAmt() {
		return instlAmt;
	}

	public void setInstlAmt(long instlAmt) {
		this.instlAmt = instlAmt;
	}

	public String getDueDate() {
		return dueDate;
	}

	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getWalletId() {
		return walletId;
	}

	public void setWalletId(String walletId) {
		this.walletId = walletId;
	}

	public String getCustomerPhone() {
		return customerPhone;
	}

	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}

	public String getTransId() {
		return transId;
	}

	public void setTransId(String transId) {
		this.transId = transId;
	}

	public int getTransAmount() {
		return transAmount;
	}

	public void setTransAmount(int transAmount) {
		this.transAmount = transAmount;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getPartnerCode() {
		return partnerCode;
	}

	public void setPartnerCode(String partnerCode) {
		this.partnerCode = partnerCode;
	}

	public boolean isCashBack() {
		return cashBack;
	}

	public void setCashBack(boolean cashBack) {
		this.cashBack = cashBack;
	}
}