package vn.com.paysmart.uis.mafc.entity;

import java.util.List;

public class ContractList {
	private String nationalID;
	private String customerPhone;
	
	public List<ContractInfo> result;
	
	public String getCustomerPhone() {
		return customerPhone;
	}

	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}

	public String getNationalID() {
		return nationalID;
	}

	public void setNationalID(String nationalID) {
		this.nationalID = nationalID;
	}

	public List<ContractInfo> getResult() {
		return result;
	}

	public void setResult(List<ContractInfo> result) {
		this.result = result;
	}
}
