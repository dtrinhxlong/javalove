package vn.com.paysmart.uis.mafc.client;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import vn.com.paysmart.common.redis.JedisSentinelClient;
import vn.com.paysmart.common.uis.entity.Response;
import vn.com.paysmart.common.uis.json.JsonObject;
import vn.com.paysmart.common.uis.profiler.ProfilerLog;
import vn.com.paysmart.uis.mafc.client.thread.log.oData;
import vn.com.paysmart.uis.mafc.constant.FieldName;
import vn.com.paysmart.uis.mafc.entity.OperationName;
import vn.com.paysmart.uis.mafc.entity.ResponseCode;
import vn.com.paysmart.uis.mafc.stream.CollectionMAFC;
import vn.com.paysmart.uis.mafc.stream.PayBillMAFC;
import vn.com.paysmart.uis.mafc.utils.CommonUtil;
import vn.com.paysmart.uis.mafc.utils.StaticConfig;

/**
 *
 * @author longdo
 */
public class MAFCConnectorClient {
    public static Response collectionMAFC(String reqId, String accNo, String walletId, String phoneNo,
            String customerPhone, String caller, ProfilerLog profilerLog, JedisSentinelClient jedisClient) {
        JsonObject data = new JsonObject();
        // data.addProperty("request_id", reqId);
        data.addProperty(FieldName.AGN_ID, accNo);
        data.addProperty(FieldName.WALLETID, walletId);
        data.addProperty(FieldName.PHONE_NO, phoneNo);
        if (!StringUtils.isEmpty(customerPhone)) {
            data.addProperty(FieldName.CUSTOMER_PHONE, customerPhone);
        }

        return postConnector(OperationName.COLLECTION_MAFC, reqId, data, profilerLog, jedisClient);
    }

    public static Response payBillMAFC(String reqId, String reqTime,
            String accNo, String customerName,
            String walletId, String phoneNo,
            String tranId, int tranAmt, String customerPhone, String transTime, String rrn, 
            ProfilerLog profilerLog, JedisSentinelClient jedisClient) {
        JsonObject data = new JsonObject();
        data.addProperty(FieldName.AC_NO, accNo);
        data.addProperty(FieldName.CUSTOMER_NAME, customerName);
        data.addProperty(FieldName.CUSTOMER_PHONE, customerPhone);
        data.addProperty(FieldName.WALLETID, walletId);
        data.addProperty(FieldName.PHONE_NO, phoneNo);
        data.addProperty(FieldName.TRAN_ID, tranId);
        data.addProperty(FieldName.TRANS_AMOUNT, tranAmt);
        data.addProperty(FieldName.TRANS_TIME, transTime);
        data.addProperty(FieldName.RRN, rrn);

        return postConnector(OperationName.PAY_BILL_MAFC, reqId, data, profilerLog, jedisClient);
    }

    private static Response postConnector(String method, String requestId, JsonObject data,
            ProfilerLog profilerLog, JedisSentinelClient jedisClient) {
        Response response = null;
        try {
            // query new
            if (method.equals(OperationName.COLLECTION_MAFC)) {
                String resp = CommonUtil.getResponse(StaticConfig.MAFC_CONNECTOR_URL + "/" + method,
                        CommonUtil.genBase64(data.toString()), requestId, profilerLog);
                if (resp == null) {
                    return new Response(ResponseCode.TIME_OUT.name()).setMessage("can not response Connector");
                }
                
                response = CollectionMAFC.streamACT(data, resp, requestId, jedisClient, profilerLog);
            } else {
                if (method.equals(OperationName.PAY_BILL_MAFC)) {
                	response = PayBillMAFC.streamACT(jedisClient, data, requestId, profilerLog);
                }
            }
        } catch (Exception e) {
            StaticConfig.LOGMANAGER.submit(new oData("post_connector_ex", ExceptionUtils.getStackTrace(e)));
            return new Response(ResponseCode.SYSTEM_ERROR.name()).setMessage("process data FAIL.");
        } finally {
        	 profilerLog.doEndLog(OperationName.COLLECTION_MAFC);
		}
        return response;
    }
}
