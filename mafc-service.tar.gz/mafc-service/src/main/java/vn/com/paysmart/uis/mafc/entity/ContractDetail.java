package vn.com.paysmart.uis.mafc.entity;

public class ContractDetail {
	private String accNo;
	private String accName;
	private String clientIdNo;
	private String orderId;
	private String expireDate;
	private String collectAmount;
	private int collectAmountMin;
	private int collectAmountMax;
	public String getAccNo() {
		return accNo;
	}
	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}
	public String getAccName() {
		return accName;
	}
	public void setAccName(String accName) {
		this.accName = accName;
	}
	public String getClientIdNo() {
		return clientIdNo;
	}
	public void setClientIdNo(String clientIdNo) {
		this.clientIdNo = clientIdNo;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getExpireDate() {
		return expireDate;
	}
	public void setExpireDate(String expireDate) {
		this.expireDate = expireDate;
	}
	public String getCollectAmount() {
		return collectAmount;
	}
	public void setCollectAmount(String collectAmount) {
		this.collectAmount = collectAmount;
	}
	public int getCollectAmountMin() {
		return collectAmountMin;
	}
	public void setCollectAmountMin(int collectAmountMin) {
		this.collectAmountMin = collectAmountMin;
	}
	public int getCollectAmountMax() {
		return collectAmountMax;
	}
	public void setCollectAmountMax(int collectAmountMax) {
		this.collectAmountMax = collectAmountMax;
	}
}
