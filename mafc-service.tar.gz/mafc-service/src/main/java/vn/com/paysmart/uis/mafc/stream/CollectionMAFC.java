package vn.com.paysmart.uis.mafc.stream;

import java.util.ArrayList;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import vn.com.paysmart.common.redis.JedisSentinelClient;
import vn.com.paysmart.common.uis.common.Config;
import vn.com.paysmart.common.uis.entity.Response;
import vn.com.paysmart.common.uis.json.JsonObject;
import vn.com.paysmart.common.uis.profiler.ProfilerLog;
import vn.com.paysmart.common.uis.utils.GsonUtil;
import vn.com.paysmart.uis.mafc.client.thread.db.bData;
import vn.com.paysmart.uis.mafc.client.thread.log.oData;
import vn.com.paysmart.uis.mafc.constant.FieldName;
import vn.com.paysmart.uis.mafc.entity.ConnectorResponse;
import vn.com.paysmart.uis.mafc.entity.ContractInfo;
import vn.com.paysmart.uis.mafc.entity.ContractList;
import vn.com.paysmart.uis.mafc.entity.ResponseCode;
import vn.com.paysmart.uis.mafc.utils.CommonUtil;
import vn.com.paysmart.uis.mafc.utils.StaticConfig;

public class CollectionMAFC {
    public static final String COLLECTION_MAFC = "collectionmafc";
    private static final String JEDIS_SERVER = "jedis_server";
    private static final String SAVE_KEYREDIS = "save_keyRedis";

    public static Response streamACT(JsonObject data, String resp, String requestId,
            JedisSentinelClient jedisClient, ProfilerLog profilerLog) throws Exception {
        String REDIS_PREFIX = Config.getParam(JEDIS_SERVER, "prefix") + "." + data.getString(FieldName.WALLETID) + ".";
        String REDIS_PREFIX_TRANS = Config.getParam(JEDIS_SERVER, "prefix-trans") + "."
                + data.getString(FieldName.WALLETID) + ".";
        long ttl = Config.getLongParam("config-data", "contract_info_expired");

        String sdata = JsonObject.parse(resp).getString(FieldName.DATA);
        ConnectorResponse result = GsonUtil.fromJson(sdata, ConnectorResponse.class);

        if (!result.getCode().equals(ResponseCode.SUCCESS.name())) {
            return new Response(ResponseCode.FAIL.name()).setMessage(result.getMessage());
        }

        ResponseCode code = vn.com.paysmart.uis.mafc.validator.ValidatorUtils.validateResponse(COLLECTION_MAFC, sdata,
                JsonObject.parse(resp).getString(FieldName.CALLER));
        if (!code.name().equals(ResponseCode.SUCCESS.name())) {
            return new Response(ResponseCode.ERROR.name()).setMessage("validate resp fail");
        }
        // save contract info to cache
        String decodeData = CommonUtil.decodeBase64(JsonObject.parse(sdata).getString(FieldName.DATA));
        ContractList contractList = GsonUtil.fromJson(decodeData, ContractList.class);
        
        StaticConfig.LOGMANAGER.submit(new oData("data_response", decodeData));

        if (contractList.getResult().isEmpty()) {
            StaticConfig.LOGMANAGER.submit(new oData("contract_list_is_empty", Boolean.TRUE.toString()));
            return new Response(ResponseCode.FAIL.name()).setMessage(JsonObject.parse(sdata).getString(FieldName.MESSAGE));
        }
        
        ArrayList<ContractInfo> resultTemp = new ArrayList<>();
        for (int i = 0; i < contractList.getResult().size(); i++) {
            ContractInfo contractInfo = contractList.getResult().get(i);
            contractInfo.setStatus("QUERY");
            contractInfo.setCustomerPhone(data.getString(FieldName.CUSTOMER_PHONE));
            contractInfo.setPhoneNo(data.getString(FieldName.PHONE_NO));
            contractInfo.setPartnerCode(StaticConfig.PARTNER_CODE);

            String cashbacked = Config.getParam(JEDIS_SERVER, "prefix") + ".cashbacked." + StaticConfig.PARTNER_CODE
                    + "." + contractInfo.getAgreeId();
            String cacheContractInfo = (String) jedisClient.get(cashbacked);
            contractInfo.setCashBack((cacheContractInfo == null));
            try {
                String keyRedisTrans = REDIS_PREFIX_TRANS + StaticConfig.PARTNER_CODE + "."
                        + data.getString(FieldName.AGN_ID);
                StaticConfig.LOGMANAGER.submit(new oData(SAVE_KEYREDIS, keyRedisTrans));

                String sData = GsonUtil.toJsonString(contractInfo);
                jedisClient.set(keyRedisTrans, sData, ttl * 60 * 24);
                processDB(contractInfo, data);
            } catch (Exception e) {
            	StaticConfig.LOGMANAGER.submit(new oData("collectionMAFC_streamACT_ex1", ExceptionUtils.getStackTrace(e)));
            }
            resultTemp.add(contractInfo);
        }
        contractList.setResult(resultTemp);
        if(!StringUtils.isEmpty(data.getString(FieldName.CUSTOMER_PHONE))) {
        	contractList.setCustomerPhone(data.getString(FieldName.CUSTOMER_PHONE));
        }
        String sData = GsonUtil.toJsonString(contractList.getResult().get(0));

        if (contractList.getResult().size() > 1) {
            sData = GsonUtil.toJsonString(contractList);
        }

        try {
            String keyRedis = REDIS_PREFIX + StaticConfig.PARTNER_CODE + "." + data.getString(FieldName.AGN_ID);
            StaticConfig.LOGMANAGER.submit(new oData(SAVE_KEYREDIS, keyRedis));

            jedisClient.set(keyRedis, sData, ttl * 60 * 24);
        } catch (Exception e) {
        	StaticConfig.LOGMANAGER.submit(new oData("collectionMAFC_streamACT_ex2", ExceptionUtils.getStackTrace(e)));
        }
        
        return new Response(ResponseCode.SUCCESS.name()).setData(CommonUtil.genResponse(contractList));
    }

    public static void processDB(ContractInfo contractInfo, JsonObject data) {
        // insert reminder
    	StaticConfig.DBMANAGER.submit(new bData("insertReminder", data.getString(FieldName.WALLETID), StaticConfig.PARTNER_CODE, contractInfo.getAgreeId(),
                "", contractInfo.getCustName(), String.valueOf(contractInfo.getInstlAmt()), contractInfo.getDueDate(),
                contractInfo.getPhoneNo(), contractInfo.getCustomerPhone()));

        if (!StringUtils.isEmpty(contractInfo.getCustomerPhone())) {
            // insert tracking insider
        	StaticConfig.DBMANAGER.submit(new bData("insertCustomerPhone", contractInfo.getCustomerPhone(), contractInfo.getCustName(),
                  contractInfo.getPartnerCode()));
        }
    }
}
