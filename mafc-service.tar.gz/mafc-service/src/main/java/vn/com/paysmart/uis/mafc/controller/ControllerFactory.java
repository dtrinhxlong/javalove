package vn.com.paysmart.uis.mafc.controller;

/**
 *
 * @author longdo
 */
public class ControllerFactory {
    private static final String COLLECTION_MAFC = "collectionmafc";
    private static final String PAY_BILL_MAFC = "paybillmafc";

    public ServiceController getServiceController(String version, String apiName) {
        ServiceController serviceController = null;
        switch (apiName) {
            case COLLECTION_MAFC:
                serviceController = new CollectionMAFC();
                break;
            case PAY_BILL_MAFC:
                serviceController = new PayBillMAFC();
                break;
            default:
                break;
        }
        return serviceController;
    }
}
