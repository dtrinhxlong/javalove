package vn.com.paysmart.uis.mafc.entity;
