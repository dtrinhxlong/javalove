package vn.com.paysmart.uis.mafc.httpservice;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import com.google.gson.Gson;
import vn.com.paysmart.common.uis.common.Config;
import vn.com.paysmart.common.uis.entity.Response;
import vn.com.paysmart.common.uis.json.JsonObject;
import vn.com.paysmart.common.uis.profiler.ProfilerLog;
import vn.com.paysmart.common.uis.utils.CommonUtil;
import vn.com.paysmart.common.uis.utils.CryptoUtil;
import vn.com.paysmart.common.uis.utils.DateTimeUtil;
import vn.com.paysmart.uis.mafc.client.thread.log.oData;
import vn.com.paysmart.uis.mafc.constant.FieldName;
import vn.com.paysmart.uis.mafc.controller.ControllerFactory;
import vn.com.paysmart.uis.mafc.controller.ServiceController;
import vn.com.paysmart.uis.mafc.entity.ResponseCode;
import vn.com.paysmart.uis.mafc.utils.StaticConfig;

/**
 *
 * @author longdo
 */
public class IndexServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String reqId = req.getHeader(FieldName.X_REQUEST_ID);
		String caller = req.getHeader(FieldName.X_CALLER);
		this.out("Success", resp, reqId, caller);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		ProfilerLog profilerLog = new ProfilerLog(true);
		StaticConfig.LOGMANAGER.submit(new oData("date", DateTimeUtil.getCurrentDateTimeAsString(DateTimeUtil.DEFAULT_DATE_TIME_FORMAT)));
		
		String caller = "";
		String reqId = "";
		Response response = new Response();
		try {
			profilerLog.doStartLog("wholerequest");
			String func = CommonUtil.trim(req.getPathInfo(), "/mafc/");
			String version = CommonUtil.trim(req.getServletPath(), "/");
			String rawData = IOUtils.toString(req.getReader());
			
			reqId = req.getHeader(FieldName.X_REQUEST_ID);
			caller = req.getHeader(FieldName.X_CALLER);
			
			//header required
			if(StringUtils.isEmpty(reqId) || StringUtils.isEmpty(caller)) {
				StaticConfig.LOGMANAGER.submit(new oData("header_request", caller+":"+reqId+" is wrong"));
				response = new Response(ResponseCode.SYSTEM_ERROR.name()).setMessage("X-Request-ID, X-Caller is requied");
			} else {
				StaticConfig.LOGMANAGER.submit(new oData("function", func));
				StaticConfig.LOGMANAGER.submit(new oData("version", version));
				
				response = processNext(func, rawData, caller, reqId, version, profilerLog);
				
				profilerLog.doEndLog("wholerequest");
				StaticConfig.LOGMANAGER.submit(new oData("PROFILER_LOG", profilerLog.dumpScribeLog()));
			}
		} catch (Exception e) {
			StaticConfig.LOGMANAGER.submit(new oData("exception_stack_trace_index_doPost", ExceptionUtils.getStackTrace(e)));
			response = new Response(ResponseCode.SYSTEM_ERROR.name());
		} finally {
			StaticConfig.LOGMANAGER.getSimpleLogBuilder().setResponseCode(response.getCode());
		}
		
		if(response.getCode().equals(ResponseCode.SUCCESS.name())) {
			//da endcode data
			String checksum = genCheckSum(response, caller);
			response.setSignature(checksum);
		}
		
		this.out(new Gson().toJson(response), resp, caller, reqId);
	}
	
	public Response processNext(String func, String rawData, String caller, String reqId, String version,
			ProfilerLog profilerLog) throws Exception {
		
		ResponseCode code = vn.com.paysmart.uis.mafc.validator.ValidatorUtils.validateRequest(func, rawData, caller);
		if (!code.name().equals(ResponseCode.SUCCESS.name())) {
			return new Response(code.name()).setMessage(code.getMessage());
		} else {
			String decodeData = code.getMessage();
			JsonObject decodeDataObj = JsonObject.parse(decodeData);
			
			if (StaticConfig.APP_ENABLE_DEBUG) {
				StaticConfig.LOGMANAGER.submit(new oData("rawData", decodeData));
	        }
			
			StaticConfig.LOGMANAGER.getSimpleLogBuilder().setRequestId("" + System.nanoTime()).setCaller(caller)
					.setModule(StaticConfig.APPLICATION_NAME).setOperation(func).setOperationVersion(version);
			
			if (StringUtils.isNotBlank(reqId)) {
				StaticConfig.LOGMANAGER.getSimpleLogBuilder().setRequestId(reqId);
			}
			
			ControllerFactory controllerFactory = new ControllerFactory();
			ServiceController controller = controllerFactory.getServiceController(version, func);

			return getResponse(controller, reqId, caller, decodeDataObj, rawData, profilerLog);
		}
	}

	public Response getResponse(ServiceController controller, String requestId, String caller, JsonObject dataRequest, 
			String rawData, ProfilerLog profilerLog) throws Exception {
		if (controller == null) {
			return new Response(ResponseCode.API_NOT_SUPPORTED.name());
		} else {
			String type = "acc";
			if(!StringUtils.isEmpty(dataRequest.getString(FieldName.NAN_ID))) {
				type = "nan";
			}

			return controller.processRequest(type, requestId, dataRequest, rawData, caller, profilerLog);
		}
	}

	private void out(String content, HttpServletResponse resp, String caller, String requestId) {
		PrintWriter out = null;
		try {
			resp.setCharacterEncoding("UTF-8");
			resp.addHeader("Content-Type", "application/json;charset=UTF-8");
			
			resp.addHeader(FieldName.X_REQUEST_ID, requestId);
			resp.addHeader(FieldName.X_CALLER, caller);
			
			if(caller.equals("PAY_TRANS_DELIVER")) {
				resp.setStatus(500);
				JsonObject tmp = JsonObject.parse(content);
				if(tmp.getString("code").equals("SUCCESS")) {
					resp.setStatus(200);
				}
			}
			out = resp.getWriter();
			out.println(content);
		} catch (IOException e) {
			StaticConfig.LOGMANAGER.submit(new oData("exception_stack_trace_todo_out", ExceptionUtils.getStackTrace(e)));
		} finally {
			if (out != null) {
				out.close();
			}
		}
	}

	private String genCheckSum(Response response, String caller) {
		try {
			String secretKey = Config.getParam("app", caller);
			String data = "";
			if (response.getData() != null) {
				data = response.getData();
			}
			return CryptoUtil.sha256(data + "|" + secretKey);
		} catch (Exception e) {
			StaticConfig.LOGMANAGER.submit(new oData("exception_stack_trace_gen_checksum", ExceptionUtils.getStackTrace(e)));
			return null;
		}
	}
}