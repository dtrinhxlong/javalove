package vn.com.paysmart.uis.mafc.client.thread.log;

import java.util.List;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import vn.com.paysmart.common.uis.json.JsonObject;
import vn.com.paysmart.common.uis.log.DefaultLogBuilder;
import vn.com.paysmart.common.uis.log.LogBuilder;
import vn.com.paysmart.json.Json;
import vn.com.paysmart.logging.SimpleLogMessage;
import vn.com.paysmart.logging.SingletonLogWriter;
import vn.com.paysmart.uis.mafc.client.thread.Task;
import vn.com.paysmart.uis.mafc.entity.Constant;
import vn.com.paysmart.uis.mafc.utils.StaticConfig;

public class GLogThread extends Task {
	private static final Logger logger = LogManager.getLogger(GLogThread.class);

	private SimpleLogMessage.Builder simpleLogBuilder;

	public SimpleLogMessage.Builder getSimpleLogBuilder() {
		return simpleLogBuilder;
	}

	public void setSimpleLogBuilder(SimpleLogMessage.Builder simpleLogBuilder) {
		this.simpleLogBuilder = simpleLogBuilder;
	}

	private LogBuilder logBuilder;

	public LogBuilder getLogBuilder() {
		return logBuilder;
	}

	public void setLogBuilder(LogBuilder logBuilder) {
		this.logBuilder = logBuilder;
	}

	@Override
	public Integer call() throws Exception {
		List<Object> lstLog = getItems();
		try {
			if (lstLog != null && !lstLog.isEmpty()) {
				save(lstLog);
			}
		} catch (Exception e) {
			logger.error(e.toString(), e);
			return 0;
		}
		return 1;
	}

	public void save(List<Object> lst) {
		try {
			for (Object item : lst) {
				logBuilder.append(((oData) item).getKey(), ((oData) item).getValue());
			}
		} catch (Exception e) {
			logger.error("save_list_task ", e);
			logger.info("backup_msg "+lst);
		} finally {
			JsonObject json = JsonObject.parse(simpleLogBuilder.build().toString());
			if (!StringUtils.isEmpty(json.getString(Constant.RESP_CODE))) {
				try {
					SingletonLogWriter.Instance
							.write(simpleLogBuilder.setData(Json.tryConvert(logBuilder.buildObject())).build());
					
					StaticConfig.LOGMANAGER.setLogBuilder(new DefaultLogBuilder());
					StaticConfig.LOGMANAGER.getSimpleLogBuilder().setResponseCode(null);
				} catch (Exception e) {
					logger.error("can't write log to kafka", e);
				}
			}
		}
	}

}
