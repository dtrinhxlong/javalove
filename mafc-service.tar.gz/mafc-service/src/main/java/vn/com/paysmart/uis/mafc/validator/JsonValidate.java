package vn.com.paysmart.uis.mafc.validator;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.everit.json.schema.Schema;
import org.everit.json.schema.ValidationException;
import org.everit.json.schema.loader.SchemaLoader;
import org.json.JSONObject;
import org.json.JSONTokener;
import vn.com.paysmart.common.uis.json.JsonObject;
import vn.com.paysmart.uis.mafc.client.thread.log.oData;
import vn.com.paysmart.uis.mafc.entity.ResponseCode;
import vn.com.paysmart.uis.mafc.utils.StaticConfig;

public class JsonValidate implements Serializable {
	private static final long serialVersionUID = 1L;
	public static final String SCHEMAFILE = "schema";

	public static void parserResult(String service, JSONObject json) throws ValidationException, FileNotFoundException {
		InputStream inputStream = Thread.currentThread().getContextClassLoader()
				.getResourceAsStream(SCHEMAFILE + File.separator + service);
		JSONObject jsonSchema = new JSONObject(new JSONTokener(inputStream));
		Schema schema = SchemaLoader.load(jsonSchema);
		schema.validate(json);
		try {
			inputStream.close();
		} catch (IOException ex) {
			StaticConfig.LOGMANAGER.submit(new oData("exception_stack_trace_parse_result", ExceptionUtils.getStackTrace(ex)));
		}
	}

	public static ResponseCode validateWithSchema(String schema, JsonObject data) {
		StringBuilder error_msg = new StringBuilder();
		try {
			parserResult(schema, new JSONObject(data.toString()));
		} catch (ValidationException ex) {
			for (String err : ex.getAllMessages()) {
				error_msg.append(err);
			}
		} catch (Exception ex) {
			error_msg.append(ex.getMessage());
		}
		if (error_msg.length() > 0) {
			StaticConfig.LOGMANAGER.submit(new oData("exception_stack_trace_validate_with_", error_msg.toString()));
			return ResponseCode.ERR_INVALID_REQUEST_DATA.addMessage(error_msg.toString());
		} else {
			return ResponseCode.SUCCESS;
		}
	}
}
