package vn.com.paysmart.uis.mafc.controller;

import vn.com.paysmart.common.uis.entity.Response;
import vn.com.paysmart.common.uis.json.JsonObject;
import vn.com.paysmart.common.uis.profiler.ProfilerLog;

/**
 *
 * @author longdo
 */
public interface ServiceController {
	Response processRequest(String type, String requestId, JsonObject data, String rawData, String caller, ProfilerLog profilerLog) throws Exception;
}
