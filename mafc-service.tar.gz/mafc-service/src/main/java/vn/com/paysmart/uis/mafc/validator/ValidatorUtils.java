package vn.com.paysmart.uis.mafc.validator;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.Base64;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.eclipse.jetty.util.StringUtil;
import org.everit.json.schema.Schema;
import org.everit.json.schema.ValidationException;
import org.everit.json.schema.loader.SchemaLoader;
import org.json.JSONObject;
import org.json.JSONTokener;
import vn.com.paysmart.common.uis.common.Config;
import vn.com.paysmart.common.uis.json.JsonObject;
import vn.com.paysmart.uis.mafc.client.thread.log.oData;
import vn.com.paysmart.uis.mafc.constant.ConfigName;
import vn.com.paysmart.uis.mafc.constant.FieldName;
import vn.com.paysmart.uis.mafc.entity.ResponseCode;
import vn.com.paysmart.uis.mafc.utils.CommonUtil;
import vn.com.paysmart.uis.mafc.utils.StaticConfig;

public class ValidatorUtils implements Serializable {
    private static final long serialVersionUID = 1L;
    
    public static final String PATH = System.getProperty("apppath") + File.separator + "conf";
    public static final String SCHEMAFILE = "schema";
    public static final String REQ_PATH_SUB = "req";
    public static final String RESP_PATH_SUB = "resp";
    public static final String PREFIX = " is wrong";
    public static final String PREFIX_VALID_ERR = "validate ERROR_ ";

    private static String SUCCESS = "SUCCESS";

    private static void parserResult(String service, JSONObject json, String pathSub)
            throws ValidationException, FileNotFoundException {
    	String pathName = PATH + File.separator + SCHEMAFILE + File.separator + pathSub + ((!StringUtils.isEmpty(pathSub))?File.separator:"") + service + ".json";
    	InputStream inputStream = new FileInputStream(pathName);
        JSONObject jsonSchema = new JSONObject(new JSONTokener(inputStream));
        Schema schema = SchemaLoader.load(jsonSchema);
        schema.validate(json);
        try {
            inputStream.close();
        } catch (IOException ex) {
        	StaticConfig.LOGMANAGER.submit(new oData("exception_stack_trace_parse_result", ExceptionUtils.getStackTrace(ex)));
        }
    }

    public static ResponseCode validateResponse(String schema, String data, String caller) {
        JsonObject dataObj = JsonObject.parse(data);
        //String caller = dataObj.getString(FieldName.CALLER);
        //check caller
        if (!caller.equals(StaticConfig.MAFC_CONNECTOR_CALLER)) {
            StaticConfig.LOGMANAGER.submit(new oData(PREFIX_VALID_ERR, caller + PREFIX));
            return ResponseCode.INVALID_AUTHEN.addMessage(caller + PREFIX);
        }

        String encodeData = dataObj.getString(FieldName.DATA);
        String checkSum = dataObj.getString(FieldName.SIGNATURE);
        //check checksum
        boolean verify = CommonUtil.verifyChecksum(encodeData, checkSum, StaticConfig.MAFC_CONNECTOR_KEY);
        if (!verify) {
            return ResponseCode.INVALID_AUTHEN.addMessage("verify checksum fail");
        }

        StringBuilder error_msg = validate(schema, dataObj.toString(), RESP_PATH_SUB);
        if (error_msg.length() > 0) {
            StaticConfig.LOGMANAGER.submit(new oData(PREFIX_VALID_ERR, error_msg.toString()));
            return ResponseCode.ERR_INVALID_RESPONSE_DATA.addMessage(error_msg.toString());
        }

        return ResponseCode.SUCCESS.addMessage(SUCCESS);
    }

    public static ResponseCode validateRequest(String schema, String data, String callerId) {
        //check caller
        String callerKey = Config.getParam(ConfigName.SERVICE, callerId);
        if (StringUtil.isEmpty(callerKey)) {
            StaticConfig.LOGMANAGER.submit(new oData(PREFIX_VALID_ERR, callerId + PREFIX));
            return ResponseCode.INVALID_AUTHEN.addMessage(callerId + PREFIX);
        }
        
        //check data request
        StringBuilder error_msg = validate("mafc-service", data, "");
        if (error_msg.length() > 0) {
            StaticConfig.LOGMANAGER.submit(new oData(PREFIX_VALID_ERR, error_msg.toString()));
            return ResponseCode.ERR_INVALID_REQUEST_DATA.addMessage(error_msg.toString());
        }
        
        JsonObject dataObj = null;
        try {
	        dataObj = JsonObject.parse(data);
        } catch (Exception e) {
        	return ResponseCode.ERR_INVALID_REQUEST_DATA.addMessage(data + " have character special before base64");
		}
        
        String encodeData = dataObj.getString(FieldName.DATA);
        String checkSum = dataObj.getString(FieldName.CHECK_SUM);
        //check checksum
        boolean verify = CommonUtil.verifyChecksum(encodeData, checkSum, callerKey);
        if (!verify) {
            return ResponseCode.INVALID_AUTHEN.addMessage("verify checksum fail");
        }
       
        //check format data
        error_msg = validate(schema, data, REQ_PATH_SUB);
        if (error_msg.length() > 0) {
            StaticConfig.LOGMANAGER.submit(new oData(PREFIX_VALID_ERR, error_msg.toString()));
            return ResponseCode.ERR_INVALID_REQUEST_DATA.addMessage(error_msg.toString());
        }

        return ResponseCode.SUCCESS.addMessage(new String(Base64.getDecoder().decode(encodeData)));
    }

    private static StringBuilder validate(String schema, String data, String pathSub) {
        StringBuilder error_msg = new StringBuilder();
        try {
            JsonObject dataObj = JsonObject.parse(data);
            String dataEncode = dataObj.getString(FieldName.DATA);
            String decodeData = new String(Base64.getDecoder().decode(dataEncode));
            
            if(StringUtils.isEmpty(pathSub)) {
            	decodeData = data;
        	}

            parserResult(schema, new JSONObject(decodeData), pathSub);
        } catch (ValidationException ex) {
            for (String err : ex.getAllMessages()) {
                error_msg.append(err);
            }
        } catch (Exception ex) {
            error_msg.append(ex.getMessage());
        }

        return error_msg;
    }
}