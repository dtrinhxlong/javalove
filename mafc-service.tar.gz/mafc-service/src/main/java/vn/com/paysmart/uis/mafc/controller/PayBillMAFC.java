package vn.com.paysmart.uis.mafc.controller;

import org.apache.commons.lang3.exception.ExceptionUtils;
import vn.com.paysmart.common.redis.JedisSentinelClient;
import vn.com.paysmart.common.uis.entity.Response;
import vn.com.paysmart.common.uis.json.JsonObject;
import vn.com.paysmart.common.uis.profiler.ProfilerLog;
import vn.com.paysmart.common.uis.utils.GsonUtil;
import vn.com.paysmart.uis.mafc.client.MAFCConnectorClient;
import vn.com.paysmart.uis.mafc.client.thread.log.oData;
import vn.com.paysmart.uis.mafc.constant.FieldName;
import vn.com.paysmart.uis.mafc.entity.OperationName;
import vn.com.paysmart.uis.mafc.entity.ResponseCode;
import vn.com.paysmart.uis.mafc.entity.ServiceRequest;
import vn.com.paysmart.uis.mafc.utils.StaticConfig;

/**
 *
 * @author longdo
 */
public class PayBillMAFC implements ServiceController {

    @Override
    public Response processRequest(String type, String requestId, JsonObject data, String rawdata, String caller, ProfilerLog profilerLog) throws Exception {
        StaticConfig.LOGMANAGER.submit(new oData(FieldName.AC_NO, data.getString(FieldName.AC_NO)));
        StaticConfig.LOGMANAGER.submit(new oData(FieldName.CUSTOMER_NAME, data.getString(FieldName.CUSTOMER_NAME)));
        StaticConfig.LOGMANAGER.submit(new oData(FieldName.WALLETID, data.getString(FieldName.WALLETID)));
        StaticConfig.LOGMANAGER.submit(new oData(FieldName.PHONE_NO, data.getString(FieldName.PHONE_NO)));
        StaticConfig.LOGMANAGER.submit(new oData(FieldName.CUSTOMER_PHONE, data.getString(FieldName.CUSTOMER_PHONE)));
        StaticConfig.LOGMANAGER.submit(new oData(FieldName.TRAN_ID, data.getString(FieldName.TRAN_ID)));
        StaticConfig.LOGMANAGER.submit(new oData(FieldName.TRANS_AMOUNT, data.getString(FieldName.TRANS_AMOUNT)));
        StaticConfig.LOGMANAGER.submit(new oData(FieldName.TRANS_TIME, data.getString(FieldName.TRANS_TIME)));
        StaticConfig.LOGMANAGER.submit(new oData(FieldName.RRN, data.getString(FieldName.RRN)));

        profilerLog.doStartLog(OperationName.PAY_BILL_MAFC);
        ServiceRequest req = null;
        try {
            req = GsonUtil.fromJson(data.toString(), ServiceRequest.class);
        } catch (Exception ex) {
            StaticConfig.LOGMANAGER.submit(new oData("collectionMAFC_processRequest_ex1", ExceptionUtils.getStackTrace(ex)));
            return new Response(ResponseCode.ERR_INVALID_REQUEST_DATA.name()).setMessage("process message Fail");
        }

        JedisSentinelClient jedisClient = JedisSentinelClient.getInstance(
                StaticConfig.REDIS_SENTINEL_NAME, StaticConfig.REDIS_SERVERS, StaticConfig.REDIS_AUTH);

        // call Connector API
        return MAFCConnectorClient.payBillMAFC(requestId, req.getRequestTime(),
                req.getAccNo(), req.getCustomerName(),
                req.getWalletId(), req.getPhoneNo(),
                req.getTransId(), req.getTransAmount(),
                req.getCustomerPhone(), req.getTransTime(), req.getRrn(), 
                profilerLog, jedisClient);
    }
}