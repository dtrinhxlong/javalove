package vn.com.paysmart.uis.mafc.client.thread.db;

import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import vn.com.paysmart.uis.mafc.client.DbCient;
import vn.com.paysmart.uis.mafc.client.thread.Task;

public class DBThread extends Task {
	private static final Logger logger = LogManager.getLogger(DBThread.class);

	@Override
	public Integer call() throws Exception {
		List<Object> lstLog = getItems();
        try {
            if (lstLog != null && !lstLog.isEmpty()) {
                save(lstLog);
            }
        } catch (Exception e) {
            logger.error(e.toString(), e);
            return 0;
        }
        return 1;
	}
	
	public void save(List<Object> lst) {
		try {
			for (Object item : lst) {
				bData data = (bData)item;
				if("insertReminder".equals(data.getName())) {
					DbCient.insertReminder(data.getWalletId(), data.getPartnerCode(), data.getContractNo(),
							data.getContractType(), data.getBorrowerName(), data.getLoanAmount(), data.getDueDate(),
							data.getPhoneNo(), data.getCustomerPhone());
				} else {
					
				}
			}
		} catch (Exception e) {
			logger.error("save_list_task", e);
			logger.info("backup_msg: "+lst);
		}
	}

}
