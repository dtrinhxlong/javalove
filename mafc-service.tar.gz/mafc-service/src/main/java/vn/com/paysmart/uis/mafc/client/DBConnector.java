package vn.com.paysmart.uis.mafc.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import vn.com.paysmart.common.databaseadapter.DatabaseAdapter;
import vn.com.paysmart.common.databaseadapter.DatabaseCallback;
import vn.com.paysmart.common.databaseadapter.SqlHelper;

/**
 *
 * @author longdo
 */
public class DBConnector {

    private final SqlHelper sqlhelper;
    private final DatabaseAdapter databaseAdapter;
    private final String queryStmt;

    public DBConnector(SqlHelper sqlhelper, DatabaseAdapter databaseAdapter, String queryStmt) {
        this.sqlhelper = sqlhelper;
        this.databaseAdapter = databaseAdapter;
        this.queryStmt = queryStmt;
    }

    public JsonArray execute() throws SQLException {
        String sqlQuery = this.queryStmt;

        final JsonArray arr = new JsonArray();
        DatabaseCallback callback = new DatabaseCallback() {
            @Override
            public CallableStatement prepareCall(Connection conn) throws SQLException {
                CallableStatement cStmt = conn.prepareCall(sqlQuery);
                sqlhelper.CopyParameters(cStmt);
                return cStmt;
            }

            @Override
            public void processResult(CallableStatement cs, ResultSet rs) throws SQLException {
                while (rs != null && rs.next()) {
                    int totalCol = rs.getMetaData().getColumnCount();
                    JsonObject obj = new JsonObject();
                    for (int i = 0; i < totalCol; i++) {
                        obj.addProperty(rs.getMetaData().getColumnLabel(i + 1).toLowerCase(), rs.getString(i + 1));
                    }
                    arr.add(obj);
                }
            }

			@Override
			public void processResult(String value) throws SQLException {
				// TODO Auto-generated method stub
				
			}
        };

        databaseAdapter.executeQuery(callback);
        return arr;
    }
}
