package vn.com.paysmart.uis.mafc.utils;

import java.io.InputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import vn.com.paysmart.common.queue.QueueConfig;
import vn.com.paysmart.common.queue.RabbitMQConfig;
import vn.com.paysmart.common.redis.JedisSentinelClient;
import vn.com.paysmart.common.uis.common.Config;
import vn.com.paysmart.logging.SingletonLogWriter;
import vn.com.paysmart.logging.kafka.LogWriter;
import vn.com.paysmart.logging.kafka.LogWriterConfig;
import vn.com.paysmart.uis.mafc.client.PoolingHttpClient;
import vn.com.paysmart.uis.mafc.client.thread.db.DBManager;
import vn.com.paysmart.uis.mafc.client.thread.log.GLogManager;
import vn.com.paysmart.uis.mafc.constant.ConfigName;

/**
 *
 * @author longdo
 */
public class StaticConfig {
	private static final Logger LOGGER = LoggerFactory.getLogger(StaticConfig.class);

	public static final String PARTNER_CODE = "MAFC";

	public static final String APPLICATION_NAME;
	public static final String APP_VERSION;
	public static final boolean APP_ENABLE_PROFILER;
	public static final boolean APP_ENABLE_DEBUG;

	public static final String SERVICE_CALLER;

	public static final String REDIS_SENTINEL_NAME;
	public static final String REDIS_SERVERS;
	public static final String REDIS_AUTH;
	public static final String REDIS_PREFIX;

	public static final String MAFC_CONNECTOR_URL;
	public static final String MAFC_CONNECTOR_CALLER;
	public static final String MAFC_CONNECTOR_KEY;

	public static final String RABBIT_MQ_INSTANCE_NAME;
	public static final String RABBIT_MQ_QUEUENAME_DELIVER;

	public static final String GIT_REVISION;
	public static final String GIT_COMMIT_ID;

	public static final String JETTY = "jetty";
	public static final int JETTY_MIN_THREADS = Integer.parseInt(Config.getParam(JETTY, "minthreads"));
	public static final int JETTY_MAX_QUEUED = Integer.parseInt(Config.getParam(JETTY, "maxqueued"));
	public static final int JETTY_MAX_THREADS = Integer.parseInt(Config.getParam(JETTY, "maxthreads"));
	public static final int JETTY_IDE_TIMEOUT = Integer.parseInt(Config.getParam(JETTY, "idetimeout"));
	public static final String JETTY_NAME = Config.getParam(JETTY, "name");
	
	public static JedisSentinelClient JEDIS_CLIENT;

	public static GLogManager LOGMANAGER;
	public static DBManager DBMANAGER;

	private StaticConfig() {
	}

	static {
		String applicationName = null;

		String appVersion = null;
		boolean appEnableProfiler = false;
		boolean appEnableDebug = false;

		String mafcConnectorUrl = null;
		String mafcConnectorCaller = null;
		String mafcConnectorKey = null;

		String serviceCaller = null;

		String rabbitMQInstanceName = null;
		String rabbitMQHost = null;
		int rabbitMQPort = 0;
		String rabbitMQUsername = null;
		String rabbitMQPassword = null;
		int rabbitMQPoolSize = 0;
		int rabbitMQPrefetchCount = 0;
		String rabbitMQQueuenameDeliver = null;

		String redisSentinelName = null;
		String redisServers = null;
		String redisAuth = null;
		String redisPrefix = null;

		String gitRevision = null;
		String gitCommitId = null;

		GLogManager logManager;
		DBManager dbManager;
		
		JedisSentinelClient jedisClient = null;

		try {
			applicationName = System.getProperty(ConfigName.APPLICATION_NAME);

			String serviceSec = ConfigName.SERVICE;

			appVersion = Config.getParam(serviceSec, ConfigName.VERSION);
			appEnableProfiler = Config.getIntParam(serviceSec, ConfigName.ENABLE_PROFILER) == 1;
			appEnableDebug = Config.getIntParam(serviceSec, ConfigName.ENABLE_DEBUG) == 1;

			rabbitMQInstanceName = "rabbitmq";
			rabbitMQHost = Config.getParam(rabbitMQInstanceName, "host");
			rabbitMQPort = Config.getIntParam(rabbitMQInstanceName, "port");
			rabbitMQUsername = Config.getParam(rabbitMQInstanceName, "username");
			rabbitMQPassword = Config.getParam(rabbitMQInstanceName, "password");
			rabbitMQPoolSize = Config.getIntParam(rabbitMQInstanceName, "thread-pool-size");
			rabbitMQPrefetchCount = Config.getIntParam(rabbitMQInstanceName, "prefetch-count");
			rabbitMQQueuenameDeliver = Config.getParam(rabbitMQInstanceName, "queue-deliver");

			RabbitMQConfig rabbitMQConfigReminder = new RabbitMQConfig(rabbitMQHost, rabbitMQPort, rabbitMQUsername,
					rabbitMQPassword, "/", rabbitMQPoolSize, false, rabbitMQPrefetchCount);
			QueueConfig.initConfig(rabbitMQInstanceName, rabbitMQConfigReminder);
			
			LOGGER.info("Init Kafka...");
			String kafkaSec = ConfigName.KAFKA;
			String kafkaServers = Config.getParam(kafkaSec, ConfigName.SERVERS);
			String kafkaClientId = Config.getParam(kafkaSec, ConfigName.CLIENT_ID);
			LogWriterConfig.Builder b = new LogWriterConfig.Builder().setClientId(kafkaClientId)
					.setTopic(System.getProperty(ConfigName.APPLICATION_NAME));
			String[] serversArr = kafkaServers.split(",");
			for (String server : serversArr) {
				String[] s = server.split(":");
				b.addHostPort(s[0], Integer.parseInt(s[1]));
			}
			SingletonLogWriter.Instance.registerWriter(new LogWriter(b.build()));

			String redis = "jedis_server";
			redisSentinelName = Config.getParam(redis, "sentinel-name");
			redisServers = Config.getParam(redis, "servers");
			redisAuth = Config.getParam(redis, "auth");
			redisPrefix = Config.getParam(redis, "prefix");
			
	        jedisClient = JedisSentinelClient.getInstance(redisSentinelName,
	        		redisServers, redisAuth);

			String fecConnectorSec = ConfigName.MAFC_CONNECTOR;
			mafcConnectorUrl = Config.getParam(fecConnectorSec, ConfigName.BASE_URL);
			mafcConnectorCaller = Config.getParam(fecConnectorSec, ConfigName.CALLER);
			mafcConnectorKey = Config.getParam(fecConnectorSec, ConfigName.SECRETKEY);

			InputStream is = Thread.currentThread().getContextClassLoader()
					.getResourceAsStream(ConfigName.GIT_PROPERTIES);
			java.util.Properties prop = new java.util.Properties();
			// load a properties file
			prop.load(is);

			gitRevision = prop.getProperty(ConfigName.GIT_BRANCH);
			gitCommitId = prop.getProperty(ConfigName.GIT_COMMIT_ID);

			LOGGER.info("Load config successfully.");
		} catch (Exception e) {
			LOGGER.error("Exception.msg=Load config failed. " + e.getMessage(), e);
			System.exit(1);
		}

		APPLICATION_NAME = applicationName;

		APP_VERSION = appVersion;
		APP_ENABLE_PROFILER = appEnableProfiler;
		APP_ENABLE_DEBUG = appEnableDebug;

		SERVICE_CALLER = serviceCaller;

		RABBIT_MQ_INSTANCE_NAME = rabbitMQInstanceName;
		RABBIT_MQ_QUEUENAME_DELIVER = rabbitMQQueuenameDeliver;

		REDIS_SENTINEL_NAME = redisSentinelName;
		REDIS_SERVERS = redisServers;
		REDIS_AUTH = redisAuth;
		REDIS_PREFIX = redisPrefix;

		MAFC_CONNECTOR_URL = mafcConnectorUrl;
		MAFC_CONNECTOR_CALLER = mafcConnectorCaller;
		MAFC_CONNECTOR_KEY = mafcConnectorKey;

		GIT_REVISION = gitRevision;
		GIT_COMMIT_ID = gitCommitId;

		logManager = new GLogManager();
		dbManager = new DBManager();

		LOGMANAGER = logManager;
		DBMANAGER = dbManager;

		LOGMANAGER.listen();
		DBMANAGER.listen();
		
		JEDIS_CLIENT = jedisClient;
	}
	
	public static final PoolingHttpClient POOL_HTTP_CLIENT = new PoolingHttpClient();

	public static void initClassLoader() {
		LOGGER.info("Init class loader ...");
	}
}