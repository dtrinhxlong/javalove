package vn.com.paysmart.uis.mafc.httpservice;

import java.io.File;
import org.apache.logging.log4j.Logger;
import vn.com.paysmart.common.uis.common.LogUtil;
import vn.com.paysmart.uis.mafc.utils.StaticConfig;

/**
*
* @author longdo
*/
public class ServiceDaemon {
	private static final Logger LOGGER = LogUtil.getLogger(ServiceDaemon.class.getSimpleName());

	public static void main(String[] args) {
		try {
			LogUtil.init();
			StaticConfig.initClassLoader();
			
			String pidFile = System.getProperty("pidfile");
			if (pidFile != null) {
				new File(pidFile).deleteOnExit();
			}

			WebServer webServer = new WebServer();
			Thread thread0 = new Thread(webServer);
			thread0.setName("httpservice_thread");
            thread0.start();
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			e.getMessage();
			System.exit(1);
		}
	}
}
