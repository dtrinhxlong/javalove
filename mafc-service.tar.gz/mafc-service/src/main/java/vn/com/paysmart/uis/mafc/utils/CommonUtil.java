package vn.com.paysmart.uis.mafc.utils;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.http.Header;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import vn.com.paysmart.common.uis.common.Config;
import vn.com.paysmart.common.uis.entity.Response;
import vn.com.paysmart.common.uis.profiler.ProfilerLog;
import vn.com.paysmart.common.uis.utils.CryptoUtil;
import vn.com.paysmart.common.uis.utils.GsonUtil;
import vn.com.paysmart.uis.mafc.client.thread.log.oData;
import vn.com.paysmart.uis.mafc.constant.ConfigName;
import vn.com.paysmart.uis.mafc.constant.FieldName;
import vn.com.paysmart.uis.mafc.entity.ContractInfo;
import vn.com.paysmart.uis.mafc.entity.ContractList;

public class CommonUtil {
	public static String genBase64(String data) {
		return new String(Base64.getEncoder().encode(data.getBytes()));
	}

	public static String decodeBase64(String data) {
		return new String(Base64.getDecoder().decode(data.getBytes()));
	}

	public static String genCheckSum(Response response, String caller) {
		try {
			String secretKey = Config.getParam("mafc_connector", caller);
			String data = "";
			if (response.getData() != null) {
				data = response.getData();
			}
			return CryptoUtil.sha256(data + "|" + secretKey);
		} catch (Exception e) {
			StaticConfig.LOGMANAGER
					.submit(new oData("exception_stack_trace_gen_checksum", ExceptionUtils.getStackTrace(e)));
			return null;
		}
	}

	public static String createChecksum(String data, String caller) {
		try {
			String secretKey = Config.getParam("mafc_connector", caller);
			return CryptoUtil.sha256(data + "|" + secretKey);
		} catch (Exception e) {
			StaticConfig.LOGMANAGER
					.submit(new oData("exception_stack_trace_create_checksum", ExceptionUtils.getStackTrace(e)));
			return null;
		}
	}

	public static String getResponse(String url, String data, String requestId, ProfilerLog profilerLog) throws IOException {
		String checksum = CryptoUtil.sha256(data + "|" + StaticConfig.MAFC_CONNECTOR_KEY);
		JsonObject reqData = new JsonObject();
		reqData.addProperty(FieldName.DATA, data);
		reqData.addProperty(FieldName.CHECK_SUM, checksum);
		
		StaticConfig.LOGMANAGER.submit(new oData("about_to_post_something_to", url));
		return StaticConfig.POOL_HTTP_CLIENT.doPost(url, reqData.toString(), requestId, StaticConfig.MAFC_CONNECTOR_CALLER, profilerLog);
	}

	public static boolean verifyChecksum(String data, String checksum, String key) {
		String encryptedSig = CryptoUtil.sha256(data + "|" + key);
		if (!encryptedSig.equals(checksum)) {
			return false;
		}
		return true;
	}

	public static String genResponse(ContractList contractList) {
		try {
			String section = "messages";
			Locale localeVN = new Locale("vi", "VN");
			NumberFormat currencyVN = NumberFormat.getCurrencyInstance(localeVN);
			String LEFT = "left";
			String RIGHT = "right";
			String ROWDETAIL = "rowDetail";

			JsonObject data = new JsonObject();
			data.addProperty(ConfigName.PARTNERNAME, Config.getParam(section, ConfigName.PARTNERNAME));
			data.addProperty(ConfigName.PARTNERDES, Config.getParam(section, ConfigName.PARTNERDES));
			data.addProperty(ConfigName.LOGOURL, Config.getParam(section, ConfigName.LOGOURL));
			data.addProperty(ConfigName.HINTAMOUNTINPUT, Config.getParam(section, ConfigName.HINTAMOUNTINPUT).replace(
					"[minAmount]",
					currencyVN.format((long) Double.parseDouble(Config.getParam(section, ConfigName.MINTAMOUNT)))
							.replace(" ", ""))
					.replace("[maxAmount]",
							currencyVN.format((long) Double.parseDouble(Config.getParam(section, ConfigName.MAXAMOUNT)))
									.replace(" ", "")));
			data.addProperty(ConfigName.MINTAMOUNT, Config.getParam(section, ConfigName.MINTAMOUNT));
			data.addProperty(ConfigName.MAXAMOUNT, Config.getParam(section, ConfigName.MAXAMOUNT));
			data.addProperty(ConfigName.USERPHONENUMBER,
					(StringUtils.isEmpty(contractList.getCustomerPhone())) ? "" : contractList.getCustomerPhone());

			List<ContractInfo> arr = contractList.getResult();
			JsonArray jb = new JsonArray();

			for (int i = 0; i < arr.size(); i++) {
				ContractInfo contract = contractList.getResult().get(i);

				JsonObject contractDetail = new JsonObject();
				JsonObject iContract = new JsonObject();

				Date dt = new SimpleDateFormat("yyyy-mm-dd").parse(contract.getDueDate());

				iContract.addProperty(ConfigName.CASHBACKAMOUNT,
						(contract.isCashBack() == false) ? "0" : Config.getParam(section, ConfigName.CASHBACKAMOUNT));
				iContract.addProperty(ConfigName.CONTRACTNO, contract.getAgreeId());
				iContract.addProperty(ConfigName.CUSTOMERNAME, contract.getCustName());
				iContract.addProperty(ConfigName.DUEDATE, new SimpleDateFormat("dd/mm/yyyy").format(dt));
				String overdueAmt = String
						.valueOf((long) Double.parseDouble(String.valueOf(contract.getNetReceivable()).toString()))
						.toString();
				iContract.addProperty(ConfigName.OVERDUEAMT, overdueAmt);
				data.addProperty(ConfigName.PARTNERCODE, contract.getPartnerCode());

				JsonArray ja = new JsonArray();

				JsonObject rowDetail = new JsonObject();
				JsonObject itm = new JsonObject();
				rowDetail.addProperty(LEFT, Config.getParam(section, ConfigName.ACCNO));
				rowDetail.addProperty(RIGHT, contract.getAgreeId());
				itm.addProperty("type", "Key");
				itm.add(ROWDETAIL, rowDetail);
				ja.add(itm);

				rowDetail = new JsonObject();
				itm = new JsonObject();
				rowDetail.addProperty(LEFT, Config.getParam(section, ConfigName.ACCNAME));
				rowDetail.addProperty(RIGHT, contract.getCustName());
				itm.addProperty("type", "Key");
				itm.add(ROWDETAIL, rowDetail);
				ja.add(itm);

				rowDetail = new JsonObject();
				itm = new JsonObject();
				rowDetail.addProperty(LEFT, Config.getParam(section, ConfigName.DUEDATE));
				rowDetail.addProperty(RIGHT, new SimpleDateFormat("dd/mm/yyyy").format(dt));
				itm.addProperty("type", "Key");
				itm.add(ROWDETAIL, rowDetail);
				ja.add(itm);

				rowDetail = new JsonObject();
				itm = new JsonObject();
				rowDetail.addProperty(LEFT, Config.getParam(section, ConfigName.COLLECTIONAMOUNT));
				rowDetail.addProperty(RIGHT,
						currencyVN.format(
								(long) Double.parseDouble(String.valueOf(contract.getNetReceivable()).toString()))
								.replace(" ", ""));
				itm.addProperty("type", "Key");
				itm.add(ROWDETAIL, rowDetail);
				ja.add(itm);

				contractDetail.add("contractInfo", iContract);
				contractDetail.add("displayInfo", ja);

				jb.add(contractDetail);
			}

			data.add("contractList", jb);
			StaticConfig.LOGMANAGER.submit(new oData("gen_response", GsonUtil.toJsonString(data)));

			return CommonUtil.genBase64(GsonUtil.toJsonString(data));
		} catch (Exception e) {
			StaticConfig.LOGMANAGER
					.submit(new oData("exception_stack_trace_gen_response", ExceptionUtils.getStackTrace(e)));
			return null;
		}
	}
}