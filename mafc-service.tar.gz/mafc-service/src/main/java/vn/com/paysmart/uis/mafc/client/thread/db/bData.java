package vn.com.paysmart.uis.mafc.client.thread.db;

import vn.com.paysmart.uis.mafc.constant.FieldName;

public class bData {
	private String name;
	private String walletId, partnerCode, contractNo, contractType, borrowerName, loanAmount, dueDate, phoneNo,
			customerPhone;

	private String customerName, fromPartner;

	public bData(String name, String customerPhone, String customerName, String fromPartner) {
		this.customerPhone = customerPhone;
		this.customerName = customerName;
		this.fromPartner = fromPartner;
	}

	public bData(String name, String walletId, String partnerCode, String contractNo, String contractType,
			String borrowerName, String loanAmount, String dueDate, String phoneNo, String customerPhone) {
		this.name = name;
		this.walletId = walletId;
		this.partnerCode = partnerCode;
		this.contractNo = contractNo;
		this.contractType = contractType;
		this.borrowerName = borrowerName;
		this.loanAmount = loanAmount;
		this.dueDate = dueDate;
		this.phoneNo = phoneNo;
		this.customerPhone = customerPhone;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getFromPartner() {
		return fromPartner;
	}

	public void setFromPartner(String fromPartner) {
		this.fromPartner = fromPartner;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getWalletId() {
		return walletId;
	}

	public void setWalletId(String walletId) {
		this.walletId = walletId;
	}

	public String getPartnerCode() {
		return partnerCode;
	}

	public void setPartnerCode(String partnerCode) {
		this.partnerCode = partnerCode;
	}

	public String getContractNo() {
		return contractNo;
	}

	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}

	public String getContractType() {
		return contractType;
	}

	public void setContractType(String contractType) {
		this.contractType = contractType;
	}

	public String getBorrowerName() {
		return borrowerName;
	}

	public void setBorrowerName(String borrowerName) {
		this.borrowerName = borrowerName;
	}

	public String getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(String loanAmount) {
		this.loanAmount = loanAmount;
	}

	public String getDueDate() {
		return dueDate;
	}

	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getCustomerPhone() {
		return customerPhone;
	}

	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}
	
	public String toString() {
		String str = name+":"+"is not found!";
		if("insertReminder".equals(name)) {
			str = name+":"+walletId+"@"+partnerCode+"@"+contractNo
					+"@"+contractType+"@"+borrowerName+"@"+loanAmount
					+"@"+dueDate+"@"+phoneNo+"@"+customerPhone;
		} else {
			if("insertCustomerPhone".equals(name)) {
				str = name+":"+customerPhone+"@"+customerName
						+"@"+fromPartner;
			}
		}
		return str;
	}
}
