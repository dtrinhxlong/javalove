package vn.com.paysmart.uis.mrps.entity;

public class PartnerName {
	public static final String FEC = "FEC";
	public static final String CASH24 = "CASH24";
	public static final String MAFC = "MAFC";
}
