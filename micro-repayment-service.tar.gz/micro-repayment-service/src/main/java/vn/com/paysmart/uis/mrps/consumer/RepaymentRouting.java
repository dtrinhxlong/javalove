package vn.com.paysmart.uis.mrps.consumer;

import java.nio.charset.StandardCharsets;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import vn.com.paysmart.common.exchange.direct.ExDirectConsumer;
import vn.com.paysmart.common.uis.entity.Response;
import vn.com.paysmart.common.uis.log.DefaultLogBuilder;
import vn.com.paysmart.common.uis.log.LogBuilder;
import vn.com.paysmart.common.uis.profiler.ProfilerLog;
import vn.com.paysmart.common.uis.utils.DateTimeUtil;
import vn.com.paysmart.common.uis.utils.GsonUtil;
import vn.com.paysmart.json.Json;
import vn.com.paysmart.logging.SimpleLogMessage;
import vn.com.paysmart.logging.SingletonLogWriter;
import vn.com.paysmart.uis.mrps.client.thread.log.oData;
import vn.com.paysmart.uis.mrps.controller.ControllerFactory;
import vn.com.paysmart.uis.mrps.controller.ServiceController;
import vn.com.paysmart.uis.mrps.entity.Beneficiary;
import vn.com.paysmart.uis.mrps.entity.Constant;
import vn.com.paysmart.uis.mrps.entity.OrderInfo;
import vn.com.paysmart.uis.mrps.entity.RequestData;
import vn.com.paysmart.uis.mrps.entity.RequestMsg;
import vn.com.paysmart.uis.mrps.util.StaticConfig;

/**
 *
 * @author longdo
 */
public class RepaymentRouting extends ExDirectConsumer {
	public RepaymentRouting() throws Exception {
		super(StaticConfig.RABBIT_MQ_NAME, StaticConfig.RABBIT_MQ_EXCHANGE, StaticConfig.RABBIT_MQ_ROUTING_KEY,
				StaticConfig.RABBIT_MQ_QUEUE_DELIVER);
	}

	@Override
	public void doWork(byte[] bodyMessage) {
		ProfilerLog profilerLog = new ProfilerLog(true);

		StaticConfig.LOGMANAGER.getSimpleLogBuilder().setOperation("repayment_routing");
		StaticConfig.LOGMANAGER.submit(
				new oData("date", DateTimeUtil.getCurrentDateTimeAsString(DateTimeUtil.DEFAULT_DATE_TIME_FORMAT)));

		try {
			profilerLog.doStartLog("WHOLE_REQUEST");
			String rawData = new String(bodyMessage, StandardCharsets.UTF_8);
			StaticConfig.LOGMANAGER.submit(new oData("data_receive", rawData));

			RequestMsg msg = GsonUtil.fromJson(rawData, RequestMsg.class);

			String requestId = msg.getRequestId();
			String caller = msg.getCaller();

			StaticConfig.LOGMANAGER.getSimpleLogBuilder().setCaller(caller);

			if (StringUtils.isNotBlank(requestId)) {
				StaticConfig.LOGMANAGER.getSimpleLogBuilder().setRequestId(requestId);
			}
			// check caller
			if (StringUtils.isEmpty(
					vn.com.paysmart.common.uis.common.Config.getParam(StaticConfig.APP_NAME, msg.getCaller()))) {
				StaticConfig.LOGMANAGER.submit(new oData("check_caller_fail", Boolean.TRUE.toString()));
				StaticConfig.LOGMANAGER.getSimpleLogBuilder().setResponseCode("ERR_CALLER");

				return;
			}
			// check sum
			String genChecksum = vn.com.paysmart.uis.mrps.util.CommonUtil.createChecksum(msg.getData(), msg.getCaller(),
					requestId);
			if (!genChecksum.equals(msg.getSignature())) {
				StaticConfig.LOGMANAGER.submit(new oData("check_sum_fail", Boolean.TRUE.toString()));
				StaticConfig.LOGMANAGER.getSimpleLogBuilder().setResponseCode("ERR_CKS");

				return;
			} else {
				String decrypt = vn.com.paysmart.uis.mrps.util.CommonUtil.decodeBase64(msg.getData());
				StaticConfig.LOGMANAGER.submit(new oData("data_decrypt", decrypt));

				RequestData data = GsonUtil.fromJson(decrypt, RequestData.class);
				OrderInfo info = data.getOrderInfo();
				Beneficiary beneficiary = info.getBeneficiary();

				StaticConfig.LOGMANAGER.submit(new oData("partner_code", beneficiary.getPartner().getCode()));

				ControllerFactory controllerFactory = new ControllerFactory();
				ServiceController controller = controllerFactory.payServiceController(info.getPartnerCode());

				if (controller == null) {
					StaticConfig.LOGMANAGER
							.submit(new oData("exception_stack_trace_partner_code", "Invalid partnerCode"));
					return;
				}

				Response response = controller.processRequest(requestId, data, profilerLog);
				StaticConfig.LOGMANAGER.submit(new oData("data_response", response.toJsonString()));

				profilerLog.doEndLog("wholerequest");
				StaticConfig.LOGMANAGER.submit(new oData("PROFILER_LOG", profilerLog.dumpScribeLog()));

				String code = response.getCode();
				StaticConfig.LOGMANAGER.getSimpleLogBuilder().setResponseCode(code);
			}
		} catch (Exception e) {
			StaticConfig.LOGMANAGER.getSimpleLogBuilder().setResponseCode(Constant.ERR_SYSTEM);
			StaticConfig.LOGMANAGER.submit(new oData("exception_stack_trace_doWork", ExceptionUtils.getStackTrace(e)));
		}
	}
}