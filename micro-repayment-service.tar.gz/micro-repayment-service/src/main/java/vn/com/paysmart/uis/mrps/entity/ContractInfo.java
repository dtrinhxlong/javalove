package vn.com.paysmart.uis.mrps.entity;

import com.google.gson.annotations.SerializedName;

public class ContractInfo {
	public String contractNo;
	public String customerName;
	public String dueDate;
	public Long overdueAmt;
	
	//FEC
	@SerializedName(value = "idNumber", alternate = {"idCardNumber"})
    private String idCardNumber;
    private String companyName;
    private Long amountOverdue;
    private String paymentDueDate;
    private String partnerCode;
    private String code;
    private String walletId;
    private String phoneNo;
    private String customerPhone;
    private Long cashbackAmount;
    private String type;
    
	public String getIdCardNumber() {
		return idCardNumber;
	}
	public void setIdCardNumber(String idCardNumber) {
		this.idCardNumber = idCardNumber;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public Long getAmountOverdue() {
		return amountOverdue;
	}
	public void setAmountOverdue(Long amountOverdue) {
		this.amountOverdue = amountOverdue;
	}
	public String getPaymentDueDate() {
		return paymentDueDate;
	}
	public void setPaymentDueDate(String paymentDueDate) {
		this.paymentDueDate = paymentDueDate;
	}
	public String getPartnerCode() {
		return partnerCode;
	}
	public void setPartnerCode(String partnerCode) {
		this.partnerCode = partnerCode;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
    public String getWalletId() {
        return walletId;
    }
    public void setWalletId(String walletId) {
        this.walletId = walletId;
    }
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getCustomerPhone() {
		return customerPhone;
	}
	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}
//	public String getMerchantId() {
//		return merchantId;
//	}
//	public void setMerchantId(String merchantId) {
//		this.merchantId = merchantId;
//	}
//	public String getMerchantType() {
//		return merchantType;
//	}
//	public void setMerchantType(String merchantType) {
//		this.merchantType = merchantType;
//	}
	public Long getCashbackAmount() {
		return cashbackAmount;
	}
	public void setCashbackAmount(Long cashbackAmount) {
		this.cashbackAmount = cashbackAmount;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getContractNo() {
		return contractNo;
	}
	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getDueDate() {
		return dueDate;
	}
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}
	public Long getOverdueAmt() {
		return overdueAmt;
	}
	public void setOverdueAmt(Long overdueAmt) {
		this.overdueAmt = overdueAmt;
	}
}
