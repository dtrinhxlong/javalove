package vn.com.paysmart.uis.mrps.controller;

import vn.com.paysmart.common.uis.entity.Response;
import vn.com.paysmart.common.uis.profiler.ProfilerLog;
import vn.com.paysmart.uis.mrps.entity.RequestData;

/**
 *
 * @author longdo
 */
public interface ServiceController {
	 Response processRequest(String requestId, RequestData data, ProfilerLog profilerLog) throws Exception;
}
