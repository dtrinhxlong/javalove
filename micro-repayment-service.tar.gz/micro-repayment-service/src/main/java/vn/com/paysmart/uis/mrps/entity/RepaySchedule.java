package vn.com.paysmart.uis.mrps.entity;

public class RepaySchedule {

    private String dueDate;

    private Long payable;

    private Long receivedCashbackAmount;

    private Long receivableCashbackAmount;

    private Long missedCashbackAmount;

    public RepaySchedule() {
    }

    public RepaySchedule(String dueDate, Long payable) {
        this.dueDate = dueDate;
        this.payable = payable;
    }

    public String getDueDate() {
        return dueDate;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    public Long getPayable() {
        return payable;
    }

    public void setPayable(Long payable) {
        this.payable = payable;
    }

    public Long getReceivedCashbackAmount() {
        return receivedCashbackAmount;
    }

    public void setReceivedCashbackAmount(Long receivedCashbackAmount) {
        this.receivedCashbackAmount = receivedCashbackAmount;
    }

    public Long getReceivableCashbackAmount() {
        return receivableCashbackAmount;
    }

    public void setReceivableCashbackAmount(Long receivableCashbackAmount) {
        this.receivableCashbackAmount = receivableCashbackAmount;
    }

    public Long getMissedCashbackAmount() {
        return missedCashbackAmount;
    }

    public void setMissedCashbackAmount(Long missedCashbackAmount) {
        this.missedCashbackAmount = missedCashbackAmount;
    }
}
