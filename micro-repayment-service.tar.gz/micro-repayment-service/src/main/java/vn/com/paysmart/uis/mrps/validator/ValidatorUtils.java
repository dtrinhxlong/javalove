package vn.com.paysmart.uis.mrps.validator;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.Base64;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.eclipse.jetty.util.StringUtil;
import org.everit.json.schema.Schema;
import org.everit.json.schema.ValidationException;
import org.everit.json.schema.loader.SchemaLoader;
import org.json.JSONObject;
import org.json.JSONTokener;
import vn.com.paysmart.common.uis.common.Config;
import vn.com.paysmart.common.uis.json.JsonObject;
import vn.com.paysmart.common.uis.utils.CryptoUtil;
import vn.com.paysmart.uis.mrps.client.thread.log.oData;
import vn.com.paysmart.uis.mrps.entity.Constant;
import vn.com.paysmart.uis.mrps.entity.ResponseCode;
import vn.com.paysmart.uis.mrps.util.CommonUtil;
import vn.com.paysmart.uis.mrps.util.StaticConfig;

public class ValidatorUtils implements Serializable {
    private static final long serialVersionUID = 1L;
    
    public static final String PATH = System.getProperty("apppath") + File.separator + "conf";
    public static final String SCHEMAFILE = "schema";
    public static final String REQ_PATH_SUB = "req";
    public static final String RESP_PATH_SUB = "resp";
    private static final String SUCCESS = "SUCCESS";
    private static final String VALIDATE_ERROR = "validate ERROR_ ";

    private static void parserResult(String service, JSONObject json, String pathSub)
            throws ValidationException, FileNotFoundException {
    	
    	String pathName = PATH + File.separator + SCHEMAFILE + File.separator + pathSub + ((!StringUtils.isEmpty(pathSub))?File.separator:"") + service + ".json";
    	InputStream inputStream = new FileInputStream(pathName);
    	
    	JSONObject jsonSchema = new JSONObject(new JSONTokener(inputStream));
        Schema schema = SchemaLoader.load(jsonSchema);
        schema.validate(json);
        try {
            inputStream.close();
        } catch (IOException ex) {
            StaticConfig.LOGMANAGER.submit(new oData("exception_stack_trace_parse_result", ExceptionUtils.getStackTrace(ex)));
        }
    }

    public static ResponseCode validateResponse(String schema, String data) {
        StringBuilder error_msg = validate(schema, data, RESP_PATH_SUB);
        if (error_msg.length() > 0) {
            StaticConfig.LOGMANAGER.submit(new oData(VALIDATE_ERROR, error_msg.toString()));
            return ResponseCode.INVALID_RESPONSE_DATA.addMessage(error_msg.toString());
        }
        return ResponseCode.SUCCESS.addMessage(SUCCESS);
    }

    public static ResponseCode validateRequest(String schema, String data, String callerId) {
        //check caller
        String callerKey = Config.getParam("app", callerId);
        if (StringUtil.isEmpty(callerKey)) {
            StaticConfig.LOGMANAGER.submit(new oData(VALIDATE_ERROR, "caller " + callerId + " is wrong"));
            return ResponseCode.INVALID_AUTHEN.addMessage("caller " + callerId + " is wrong");
        }
        
        //check data request
        StringBuilder error_msg = validate("micro-repayment-service", data, "");
        if (error_msg.length() > 0) {
            StaticConfig.LOGMANAGER.submit(new oData(VALIDATE_ERROR, error_msg.toString()));
            return ResponseCode.INVALID_REQUEST_DATA.addMessage(error_msg.toString());
        }
        
        JsonObject dataObj = null;
        try {
        	dataObj = JsonObject.parse(data);
        } catch (Exception e) {
        	return ResponseCode.INVALID_REQUEST_DATA.addMessage(data + " have character special before base64");
		}
        
        String encodeData = dataObj.getString(Constant.DATA);
        String checkSum = dataObj.getString(Constant.CHECK_SUM);
        
        // data passed as json
        boolean verify = verifyChecksum(encodeData, checkSum, callerKey);
        if (!verify) {
            return ResponseCode.INVALID_AUTHEN.addMessage("verify checksum fail");
        }
        
        //check format data
        error_msg = validate(schema, CommonUtil.decodeBase64(encodeData), REQ_PATH_SUB);
        if (error_msg.length() > 0) {
            StaticConfig.LOGMANAGER.submit(new oData(VALIDATE_ERROR, error_msg.toString()));
            return ResponseCode.INVALID_REQUEST_DATA.addMessage(error_msg.toString());
        }
        
        return ResponseCode.SUCCESS.addMessage(new String(Base64.getDecoder().decode(encodeData)));
    }

    private static StringBuilder validate(String schema, String data, String pathSub) {
        StringBuilder error_msg = new StringBuilder();
        try {
            parserResult(schema, new JSONObject(data), pathSub);
        } catch (ValidationException ex) {
            for (String err : ex.getAllMessages()) {
                error_msg.append(err);
            }
        } catch (Exception ex) {
            error_msg.append(ex.getMessage());
        }

        return error_msg;
    }

    private static boolean verifyChecksum(String data, String checkSum, String callerKey) {
        String encryptedSig = CryptoUtil.sha256(data + "|" + callerKey);
        return encryptedSig.equals(checkSum);
    }
}
