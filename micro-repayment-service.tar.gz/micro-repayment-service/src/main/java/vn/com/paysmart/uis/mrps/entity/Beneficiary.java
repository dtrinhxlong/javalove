package vn.com.paysmart.uis.mrps.entity;

public class Beneficiary {
	public String type;
	public Partner partner;
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Partner getPartner() {
		return partner;
	}
	public void setPartner(Partner partner) {
		this.partner = partner;
	}
	
}
