package vn.com.paysmart.uis.mrps.client;

import com.google.gson.JsonObject;
import vn.com.paysmart.common.uis.common.Config;
import vn.com.paysmart.common.uis.profiler.ProfilerLog;
import vn.com.paysmart.common.uis.utils.CryptoUtil;
import vn.com.paysmart.uis.mrps.client.thread.log.oData;
import vn.com.paysmart.uis.mrps.entity.Constant;
import vn.com.paysmart.uis.mrps.util.StaticConfig;

public class HttpClient {
	public static String getResponse(String url, String data, String requestId, String partner, String caller,
			ProfilerLog profilerLog) throws Exception {
	
		String checksum = CryptoUtil.sha256(data + "|" + Config.getParam(partner.toLowerCase()+"_service", "secret-key"));
		JsonObject reqData = new JsonObject();
		reqData.addProperty(Constant.DATA, data);
		reqData.addProperty(Constant.CHECK_SUM, checksum);
		
		StaticConfig.LOGMANAGER.submit(new oData("about_to_post_something_to", url));
		return StaticConfig.POOL_HTTP_CLIENT.doPost(url, reqData.toString(), requestId, caller, profilerLog);
	}
}
