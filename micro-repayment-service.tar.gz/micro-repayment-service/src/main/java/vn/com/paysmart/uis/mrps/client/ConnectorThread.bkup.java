//package vn.com.paysmart.uis.mrps.client;
//
//import java.io.IOException;
//import org.apache.commons.httpclient.HttpClient;
//import org.apache.commons.httpclient.HttpException;
//import org.apache.commons.httpclient.HttpStatus;
//import org.apache.commons.httpclient.StatusLine;
//import org.apache.commons.httpclient.methods.PostMethod;
//import org.apache.commons.httpclient.methods.StringRequestEntity;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//
//import vn.com.paysmart.common.uis.profiler.ProfilerLog;
//import vn.com.paysmart.uis.mrps.entity.Constant;
//
//public class ConnectorThread extends Thread {
//	private static final Logger LOGGER = LogManager.getLogger(ConnectorThread.class);
//	
//	private static final String CONTENT_TYPE = "application/json";
//	private final HttpClient httpClient;
//    private final PostMethod method;
//    private final String reqData;
//    private final String requestId;
//    private String respData;
//    private String caller;
//    private ProfilerLog profilerLog;
//
//	public ConnectorThread(HttpClient httpClient, PostMethod method, String name, String reqData, String requestId, String caller, ProfilerLog profilerLog) {
//        super(name);
//        this.httpClient = httpClient;
//        this.method = method;
//        this.reqData = reqData;
//        this.requestId = requestId;
//        this.caller = caller;
//        this.profilerLog = profilerLog;
//    }
//
//    @Override
//    public void run() {
//        try {
//        	LOGGER.info(Thread.currentThread().getName() + " - about to post something to "
//                    + method.getURI());
//        	this.profilerLog.doStartLog("getResponseFromService");
//            StringRequestEntity requestEntity = new StringRequestEntity(this.reqData, CONTENT_TYPE, "UTF-8");
//			
//            method.setRequestHeader("Accept", CONTENT_TYPE);
//            method.setRequestHeader("Content-Type", CONTENT_TYPE);
//            method.setRequestHeader(Constant.X_REQUEST_ID, this.requestId);
//            method.setRequestHeader(Constant.X_CALLER, this.caller);
//            method.setRequestEntity(requestEntity);
//            
//            // Execute the method.  
//            int statusCode = httpClient.executeMethod(method);
//            if (statusCode != HttpStatus.SC_OK) {
//            	LOGGER.error("Method failed: " + statusCode);
//            }
//
//            // Reading the status body.  
//            StatusLine statusLine = method.getStatusLine();
//            LOGGER.info(Thread.currentThread().getName() + " " + statusLine);
//            
//            this.respData = method.getResponseBodyAsString();
//            this.profilerLog.doEndLog("getResponseFromService");
//        } catch (HttpException e) {
//        	LOGGER.error("Fatal protocol violation_ ", e.getMessage());
//        } catch (IOException e) {
//        	LOGGER.error("Fatal transport error_ ", e.getMessage());
//        } finally {
//			method.releaseConnection();
//			LOGGER.info("releaseConnection_ Done.");
//		}
//    }
//    
//    public String getRespData() {
//		return respData;
//	}
//}