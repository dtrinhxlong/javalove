package vn.com.paysmart.uis.mrps.entity;

public class OperationName {
	public static final String GET_CONTRACT_INFO_V2 = "getcontractinfov2";
	public static final String QUERY_OF_PAYMENT = "queryofpayment";
    public static final String COLLECTION_MAFC = "collectionmafc";
}
