package vn.com.paysmart.uis.mrps.client.query;

import java.io.File;
import org.apache.commons.lang3.StringUtils;
import vn.com.paysmart.common.uis.common.Config;
import vn.com.paysmart.common.uis.entity.Response;
import vn.com.paysmart.common.uis.json.JsonArray;
import vn.com.paysmart.common.uis.json.JsonObject;
import vn.com.paysmart.common.uis.profiler.ProfilerLog;
import vn.com.paysmart.common.uis.utils.GsonUtil;
import vn.com.paysmart.uis.mrps.client.HttpClient;
import vn.com.paysmart.uis.mrps.client.thread.log.oData;
import vn.com.paysmart.uis.mrps.controller.ServiceController;
import vn.com.paysmart.uis.mrps.entity.ContractInfo;
import vn.com.paysmart.uis.mrps.entity.RequestData;
import vn.com.paysmart.uis.mrps.entity.ResponseCode;
import vn.com.paysmart.uis.mrps.util.CommonUtil;
import vn.com.paysmart.uis.mrps.util.StaticConfig;

public class Cash24QueryProcessor implements ServiceController {
	public static final String QUERY_OF_PAYMENT = "queryofpayment";
	private static final String URL = Config.getParam("cash24_service", "base_url") + File.separator + QUERY_OF_PAYMENT;
	private static final String CALLER = Config.getParam("micro_service", "caller");

	@Override
	public Response processRequest(String requestId, RequestData data, ProfilerLog profilerLog) throws Exception {

		JsonObject dataObj = new JsonObject();
		dataObj.addProperty("accNo", data.getContractNo());
		dataObj.addProperty("phoneNo", data.getPhone());
		dataObj.addProperty("walletId", data.getWalletId());
		StaticConfig.LOGMANAGER.submit(new oData("reqData", dataObj.toString()));

		String resp = HttpClient.getResponse(URL, CommonUtil.genBase64(dataObj.toString()), requestId, "micro", CALLER,
				profilerLog);
		StaticConfig.LOGMANAGER.submit(new oData("respData", resp));

		if (StringUtils.isEmpty(resp)) {
			return new Response(ResponseCode.FAIL.name()).setMessage("don't have response");
		}

		JsonObject respObj = JsonObject.parse(resp);
		if (respObj.getString("code").equals("FAIL")) {
			return new Response(respObj.getString("code")).setMessage(respObj.getString("message"));
		}
		String decrypt = CommonUtil.decodeBase64(respObj.getString("data"));
		JsonArray contractInfos = new JsonArray();

		for (int i = 0; i < JsonObject.parse(decrypt).getArray("contractList").size(); i++) {
			JsonObject list = JsonObject.parse(decrypt).getArray("contractList").getObject(i);
			String contractInfo = list.getObject("contractInfo").toString();
			ContractInfo obj = GsonUtil.fromJson(contractInfo, ContractInfo.class);
			obj.setPartnerCode(data.getPartnerCode());
			obj.setIdCardNumber("");

			contractInfos.add(JsonObject.parse(GsonUtil.toJsonString(obj)));
		}
		JsonObject fn = new JsonObject();
		fn.add("contractInfo", contractInfos);

		return new Response(respObj.getString("code")).setData(CommonUtil.genBase64(fn.toString()))
				.setMessage(respObj.getString("message"));
	}

}
