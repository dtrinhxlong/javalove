package vn.com.paysmart.uis.mrps.entity;
