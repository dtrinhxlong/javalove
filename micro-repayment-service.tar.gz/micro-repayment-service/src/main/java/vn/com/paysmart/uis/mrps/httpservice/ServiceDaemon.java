package vn.com.paysmart.uis.mrps.httpservice;

import java.io.File;
import java.io.InputStream;
import org.apache.logging.log4j.Logger;
import vn.com.paysmart.common.queue.QueueConfig;
import vn.com.paysmart.common.queue.RabbitMQConfig;
import vn.com.paysmart.common.uis.common.Config;
import vn.com.paysmart.common.uis.common.LogUtil;
import vn.com.paysmart.logging.SingletonLogWriter;
import vn.com.paysmart.logging.kafka.LogWriter;
import vn.com.paysmart.logging.kafka.LogWriterConfig;
import vn.com.paysmart.uis.mrps.consumer.RepaymentRouting;
import vn.com.paysmart.uis.mrps.util.StaticConfig;

/**
 *
 * @author longdo
 */
public class ServiceDaemon {
    private static final Logger LOGGER = LogUtil.getLogger(ServiceDaemon.class.getSimpleName());
    
    public static void main(String[] args) {
        try {
            LogUtil.init();

            StaticConfig.initClassLoader();

            initRabbitMQConfig();

            initKafkaConfig();

            String pidFile = System.getProperty("pidfile");
            if (pidFile != null) {
                new File(pidFile).deleteOnExit();
            }

            try {
                InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream("git.properties");
                java.util.Properties prop = new java.util.Properties();
                prop.load(is);
                LOGGER.info("Bitbucket revision: " + prop.getProperty("git.branch"));
                LOGGER.info("Bitbucket commitId: " + prop.getProperty("git.commit.id"));
            } catch (Exception e) {
                LOGGER.error(e.getMessage(), e);
            }

            WebServer webServer = new WebServer();
            Thread thread0 = new Thread(webServer);
            thread0.setName("httpservice_thread");
            thread0.start();

            LOGGER.info("consumerName_ " + StaticConfig.RABBIT_MQ_QUEUE_DELIVER);
            RepaymentRouting repaymentDeliver = new RepaymentRouting();
            Thread thread = new Thread(repaymentDeliver);
            thread.start();

        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
    }

    private static void initRabbitMQConfig() throws Exception {
        RabbitMQConfig rabbitMQConfig = new RabbitMQConfig(StaticConfig.RABBIT_MQ_HOST, StaticConfig.RABBIT_MQ_PORT,
                StaticConfig.RABBIT_MQ_USERNAME, StaticConfig.RABBIT_MQ_PASSWORD, "/", StaticConfig.RABBIT_MQ_POOL_SIZE,
                StaticConfig.RABBIT_MQ_AUTO_ACK, StaticConfig.RABBIT_MQ_PREFETCH_SIZE);
        QueueConfig.initConfig(StaticConfig.RABBIT_MQ_NAME, rabbitMQConfig);
    }

    private static void initKafkaConfig() throws Exception {
        String kafkaSec = "kafka";
        String kafkaServers = Config.getParam(kafkaSec, "servers");
        String kafkaClientId = Config.getParam(kafkaSec, "client-id");
        LogWriterConfig.Builder b = new LogWriterConfig.Builder().setClientId(kafkaClientId)
                .setTopic(System.getProperty("application.name"));
        String[] serversArr = kafkaServers.split(",");
        for (String server : serversArr) {
            String[] s = server.split(":");
            b.addHostPort(s[0], Integer.parseInt(s[1]));
        }
        SingletonLogWriter.Instance.registerWriter(new LogWriter(b.build()));
    }
}
