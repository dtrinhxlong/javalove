package vn.com.paysmart.uis.mrps.util;

import java.io.InputStream;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import vn.com.paysmart.common.uis.common.Config;
import vn.com.paysmart.uis.mrps.client.PoolingHttpClient;
import vn.com.paysmart.uis.mrps.client.thread.log.GLogManager;

/**
 * @author longdo
 */
public class StaticConfig {
	private static final Logger LOGGER = LogManager.getLogger(StaticConfig.class);

	public static final String APPLICATION_NAME = System.getProperty("application.name", "dev.MicroRepaymentService");
	public static final String RABBIT_MQ_NAME = "rabbitmq";
	public static final String RABBIT_MQ_HOST = Config.getParam(RABBIT_MQ_NAME, "host");
	public static final int RABBIT_MQ_PORT = Integer.parseInt(Config.getParam(RABBIT_MQ_NAME, "port"));
	public static final String RABBIT_MQ_USERNAME = Config.getParam(RABBIT_MQ_NAME, "username");
	public static final String RABBIT_MQ_PASSWORD = Config.getParam(RABBIT_MQ_NAME, "password");
	public static final int RABBIT_MQ_POOL_SIZE = Integer.parseInt(Config.getParam(RABBIT_MQ_NAME, "thread-pool-size"));
	public static final int RABBIT_MQ_PREFETCH_SIZE = Integer
			.parseInt(Config.getParam(RABBIT_MQ_NAME, "prefetch-count"));
	public static final boolean RABBIT_MQ_AUTO_ACK = Boolean.parseBoolean(Config.getParam(RABBIT_MQ_NAME, "auto-ack"));

	public static final String RABBIT_MQ_EXCHANGE = Config.getParam(RABBIT_MQ_NAME, "exchange");
	public static final String RABBIT_MQ_ROUTING_KEY = Config.getParam(RABBIT_MQ_NAME, "routing-key");
	public static final String RABBIT_MQ_QUEUE_DELIVER = Config.getParam(RABBIT_MQ_NAME, "queue-deliver");
	public static final String APP_NAME = "app";

	public static String GIT_REVISION = "";
	public static String GIT_COMMIT_ID = "";
	
	public static boolean APP_ENABLE_DEBUG = Integer.parseInt(Config.getParam("app", "enable-debug"))==1;
	
	public static final String JETTY = "jetty";
	public static final int JETTY_MIN_THREADS = Integer.parseInt(Config.getParam(JETTY, "minthreads"));
	public static final int JETTY_MAX_QUEUED = Integer.parseInt(Config.getParam(JETTY, "maxqueued"));
	public static final int JETTY_MAX_THREADS = Integer.parseInt(Config.getParam(JETTY, "maxthreads"));
	public static final int JETTY_IDE_TIMEOUT = Integer.parseInt(Config.getParam(JETTY, "idetimeout"));
	public static final String JETTY_NAME = Config.getParam(JETTY, "name");
	
	public static final PoolingHttpClient POOL_HTTP_CLIENT = new PoolingHttpClient();
	public static GLogManager LOGMANAGER = new GLogManager();
	static {
		try {
			InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream("git.properties");
			java.util.Properties prop = new java.util.Properties();
			prop.load(is);
			GIT_REVISION = prop.getProperty("git.branch");
			GIT_COMMIT_ID = prop.getProperty("git.commit.id");
			
			LOGMANAGER.listen();
		} catch (Exception e) {
			 LOGGER.error(e.getMessage(), e);
		}
	}

	public static void initClassLoader() {
		LOGGER.info("Init class loader ...");
	}
}