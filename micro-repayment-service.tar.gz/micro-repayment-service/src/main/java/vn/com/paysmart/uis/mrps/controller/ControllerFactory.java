package vn.com.paysmart.uis.mrps.controller;

import vn.com.paysmart.uis.mrps.client.payment.Cash24Processor;
import vn.com.paysmart.uis.mrps.client.payment.MafcProcessor;
import vn.com.paysmart.uis.mrps.client.query.Cash24QueryProcessor;
import vn.com.paysmart.uis.mrps.client.query.FECQueryProcessor;
import vn.com.paysmart.uis.mrps.client.query.MafcQueryProcessor;

/**
 *
 * @author longdo
 */
public class ControllerFactory {

	private static final String FEC = "FEC";

	private static final String CASH24 = "CASH24";

	private static final String MAFC = "MAFC";

	public ServiceController payServiceController(String partnerCode) {
		ServiceController serviceController = null;
		switch (partnerCode) {
		case FEC:
			break;
		case CASH24:
			serviceController = new Cash24Processor(); // Sprint 39 : cash24 chưa chạy -- nên comment lại
			break;
		case MAFC:
			serviceController = new MafcProcessor();
			break;
		default:
			break;
		}
		return serviceController;
	}

	public ServiceController queryServiceController(String partnerCode) {
		ServiceController serviceController = null;
		switch (partnerCode) {
		case FEC:
			serviceController = new FECQueryProcessor();
			break;
		case CASH24:
			serviceController = new Cash24QueryProcessor(); // Sprint 39 : cash24 chưa chạy -- nên comment lại
			break;
		case MAFC:
			serviceController = new MafcQueryProcessor();
			break;
		default:
			break;
		}
		return serviceController;
	}
}