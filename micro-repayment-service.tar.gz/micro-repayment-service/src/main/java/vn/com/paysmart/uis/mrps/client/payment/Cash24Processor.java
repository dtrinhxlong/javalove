package vn.com.paysmart.uis.mrps.client.payment;

import java.io.File;
import org.apache.commons.lang.StringUtils;
import vn.com.paysmart.common.uis.common.Config;
import vn.com.paysmart.common.uis.entity.Response;
import vn.com.paysmart.common.uis.json.JsonObject;
import vn.com.paysmart.common.uis.profiler.ProfilerLog;
import vn.com.paysmart.uis.mrps.client.HttpClient;
import vn.com.paysmart.uis.mrps.client.thread.log.oData;
import vn.com.paysmart.uis.mrps.controller.ServiceController;
import vn.com.paysmart.uis.mrps.entity.Beneficiary;
import vn.com.paysmart.uis.mrps.entity.OrderInfo;
import vn.com.paysmart.uis.mrps.entity.RequestData;
import vn.com.paysmart.uis.mrps.entity.ResponseCode;
import vn.com.paysmart.uis.mrps.util.CommonUtil;
import vn.com.paysmart.uis.mrps.util.StaticConfig;

public class Cash24Processor implements ServiceController {
	public static final String NOTICE_OF_PAYMENT = "noticeofpayment";

	private static final String URL = Config.getParam("cash24_service", "base_url") + File.separator
			+ NOTICE_OF_PAYMENT;

	private static final String CALLER = Config.getParam("cash24_service", "caller");

	@Override
	public Response processRequest(String requestId, RequestData data, ProfilerLog profilerLog) throws Exception {
		OrderInfo contractInfo = data.getOrderInfo();
		Beneficiary beneficiary = contractInfo.getBeneficiary();

		JsonObject dataObj = new JsonObject();
		dataObj.addProperty("accNo", contractInfo.getContractNo());
		dataObj.addProperty("customerName", contractInfo.getBorrowerName());
		dataObj.addProperty("customerPhone",
				(StringUtils.isEmpty(contractInfo.getCustomerPhone())) ? null : contractInfo.getCustomerPhone());
		dataObj.addProperty("phoneNo", data.getPhone());
		dataObj.addProperty("walletId", data.getWalletId());
		dataObj.addProperty("transId", data.getRefNo());
		dataObj.addProperty("transAmount", data.getPayAmt());
		dataObj.addProperty("rrn", data.getRRN());
		dataObj.addProperty("transTime", data.getTransDate());

		StaticConfig.LOGMANAGER.submit(new oData("reqData", dataObj.toString()));

		String resp = HttpClient.getResponse(URL, CommonUtil.genBase64(dataObj.toString()), requestId,
				beneficiary.getPartner().getCode(), CALLER, profilerLog);
		if (StringUtils.isEmpty(resp)) {
			return new Response(ResponseCode.FAIL.name()).setMessage("don't have response");
		}

		JsonObject respObj = JsonObject.parse(resp);
		return new Response(respObj.getString("code")).setData(respObj.getString("data"))
				.setMessage(respObj.getString("message"));
	}
}