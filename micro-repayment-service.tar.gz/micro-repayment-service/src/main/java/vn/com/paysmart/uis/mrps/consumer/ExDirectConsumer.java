//package vn.com.paysmart.uis.mrps.consumer;
//
//import com.rabbitmq.client.AMQP;
//import com.rabbitmq.client.BuiltinExchangeType;
//import java.io.IOException;
//import com.rabbitmq.client.Channel;
//import com.rabbitmq.client.Connection;
//import com.rabbitmq.client.Consumer;
//import com.rabbitmq.client.Envelope;
//import com.rabbitmq.client.ShutdownSignalException;
//import java.util.Arrays;
//import java.util.List;
//import java.util.concurrent.ExecutorService;
//import java.util.concurrent.Executors;
//import java.util.concurrent.TimeoutException;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import vn.com.paysmart.common.queue.QueueConfig;
//import vn.com.paysmart.common.queue.RabbitMQConfig;
//import vn.com.paysmart.common.queue.RabbitMQConnection;
//import vn.com.paysmart.common.queue.ShutdownThread;
//
///**
// *
// * @author longdo
// */
//public abstract class ExDirectConsumer implements Runnable, Consumer {
//
//    private static final Logger LOGGER = LoggerFactory.getLogger(RepaymentRouting.class);
//
//    private boolean autoAck = false;
//    private ExecutorService executorService = Executors.newFixedThreadPool(4);
//
//    private Channel channel;
//    protected String queueName;
//
//    public ExDirectConsumer(String instanceName, String exchangeName, String routingKeys, String queueName) throws Exception {
//        Connection connection = RabbitMQConnection.getInstance(instanceName).getConnection();
//        if (connection == null) {
//            throw new RuntimeException(instanceName + " - Rabbit MQ connection failed.");
//        }
//
//        this.queueName = queueName;
//        channel = connection.createChannel();
//
//        RabbitMQConfig rabbitMQConfig = QueueConfig.getConfig(instanceName);
//        if (rabbitMQConfig != null) {
//            executorService = Executors.newFixedThreadPool(rabbitMQConfig.getPoolSize());
//            channel.basicQos(rabbitMQConfig.getPrefetchCount());
//            autoAck = rabbitMQConfig.isAutoAck();
//        }
//
//        channel.exchangeDeclare(exchangeName, BuiltinExchangeType.DIRECT, true);
//        channel.queueDeclare(queueName, true, false, false, null);
//        List<String> keys = Arrays.asList(routingKeys.split(","));
//        for (String routingKey : keys) {
//            channel.queueBind(queueName, exchangeName, routingKey);
//        }
//
//        LOGGER.info("ExchangeName " + exchangeName + " registered");
//    }
//
//    @Override
//    public void run() {
//        try {
//            channel.basicConsume(queueName, autoAck, this);
//        } catch (IOException ex) {
//            LOGGER.error("run_exception_ ", ex);
//        }
//        ShutdownThread shutdownConsumer = new ShutdownThread(executorService, 60);
//        Runtime.getRuntime().addShutdownHook(shutdownConsumer);
//        LOGGER.info("Registered shutdownhook - Exchange consumer.");
//    }
//
//    @Override
//    public void handleConsumeOk(String consumerTag) {
//        LOGGER.info("Consumer " + consumerTag + " registered");
//    }
//
//    @Override
//    public void handleCancelOk(String consumerTag) {
//    }
//
//    @Override
//    public void handleCancel(String consumerTag) throws IOException {
//    }
//
//    @Override
//    public void handleShutdownSignal(String consumerTag, ShutdownSignalException sig) {
//    }
//
//    @Override
//    public void handleRecoverOk(String consumerTag) {
//    }
//
//    @Override
//    public void handleDelivery(String consumerTag, Envelope envelope, AMQP.BasicProperties properties, byte[] body) throws IOException {
//        executorService.execute(() -> {
//            try {
//                this.handleMessage(consumerTag, envelope, properties, body);
//            } catch (IOException e) {
//                //LOGGER.error("Exception.msg=" + e.getMessage(), e);
//            }
//        });
//    }
//
//    private void handleMessage(String consumerTag, Envelope envlp, AMQP.BasicProperties bp, byte[] body) throws IOException {
//        try {
//            doWork(body);
//        } finally {
//            if (!autoAck) {
//                channel.basicAck(envlp.getDeliveryTag(), false);
//            }
//        }
//    }
//
//    public abstract void doWork(byte[] bodyMessage);
//
//    /**
//     * @throws IOException
//     * @throws java.util.concurrent.TimeoutException
//     */
//    protected void close() throws IOException, TimeoutException {
//        if (this.channel != null && this.channel.isOpen()) {
//            this.channel.close();
//        }
//    }
//
//}
