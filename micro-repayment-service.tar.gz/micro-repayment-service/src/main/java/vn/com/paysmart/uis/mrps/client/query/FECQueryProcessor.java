package vn.com.paysmart.uis.mrps.client.query;

import java.io.File;
import java.text.SimpleDateFormat;
import com.google.gson.Gson;
import com.google.gson.JsonParser;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import org.apache.commons.lang.StringUtils;
import vn.com.paysmart.common.uis.common.Config;
import vn.com.paysmart.common.uis.entity.Response;
import vn.com.paysmart.common.uis.json.JsonArray;
import vn.com.paysmart.common.uis.json.JsonObject;
import vn.com.paysmart.common.uis.profiler.ProfilerLog;
import vn.com.paysmart.common.uis.utils.CryptoUtil;
import vn.com.paysmart.common.uis.utils.GsonUtil;
import vn.com.paysmart.uis.mrps.client.thread.log.oData;
import vn.com.paysmart.uis.mrps.controller.ServiceController;
import vn.com.paysmart.uis.mrps.entity.Constant;
import vn.com.paysmart.uis.mrps.entity.ContractInfo;
import vn.com.paysmart.uis.mrps.entity.RequestData;
import vn.com.paysmart.uis.mrps.entity.ResponseCode;
import vn.com.paysmart.uis.mrps.util.CommonUtil;
import vn.com.paysmart.uis.mrps.util.StaticConfig;

public class FECQueryProcessor implements ServiceController {

	public static final String QUERY_CONTRACT = "getcontractinfov2";

	private static final String FEC_SEC_CONF = "fec_service";

	private static final String REQ_ID = "reqId: ";

	private static final String PARTNER_CODE_2 = " - partnerCode: ";

	private static final String CONTRACT_NO = " - contractNo: ";

	private static final String PARTNER_CODE = "FEC";

	private static final String URL = Config.getParam(FEC_SEC_CONF, "base_url") + File.separator + QUERY_CONTRACT;

	private static final String CALLER = Config.getParam(FEC_SEC_CONF, "caller");

	private static final String SECRET_KEY = Config.getParam(FEC_SEC_CONF, "secret-key");

	@Override
	public Response processRequest(String requestId, RequestData data, ProfilerLog profilerLog) throws Exception {
		ContractInfo contract = getContractInfo(requestId, data.getWalletId(), data.getPhone(), data.getContractNo(),
				profilerLog);
		if (contract == null) {
			return new Response(ResponseCode.FAIL.name()).setMessage("don't have response");
		}
		StaticConfig.LOGMANAGER.submit(new oData("respData", GsonUtil.toJsonString(contract)));
		JsonObject json = new JsonObject();
		JsonArray contractInfos = new JsonArray();
		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
		if (contract.getCode().equals("OK")) {
			json.addProperty("contractNo", contract.getContractNo());
			json.addProperty("customerName", contract.getCustomerName());
			json.addProperty("dueDate",
					format.format(new SimpleDateFormat("yyyy-MM-dd").parse(contract.getPaymentDueDate())));
			json.addProperty("overdueAmt", contract.getAmountOverdue());
			json.addProperty("cashbackAmount", contract.getCashbackAmount());
			json.addProperty("partnerCode", data.getPartnerCode());
			json.addProperty("idNumber", contract.getIdCardNumber());
		}
		contractInfos.add(json);
		JsonObject fn = new JsonObject();
		fn.add("contractInfo", contractInfos);
		return new Response(contract.getCode().equals("OK") ? ResponseCode.SUCCESS.name() : ResponseCode.FAIL.name())
				.setData(CommonUtil.genBase64(fn.toString()));
	}

	public ContractInfo getContractInfo(String reqId, String eWalletId, String phoneNo, String contractNo,
			ProfilerLog profilerLog) throws Exception {
		String f = "getContractInfo_";
		String reqData = buildGetContractInfoData(reqId, eWalletId, phoneNo, contractNo);
		StaticConfig.LOGMANAGER.submit(new oData(f + Constant.REQ_DATA, reqData));

		String respData = StaticConfig.POOL_HTTP_CLIENT.doPost(URL, reqData, reqId, "FEC", profilerLog);
		StaticConfig.LOGMANAGER.submit(new oData(f + Constant.RESP_DATA, respData));

		ContractInfo contractInfo = null;
		if (StringUtils.isNotBlank(respData)) {
			JsonParser jsonParser = new JsonParser();
			com.google.gson.JsonObject joResp = jsonParser.parse(respData) == null ? null
					: jsonParser.parse(respData).getAsJsonObject();
			if (joResp != null) {
				String code = joResp.get(Constant.CODE) == null ? Constant.EMP_ERROR
						: joResp.get(Constant.CODE).getAsString();
				contractInfo = process(code, joResp, reqId, contractNo, f);
				if (contractInfo != null) {
					contractInfo.setCode(code);
				} else {
					contractInfo = new ContractInfo();
					contractInfo.setCode(code);
				}
			} else {
				StaticConfig.LOGMANAGER.submit(new oData(f + Constant.MSG,  REQ_ID + reqId + PARTNER_CODE_2 + PARTNER_CODE + CONTRACT_NO
						+ CommonUtil.maskString6F4L(contractNo) + " - invalid format response"));
			}
		} else {
			StaticConfig.LOGMANAGER.submit(new oData(f + Constant.MSG, REQ_ID + reqId + PARTNER_CODE_2 + PARTNER_CODE + CONTRACT_NO
					+ CommonUtil.maskString6F4L(contractNo) + " - null or empty response"));
		}
		return contractInfo;
	}

	public ContractInfo process(String code, com.google.gson.JsonObject joResp, String reqId,
			String contractNo, String f) {
		ContractInfo contractInfo = null;
		if (Constant.OK.equals(code)) {
			// field name as SIGNATURE but actually it is checksum
			String respCks = joResp.get(Constant.SIGNATURE) == null ? null
					: joResp.get(Constant.SIGNATURE).getAsString();

			String dataBase64 = joResp.get(Constant.DATA) == null ? null : joResp.get(Constant.DATA).getAsString();
			if (StringUtils.isNotBlank(dataBase64)) {
				String cks = CryptoUtil.sha256(dataBase64 + "|" + SECRET_KEY);
				if (cks.equals(respCks)) {
					String data = new String(Base64.getDecoder().decode(dataBase64));
					contractInfo = new Gson().fromJson(data, ContractInfo.class);
				} else {
					StaticConfig.LOGMANAGER.submit(new oData(f + Constant.MSG, REQ_ID + reqId + PARTNER_CODE_2 + PARTNER_CODE + CONTRACT_NO
							+ CommonUtil.maskString6F4L(contractNo) + " invalid checksum"));
				}
			} else {
				StaticConfig.LOGMANAGER.submit(new oData(f + Constant.MSG,  REQ_ID + reqId + PARTNER_CODE_2 + PARTNER_CODE + CONTRACT_NO
						+ CommonUtil.maskString6F4L(contractNo) + " null or empty data"));
			}
		} else {
			StaticConfig.LOGMANAGER.submit(new oData(f + Constant.MSG, REQ_ID + reqId + PARTNER_CODE_2 + PARTNER_CODE + CONTRACT_NO
					+ CommonUtil.maskString6F4L(contractNo) + " - code: " + code));
		}
		return contractInfo;
	}

	private String buildGetContractInfoData(String reqId, String walletId, String phoneNo, String contractNo)
			throws Exception {
		com.google.gson.JsonObject data = new com.google.gson.JsonObject();
		data.addProperty(Constant.REQUEST_ID, reqId);
		data.addProperty(Constant.WALLET_ID, walletId);
		data.addProperty(Constant.PHONE_NO, phoneNo);
		data.addProperty(Constant.CONTRACT_NO, contractNo);
		String dataBase64 = Base64.getEncoder().encodeToString(data.toString().getBytes(StandardCharsets.UTF_8));
		String cks = CryptoUtil.sha256(dataBase64 + "|" + SECRET_KEY);
		com.google.gson.JsonObject jo = new com.google.gson.JsonObject();
		jo.addProperty(Constant.DATA, dataBase64);
		jo.addProperty(Constant.CALLER, CALLER);
		jo.addProperty(Constant.CHECK_SUM, cks);
		return jo.toString();
	}
}
