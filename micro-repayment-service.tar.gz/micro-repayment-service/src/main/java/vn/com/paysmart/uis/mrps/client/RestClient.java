//package vn.com.paysmart.uis.mrps.client;
//
//import org.apache.commons.httpclient.HostConfiguration;
//import org.apache.commons.httpclient.HttpClient;
//import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
//import org.apache.commons.httpclient.methods.PostMethod;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//import vn.com.paysmart.common.uis.common.Config;
//import vn.com.paysmart.common.uis.profiler.ProfilerLog;
//
///**
// *
// * @author longdo
// */
//public final class RestClient {
//	private static final Logger LOGGER = LogManager.getLogger(RestClient.class);
//	private static final String APP = "app";
//
//	public static String httpClientQueue(String url, String data, String requestId, String caller, ProfilerLog profilerLog) {
//		MultiThreadedHttpConnectionManager connectionManager = new MultiThreadedHttpConnectionManager();
//		HttpClient client = new HttpClient(connectionManager);
//		try {
//			boolean enableProxy = (Config.getIntParam(APP, "enable-proxy") == 1);
//			if (enableProxy) {
//				HostConfiguration config = client.getHostConfiguration();
//				String proxyH = System.getProperty("http.proxyHost");
//				int proxyP = Integer.parseInt(System.getProperty("http.proxyPort"));
//				config.setProxy(proxyH, proxyP);
//			}
//		} catch (Exception e) {
//			LOGGER.error(e.getMessage(), e);
//			return null;
//		}
//
//		// and tn from inside some thread executing a method
//		PostMethod post = new PostMethod(url);
//		try {
//			// execute thread
//			ConnectorThread thread = new ConnectorThread(client, post, "Micro Repayment Service Connector Thread", data, requestId, caller, profilerLog);
//			thread.setDaemon(true);
//			thread.start();
//			// tunnel response
//			thread.join();
//			return thread.getRespData();
//		} catch (Exception ex) {
//			LOGGER.error(ex.getMessage(), ex);
//			return null;
//		}
//	}
//}