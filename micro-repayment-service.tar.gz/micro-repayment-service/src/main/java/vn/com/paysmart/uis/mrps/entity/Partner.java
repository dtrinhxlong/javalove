package vn.com.paysmart.uis.mrps.entity;

public class Partner {
	public String code;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	
}
