package vn.com.paysmart.uis.mrps.entity;

/**
 *
 * @author longdo
 */
public enum ResponseCode {
	SUCCESS,
    FAIL,
    INVALID_REQUEST,
    INVALID_AUTHEN,
    INVALID_REQUEST_DATA,
    INVALID_RESPONSE_DATA,
    INVALID_AUTHEN_RESPONSE,
    INVALID_SYSTEM_TRACE,
    INVALID_SERVICE_CODE,
    INVALID_PAYMENT_ID,
    INVALID_TRANS_ID,
    INVALID_AGENT_ID,
    API_NOT_SUPPORTED,
    PARTNER_CODE_NOT_SUPPORTED,
    TRANSACTION_NOT_FOUND,
    CHANNEL_NOT_SUPPORTED,
    TIMEOUT,
    SYSTEM_ERROR;
	
	private String message = "";
    public ResponseCode addMessage(String message) {
        this.message = message;
        return this;
    }
	public String getMessage() {
		return message;
	}
}