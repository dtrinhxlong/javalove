package vn.com.paysmart.uis.mrps.entity;

public class Constant {
	public static final String DATA = "data";
	public static final String CALLER = "caller";
	public static final String CHECK_SUM = "checksum";
	public static final String X_REQUEST_ID = "X-Request-ID";
	public static final String X_CALLER = "X-Caller";
	public static final String X_PARTNER = "X-Partner";
	public static final String ERR_SYSTEM = "ERR_SYSTEM";
	
	public static final String REQ_DATA = "reqData";
    public static final String RESP_DATA = "respData";
    public static final String RESP_CODE = "respCode";
    
    public static final String SIGNATURE = "signature";
    public static final String CODE = "code";
    public static final String MSG = "msg";
    public static final String REQUEST_ID = "requestId";
    public static final String WALLET_ID = "walletId";
    public static final String PHONE_NO = "phoneNo";
    public static final String CONTRACT_NO = "contractNo";
    
    public static final String EMP_ERROR = "EMP_ERROR";
    public static final String OK = "OK";
    public static final String PARTNER_CODE = "partnerCode";
    
    public static final String CONTENT_TYPE = "Content-Type";
    public static final String CONTENT_LENGTH = "Content-Length";
}
