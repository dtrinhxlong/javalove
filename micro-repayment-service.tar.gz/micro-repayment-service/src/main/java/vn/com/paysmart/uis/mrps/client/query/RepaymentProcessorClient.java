//package vn.com.paysmart.uis.mrps.client.query;
//
//import com.google.gson.Gson;
//import com.google.gson.JsonObject;
//import com.google.gson.JsonParser;
//import java.nio.charset.StandardCharsets;
//import java.util.Base64;
//import org.apache.commons.lang.StringUtils;
//import vn.com.paysmart.common.uis.log.LogBuilder;
//import vn.com.paysmart.common.uis.utils.CryptoUtil;
//import vn.com.paysmart.uis.mrps.client.RestClient;
//import vn.com.paysmart.uis.mrps.entity.Constant;
//import vn.com.paysmart.uis.mrps.entity.ContractInfo;
//import vn.com.paysmart.uis.mrps.util.CommonUtil;
//
///**
// *
// * @author longdo
// */
//public class RepaymentProcessorClient {
//	private String url;
//	private String caller;
//	private String secretKey;
//	private String partnerCode = "FEC";
//	
//	private String req_id = "reqId: ";
//	private String partner_code = " - partnerCode: ";
//	private String contract_no = " - contractNo: ";
//
//	public ContractInfo getContractInfo(String reqId, String eWalletId, String phoneNo, String contractNo,
//			LogBuilder logBuilder) throws Exception {
//		String f = "getContractInfo_";
//		String reqData = buildGetContractInfoData(reqId, eWalletId, phoneNo, contractNo);
//		logBuilder.append(f + Constant.REQ_DATA, reqData);
//
//		String respData = RestClient.httpClientQueue(url, reqData, reqId, "FEC");
//		logBuilder.append(f + Constant.RESP_DATA, respData);
//
//		ContractInfo contractInfo = null;
//
//		if (StringUtils.isNotBlank(respData)) {
//			JsonParser jsonParser = new JsonParser();
//			JsonObject joResp = jsonParser.parse(respData) == null ? null
//					: jsonParser.parse(respData).getAsJsonObject();
//			if (joResp != null) {
//				String code = joResp.get(Constant.CODE) == null ? Constant.EMP_ERROR
//						: joResp.get(Constant.CODE).getAsString();
//				
//				contractInfo = process(code, joResp, logBuilder, reqId, contractNo, f);
//				
//				if (contractInfo != null) {
//					contractInfo.setCode(code);
//				} else {
//					contractInfo = new ContractInfo();
//					contractInfo.setCode(code);
//				}
//			} else {
//				logBuilder.append(f + Constant.MSG, req_id + reqId + partner_code + partnerCode
//						+ contract_no + CommonUtil.maskString6F4L(contractNo) + " - invalid format response");
//			}
//		} else {
//			logBuilder.append(f + Constant.MSG, req_id + reqId + partner_code + partnerCode + contract_no
//					+ CommonUtil.maskString6F4L(contractNo) + " - null or empty response");
//		}
//		return contractInfo;
//	}
//	
//	public ContractInfo process(String code, JsonObject joResp, LogBuilder logBuilder,
//			String reqId, String contractNo, String f) {
//		
//		ContractInfo contractInfo = null;
//		if (Constant.OK.equals(code)) {
//			// field name as SIGNATURE but actually it is checksum
//			String respCks = joResp.get(Constant.SIGNATURE) == null ? null
//					: joResp.get(Constant.SIGNATURE).getAsString();
//			
//			String dataBase64 = joResp.get(Constant.DATA) == null ? null
//					: joResp.get(Constant.DATA).getAsString();
//			if (StringUtils.isNotBlank(dataBase64)) {
//				String cks = CryptoUtil.sha256(dataBase64 + "|" + secretKey);
//				if (cks.equals(respCks)) {
//					String data = new String(Base64.getDecoder().decode(dataBase64));
//					contractInfo = new Gson().fromJson(data, ContractInfo.class);
//				} else {
//					logBuilder.append(f + Constant.MSG, req_id + reqId + partner_code + partnerCode
//							+ contract_no + CommonUtil.maskString6F4L(contractNo) + " invalid checksum");
//				}
//			} else {
//				logBuilder.append(f + Constant.MSG, req_id + reqId + partner_code + partnerCode
//						+ contract_no + CommonUtil.maskString6F4L(contractNo) + " null or empty data");
//			}
//		} else {
//			logBuilder.append(f + Constant.MSG, req_id + reqId + partner_code + partnerCode
//					+ contract_no + CommonUtil.maskString6F4L(contractNo) + " - code: " + code);
//		}
//		
//		return contractInfo;
//		
//	}
//
//	private String buildGetContractInfoData(String reqId, String eWalletId, String phoneNo, String contractNo)
//			throws Exception {
//		JsonObject data = new JsonObject();
//		data.addProperty(Constant.REQUEST_ID, reqId);
//		data.addProperty(Constant.WALLET_ID, eWalletId);
//		data.addProperty(Constant.PHONE_NO, phoneNo);
//		data.addProperty(Constant.CONTRACT_NO, contractNo);
//
//		String dataBase64 = Base64.getEncoder().encodeToString(data.toString().getBytes(StandardCharsets.UTF_8));
//		String cks = CryptoUtil.sha256(dataBase64 + "|" + secretKey);
//
//		JsonObject jo = new JsonObject();
//		jo.addProperty(Constant.DATA, dataBase64);
//		jo.addProperty(Constant.CALLER, caller);
//		jo.addProperty(Constant.CHECK_SUM, cks);
//		return jo.toString();
//	}
//
//	public RepaymentProcessorClient() {
//	}
//
//	public RepaymentProcessorClient(String url, String caller, String secretKey) {
//		this.url = url;
//		this.caller = caller;
//		this.secretKey = secretKey;
//	}
//
//	public void setUrl(String url) {
//		this.url = url;
//	}
//
//	public void setCaller(String caller) {
//		this.caller = caller;
//	}
//
//	public void setSecretKey(String secretKey) {
//		this.secretKey = secretKey;
//	}
//}
