package vn.com.paysmart.uis.mrps.httpservice;

import java.util.concurrent.TimeUnit;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.eclipse.jetty.server.Connector;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.ServerConnector;
import org.eclipse.jetty.servlet.ServletHandler;
import org.eclipse.jetty.util.BlockingArrayQueue;
import org.eclipse.jetty.util.thread.QueuedThreadPool;
import org.eclipse.jetty.util.thread.ReservedThreadExecutor;
import vn.com.paysmart.uis.mrps.util.StaticConfig;

/**
 *
 * @author longdo
 */
public class WebServer implements Runnable {
	private static final Logger LOGGER = LogManager.getLogger(WebServer.class);

	@Override
	public void run() {
		try {
			LOGGER.info("Bitbucket revision: " + StaticConfig.GIT_REVISION);
			LOGGER.info("Bitbucket commitId: " + StaticConfig.GIT_COMMIT_ID);

			if (StaticConfig.APP_ENABLE_DEBUG) {
				// jdk 1.8
				System.setProperty("com.sun.xml.ws.transport.http.client.HttpTransportPipe.dump", "true");
				System.setProperty("com.sun.xml.ws.transport.http.HttpAdapter.dump", "true");
				System.setProperty("com.sun.xml.ws.transport.http.HttpAdapter.dumpTreshold", "999999");

				System.setProperty("org.eclipse.jetty.util.log.class", "org.eclipse.jetty.util.log.StdErrLog");
				System.setProperty("org.eclipse.jetty.LEVEL", "DEBUG");
			}

			int minThreads = StaticConfig.JETTY_MIN_THREADS;
			int maxQueued = StaticConfig.JETTY_MAX_QUEUED;

			int maxCapacity = Integer.MAX_VALUE;
			if (String.valueOf(maxQueued) != null || maxQueued != 0) {
				maxCapacity = Math.max(minThreads, maxQueued);
			}

			// max=100, min=10
			QueuedThreadPool threadPool = new QueuedThreadPool(StaticConfig.JETTY_MAX_THREADS,
					StaticConfig.JETTY_MIN_THREADS, StaticConfig.JETTY_IDE_TIMEOUT,
					new BlockingArrayQueue<>(maxCapacity));

			threadPool.setReservedThreads(StaticConfig.JETTY_MAX_THREADS/2); //experiment
			threadPool.setDaemon(true);
			threadPool.setName(StaticConfig.JETTY_NAME);

			boolean checkOOM = threadPool.getThreadPoolBudget().check(StaticConfig.JETTY_MAX_THREADS);
			LOGGER.info("check maxThread with memory : " + checkOOM);

			if (!checkOOM) {
				LOGGER.info("please check merory server or decrease maxThread.");
				// begin tracking
				ReservedThreadExecutor reserved = threadPool.getBean(ReservedThreadExecutor.class);
		        if (reserved != null) {
		            reserved.setIdleTimeout(StaticConfig.JETTY_IDE_TIMEOUT, TimeUnit.MILLISECONDS);
		        }
		        // end tracking
			}

			// depend info system
			int coreProcessor = Runtime.getRuntime().availableProcessors();
			LOGGER.info("coreProcessor : " + coreProcessor);

			Server server = new Server(threadPool);
			int port = 0;
			try {
				port = Integer.parseInt(System.getProperty("server.port"));
			} catch (NumberFormatException ex) {
				LOGGER.error("Property server.port not found. " + ex.getMessage(), ex);
			}

			// if acceptor 0 then the selector threads are used to accept connections
			// selector backup for acceptor
			// only init with limit system
			try (ServerConnector httpConnector = new ServerConnector(server, 1, coreProcessor)) {
				httpConnector.setAcceptQueueSize(StaticConfig.JETTY_MAX_QUEUED);

				LOGGER.info("acceptors : " + httpConnector.getAcceptors());
				LOGGER.info("queueSize : " + httpConnector.getAcceptQueueSize());

				httpConnector.setIdleTimeout(-1);
				httpConnector.setPort(port);
				server.setConnectors(new Connector[] { httpConnector });
			} catch (Exception e) {
				LOGGER.error(e.getMessage(), e);
			}
			
			ServletHandler handler = new ServletHandler();
			handler.addServletWithMapping(IndexServlet.class, "/v1.0/*");

			server.setHandler(handler);
			server.setStopAtShutdown(true);
			server.start();
			LOGGER.info("Server started on port = " + port);
			server.join();
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
	}
}
