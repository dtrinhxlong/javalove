package vn.com.paysmart.uis.mrps.httpservice;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Base64;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import com.google.gson.Gson;
import vn.com.paysmart.common.uis.common.Config;
import vn.com.paysmart.common.uis.entity.Response;
import vn.com.paysmart.common.uis.json.JsonObject;
import vn.com.paysmart.common.uis.profiler.ProfilerLog;
import vn.com.paysmart.common.uis.utils.CommonUtil;
import vn.com.paysmart.common.uis.utils.CryptoUtil;
import vn.com.paysmart.common.uis.utils.DateTimeUtil;
import vn.com.paysmart.common.uis.utils.GsonUtil;
import vn.com.paysmart.uis.mrps.client.thread.log.oData;
import vn.com.paysmart.uis.mrps.controller.ControllerFactory;
import vn.com.paysmart.uis.mrps.controller.ServiceController;
import vn.com.paysmart.uis.mrps.entity.Constant;
import vn.com.paysmart.uis.mrps.entity.OperationName;
import vn.com.paysmart.uis.mrps.entity.PartnerName;
import vn.com.paysmart.uis.mrps.entity.RequestData;
import vn.com.paysmart.uis.mrps.entity.ResponseCode;
import vn.com.paysmart.uis.mrps.util.StaticConfig;
import vn.com.paysmart.uis.mrps.validator.ValidatorUtils;

/**
 *
 * @author longdo
 */
public class IndexServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String reqId = req.getHeader(Constant.X_REQUEST_ID);
		String caller = req.getHeader(Constant.X_CALLER);
		this.out("Success", resp, reqId, caller);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		ProfilerLog profilerLog = new ProfilerLog(true);
		StaticConfig.LOGMANAGER.submit(new oData("date", DateTimeUtil.getCurrentDateTimeAsString(DateTimeUtil.DEFAULT_DATE_TIME_FORMAT)));
		
		String caller = "";
		String reqId = "";
		String partner = "";
		Response response = new Response();
		try {
			profilerLog.doStartLog("wholerequest");
			String func = CommonUtil.trim(req.getPathInfo(), "/");
			String version = CommonUtil.trim(req.getServletPath(), "/");
			String rawData = IOUtils.toString(req.getReader());
			
			JsonObject rawObj = JsonObject.parse(rawData);
			String decodeData = new String(Base64.getDecoder().decode(rawObj.getString(Constant.DATA)));
			JsonObject obj = JsonObject.parse(decodeData);
			partner = obj.getString(Constant.PARTNER_CODE);
			
			String method = getMethod(partner);
			
			reqId = req.getHeader(Constant.X_REQUEST_ID);
			caller = req.getHeader(Constant.X_CALLER);
			
			StaticConfig.LOGMANAGER.getSimpleLogBuilder().setRequestId(reqId);
			StaticConfig.LOGMANAGER.getSimpleLogBuilder().setCaller(caller);
			
			ResponseCode code = ValidatorUtils.validateRequest(method, rawData, caller);
			if (!code.name().equals(ResponseCode.SUCCESS.name())) {
				response = new Response(code.name()).setMessage(code.getMessage());
			} else {
				decodeData = code.getMessage();
				//header required
				if(StringUtils.isEmpty(reqId) || StringUtils.isEmpty(caller)) {
					StaticConfig.LOGMANAGER.submit(new oData("header", "caller: "+caller+" reqId: "+reqId+" is wrong"));
					response = new Response(ResponseCode.SYSTEM_ERROR.name()).setMessage("X-Request-ID, X-Caller is requied");
				} else {
					StaticConfig.LOGMANAGER.submit(new oData("partner", partner));
					StaticConfig.LOGMANAGER.submit(new oData("method", method));

					response = processNext(partner, func, method, decodeData, caller, reqId, version, profilerLog);
				}
			}
			
			profilerLog.doEndLog("wholerequest");
			StaticConfig.LOGMANAGER.submit(new oData("PROFILER_LOG", profilerLog.dumpScribeLog()));
		} catch (Exception e) {
			StaticConfig.LOGMANAGER.submit(new oData("exception_stack_trace_index_doPost", ExceptionUtils.getStackTrace(e)));
			response = new Response(ResponseCode.SYSTEM_ERROR.name());
			
			StaticConfig.LOGMANAGER.getSimpleLogBuilder().setResponseCode(response.getCode());
		} finally {
            StaticConfig.LOGMANAGER.getSimpleLogBuilder().setResponseCode(response.getCode());
		}
		if(response.getCode().equals(ResponseCode.SUCCESS.name())) {
			//da endcode data
			String checksum = genCheckSum(response, caller);
			response.setSignature(checksum);
		}
		
		this.out(new Gson().toJson(response), resp, caller, reqId);
	}
	
	public String getMethod(String partner) {
		if(partner.equals(PartnerName.CASH24)) {
			 return OperationName.QUERY_OF_PAYMENT;
		} else {
			if(partner.equals(PartnerName.MAFC)) {
				return OperationName.COLLECTION_MAFC;
			}
		}
		return OperationName.GET_CONTRACT_INFO_V2;
	}
	
	public Response processNext(String partner, String func, String method, String decodeData, String caller, String reqId, String version,
			ProfilerLog profilerLog) throws Exception {
		
			if (StaticConfig.APP_ENABLE_DEBUG) {
	            StaticConfig.LOGMANAGER.submit(new oData("rawData", decodeData));
	        }
			
			if (StringUtils.isNotBlank(reqId)) {
				StaticConfig.LOGMANAGER.submit(new oData("reqId", reqId));
			}
			
			RequestData data = GsonUtil.fromJson(decodeData, RequestData.class);
			data.setPartnerCode(partner);
			
			ControllerFactory controllerFactory = new ControllerFactory();
			if("querycontract".equalsIgnoreCase(func)) {
				ServiceController controller = controllerFactory.queryServiceController(partner);
				if(controller==null) {
					return new Response(ResponseCode.PARTNER_CODE_NOT_SUPPORTED.name()).setMessage(partner+" not support");
				}
				return controller.processRequest(reqId, data, profilerLog);
			} else {
				return new Response(ResponseCode.API_NOT_SUPPORTED.name()).setMessage(func+" not support");
			}
	}

	private void out(String content, HttpServletResponse resp, String caller, String requestId) {
		PrintWriter out = null;
		try {
			resp.setCharacterEncoding("UTF-8");
			resp.addHeader("Content-Type", "application/json;charset=UTF-8");
			
			resp.addHeader(Constant.X_REQUEST_ID, requestId);
			resp.addHeader(Constant.X_CALLER, caller);
			
			out = resp.getWriter();
			out.println(content);
		} catch (IOException e) {
			StaticConfig.LOGMANAGER.submit(new oData("exception_stack_trace_todo_out", ExceptionUtils.getStackTrace(e)));
		} finally {
			if (out != null) {
				out.close();
			}
		}
	}

	private String genCheckSum(Response response, String caller) {
		try {
			String secretKey = Config.getParam("app", caller);
			String data = "";
			if (response.getData() != null) {
				data = response.getData();
			}
			return CryptoUtil.sha256(data + "|" + secretKey);
		} catch (Exception e) {
			StaticConfig.LOGMANAGER.submit(new oData("exception_stack_trace_gen_checksum", ExceptionUtils.getStackTrace(e)));
			return null;
		}
	}
}
