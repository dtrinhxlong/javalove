package vn.com.paysmart.uis.mrps.client;

import static com.google.common.base.Preconditions.checkArgument;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import vn.com.paysmart.common.uis.profiler.ProfilerLog;
import vn.com.paysmart.uis.mrps.client.thread.log.oData;
import vn.com.paysmart.uis.mrps.entity.Constant;
import vn.com.paysmart.uis.mrps.util.StaticConfig;

public class ConnectorThread extends Thread {
	private static final int DEFAULT_RETRY_COUNT = 2;
	private int retries = DEFAULT_RETRY_COUNT;
	private static final String CONTENT_TYPE = "application/json;charset=UTF-8";

	private final CloseableHttpClient httpClient;
	private final String reqData;
	private ProfilerLog profilerLog;
	private String respData;
	private String url;
	private String requestId;
	private String caller;
	private CloseableHttpResponse response;
	private HttpPost postMethod;
	
	public ConnectorThread(String url, CloseableHttpClient httpClient, String name, String reqData,
			String requestId, String caller, ProfilerLog profilerLog) {
		super(name);
		this.httpClient = httpClient;
		this.reqData = reqData;
		this.profilerLog = profilerLog;
		this.url = url;
		this.requestId = requestId;
		this.caller = caller;
	}

	@Override
	public void run() {
		try {
			profilerLog.doStartLog("getResponseFromService");
			postMethod = new HttpPost(url);
			
			postMethod.setHeader(Constant.CONTENT_TYPE, CONTENT_TYPE);
			
			postMethod.setHeader(Constant.X_REQUEST_ID, this.requestId);
			postMethod.setHeader(Constant.X_CALLER, this.caller);
			
			StringEntity data_send = new StringEntity(this.reqData, StandardCharsets.UTF_8);
			postMethod.setEntity(data_send);
			 
			response = processMethod(); 
			StaticConfig.LOGMANAGER.submit(new oData(Thread.currentThread().getName() + " " + super.getId(), "" + response.getStatusLine()));
			
			int statusCode = response.getStatusLine().getStatusCode();
			if (statusCode == 200) {
				this.respData = readHttpResponse(response);
			}
			profilerLog.doEndLog("getResponseFromService");
		} catch (Exception e) {
			StaticConfig.LOGMANAGER.submit(new oData("exception_stack_trace_fatal_transfort", ExceptionUtils.getStackTrace(e)));
		} finally {
			if (response != null) {
				try {
					response.close();
				} catch (IOException e) {
					StaticConfig.LOGMANAGER.submit(new oData("exception_stack_trace_fatal_close", e.getMessage()));
				}
			}
		}
	}
	
	public CloseableHttpResponse processMethod() {
		CloseableHttpResponse response = null;
		try {
			if (postMethod != null) {
				response = execute(postMethod);
				postMethod.releaseConnection();
			}
			return response;
		} catch (Exception e) {
			StaticConfig.LOGMANAGER.submit(new oData("exception_stack_trace_fatal_process_method", e.getMessage()));
			return null;
		}
	}
	
	public String readHttpResponse(CloseableHttpResponse httpResponse) {
		try (BufferedReader reader = new BufferedReader(new InputStreamReader(httpResponse.getEntity().getContent()))) {

			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = reader.readLine()) != null) {
				response.append(inputLine);
			}
			
			return response.toString();
		} catch (Exception e) {
			StaticConfig.LOGMANAGER.submit(new oData("exception_stack_trace_fatal_read_response", e.getMessage()));
			return null;
		} finally {
			EntityUtils.consumeQuietly(httpResponse.getEntity());
		}
	}
	
	public CloseableHttpResponse execute(HttpUriRequest request) throws IOException {
		CloseableHttpResponse response;

		int tries = ++retries;
		while (true) {
			tries--;
			try {
				response = httpClient.execute(request, HttpClientContext.create());
				break;
			} catch (IOException e) {
				if (tries < 1) {
					throw e;
				}
			} finally {
				 //abort the request
		        if (null != request && !request.isAborted()) {
		            request.abort();
		        }
			}
		}

		return response;
	}

	public String getRespData() {
		return respData;
	}

	public static String processGetResponseCharset(String[] pair, String charset) {
		if (pair.length == 2) {
			if (!StringUtils.isEmpty(pair[1])) {
				charset = pair[1].trim();
			}
		}

		return charset;
	}

	public int getRetryCount() {
		return retries;
	}

	public void setRetryCount(int retries) {
		checkArgument(retries >= 0);
		this.retries = retries;
	}
}
