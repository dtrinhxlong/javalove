package vn.com.paysmart.uis.mrps.util;

import java.util.Base64;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import vn.com.paysmart.common.uis.common.Config;
import vn.com.paysmart.mis.queuehmac.HMACQueueMessageCreator;
import vn.com.paysmart.uis.mrps.client.thread.log.oData;

public class CommonUtil {
	public static String createChecksum(String data, String caller, String requestId) {
		try {
			String hashkey = Config.getParam(StaticConfig.APP_NAME, caller);
			return HMACQueueMessageCreator.createSignatureFromMessage(requestId, caller, data, hashkey);
		} catch (Exception e) {
          StaticConfig.LOGMANAGER.submit(new oData("exception_stack_trace_create_checksum", ExceptionUtils.getStackTrace(e)));
          return null;
      }
    }
	
	public static String decodeBase64(String data) {
        return new String(Base64.getDecoder().decode(data.getBytes()));
    }
	
	public static String genBase64(String data) {
		return new String(Base64.getEncoder().encode(data.getBytes()));
	}
	
	public static String maskString6F4L(String s) {
        String s1 = StringUtils.left(s, 6);
        String s2 = StringUtils.right(s, 4);
        return s1 + "****" + s2;
    }
}
