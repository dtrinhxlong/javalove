import vn.com.paysmart.common.queue.QueueConfig;
import vn.com.paysmart.common.queue.RabbitMQConfig;
import vn.com.paysmart.common.queue.delay.DelayProducer;
import vn.com.paysmart.common.queue.producer.QueueProducer;
import vn.com.paysmart.common.uis.common.LogUtil;
import vn.com.paysmart.uis.mrps.util.StaticConfig;

public class TestMutilThread {

	public static void main(String[] args) {
		try {
			LogUtil.init();
			StaticConfig.initClassLoader();
			
			initRabbitMQConfig();

			String dataQueue = "{\"data\":\"eyJBY2NObyI6Ijc2MjQ3MzAwNDk3MyIsIkFjY05hbWUiOiJOZ3V5ZW4gVGhpIERpZXAiLCJDbGllbnRJZE5vIjoiIiwiT3JkZXJJZCI6IiIsIkV4cGlyZURhdGUiOiIyMDIwLTA2LTIzIiwiQ29sbGVjdEFtb3VudCI6IjU4OTYwMDAuMDAiLCJDb2xsZWN0QW1vdW50TWluIjoiNTAwMDAiLCJDb2xsZWN0QW1vdW50TWF4IjoiNTg5NjAwMCIsIlN0YXR1cyI6IkRFTElWRVIiLCJXYWxsZXRJZCI6IjgyIiwiVHJhbnNJZCI6IjIwMjAwNzI5MDAwMDAwMDU2OSIsIlRyYW5zQW1vdW50Ijo1ODAwMCwiVHJhbnNUaW1lIjoxNTk2MDE0NjAzNzkwLCJSZXF1ZXN0SWQiOiIxNTk1NTgwNTEwNDI4IiwiUGhvbmVObyI6IjA5MDc3MTEzMzYiLCJQYXJ0bmVyQ29kZSI6IkNBU0gyNCIsIk1pbkFtb3VudCI6NTAwMDAsIlJybiI6IjAyMTE3MzQ3ODM3MSJ9\",\"signature\":\"d7a214cc2b10ee8fcc4b219194a3acadfe33f48052ed0b4a23a00d0fd34e1de5\"}";

			for (int i = 0; i < 300; i++) {
				QueueProducer producer = new QueueProducer(StaticConfig.RABBIT_MQ_NAME,
						"CASH24_REPAYMENT_DELIVER");
				producer.sendMessage(dataQueue);
			}
			System.out.println("Done.");
			System.exit(1);
		} catch (Exception e) {
			e.printStackTrace(System.out);
		}

	}
	
	private static void initRabbitMQConfig() throws Exception {
        RabbitMQConfig rabbitMQConfig = new RabbitMQConfig(StaticConfig.RABBIT_MQ_HOST, StaticConfig.RABBIT_MQ_PORT,
                StaticConfig.RABBIT_MQ_USERNAME, StaticConfig.RABBIT_MQ_PASSWORD, "/",
                StaticConfig.RABBIT_MQ_POOL_SIZE,
                StaticConfig.RABBIT_MQ_AUTO_ACK, StaticConfig.RABBIT_MQ_PREFETCH_SIZE);
        QueueConfig.initConfig(StaticConfig.RABBIT_MQ_NAME, rabbitMQConfig);
    }

}
