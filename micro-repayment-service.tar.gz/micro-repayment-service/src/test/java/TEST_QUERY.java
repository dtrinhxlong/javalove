
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.util.Base64;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

/**
 *
 * @author tainguyen
 */
public class TEST_QUERY {

    private static String CALLER = "DELIVER_SERVICE";

    private static String SECRECT_KEY = "a";

    private static String URL = "https://dev-mrps.paysmart.com.vn/v1.0/querycontract";

    public static void main(String[] args) {
        System.out.println("start....");
        for (int i = 0; i < 1; i++) {
        getContractInfo(
                "CASH24",
                "900300024738",
                "1234321",
                "0987654321");
        }
    }

    private static void getContractInfo(String partnerCode, String contractNo,
            String walletId, String phone) {

        String reqId = System.nanoTime() + "";

        JsonObject jo = new JsonObject();
        jo.addProperty("walletId", walletId);
        jo.addProperty("phone", phone);
        jo.addProperty("contractNo", contractNo);
        jo.addProperty("partnerCode", partnerCode);
        String encodeData = Base64.getEncoder().encodeToString(jo.toString().getBytes());
        JsonObject bodyData = new JsonObject();

        bodyData.addProperty("data", encodeData);
        bodyData.addProperty("checksum", vn.com.paysmart.common.uis.utils.CryptoUtil.sha256(encodeData + "|" + SECRECT_KEY));

        System.out.println("req:" + bodyData.toString());

        String resp = httpPost(reqId, URL, bodyData.toString());
        System.out.println("resp:" + resp);
        if (StringUtils.isNotBlank(resp)) {
            try {
                JsonElement je = new JsonParser().parse(resp);
                if (je != null) {
                    JsonObject joResp = je.getAsJsonObject();
                    String dataRespEncode = joResp.get("data").getAsString();
//                    System.out.println("dataRespEncode:\n" + dataRespEncode);
//
//                    String ckecksum = joResp.get("checksum").getAsString();
//                    System.out.println("ckecksum:\n" + ckecksum);
//
                    String code = joResp.get("code").getAsString();
//                    System.out.println("code: " + code);
//
//                    String checksum1 = vn.com.paysmart.common.uis.utils.CryptoUtil.SHA256(code + "|" + dataRespEncode + "|" + secrectKey);
//                    System.out.println("checksum1:\n" + checksum1);
//                    System.out.println("verify checksum: " + checksum1.equals(ckecksum));
//
                    String dataRespDecode = new String(Base64.getDecoder().decode(dataRespEncode));
                    System.out.println("dataRespDecode: " + dataRespDecode);
                }
            } catch (Exception e) {
                e.printStackTrace(System.out);
            }
        } else {
            System.out.println("no response");
        }
        System.out.println("---------------------------------------");
    }

    private static String httpPost(String reqId, String url, String data) {
        try (CloseableHttpClient httpclient = HttpClients.createDefault()) {
            HttpPost httpPost = new HttpPost(url);
            httpPost.setHeader("X-Request-ID", reqId);
            httpPost.setHeader("X-Caller", CALLER);
            httpPost.setHeader("Accept", "application/json");
            httpPost.setHeader("Content-type", "application/json");
            httpPost.setEntity(new StringEntity(data));
            try (CloseableHttpResponse response = httpclient.execute(httpPost)) {
                return EntityUtils.toString(response.getEntity());
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        } catch (Exception ex) {
            ex.printStackTrace(System.out);
        }
        return null;
    }
}
