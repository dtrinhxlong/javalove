import java.io.IOException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.Locale;

import vn.com.paysmart.common.uis.common.Config;
import vn.com.paysmart.common.uis.utils.CryptoUtil;
import vn.com.paysmart.mis.httphmac.HmacException;
import vn.com.paysmart.mis.queuehmac.HMACQueueMessageCreator;

public class TestChecksum {

	public static void main(String[] args) throws ParseException, IOException, HmacException {
		String str = "{\"accNo\":\"762473004973\",\"customerName\":\"NGUYEN THI DIEP\",\"customerPhone\":\"0988303035\",\"phoneNo\":\"0988303035\",\"transAmount\":50000,\"transDate\":15345677,\"transId\":\"123456789\",\"walletId\":\"82\"}";
		String query = "{\"RRN\":\"021173478371\",\"amount\":58000,\"orderInfo\":{\"service\":\"REPAYMENT\",\"partnerCode\":\"CASH24\",\"contractNo\":\"762473004973\",\"borrowerName\":\"NGUYEN THI DIEP\",\"dueDate\":\"23/06/2020\",\"beneficiary\":{\"type\":\"PARTNER\",\"partner\":{\"code\":\"CASH24\"}}},\"orgAmt\":58000,\"payAmt\":58000,\"phone\":\"0907711336\",\"refNo\":\"202007290000000569\",\"transDate\":1596014603790,\"type\":\"PURCHASE\",\"walletId\":\"82\"}";
		String base64 = new String(Base64.getEncoder().encode(query.getBytes()));
		System.out.println("base64_ "+base64);
		
		String sign = HMACQueueMessageCreator.createSignatureFromMessage("1595580510428", "DELIVER_SERVICE", base64, "a");
		
		String encrypt = CryptoUtil.sha256(base64 + "|" + "a");
		System.out.println("encrypt_ "+sign);
		
//		String amt = "14700000.000";
//		NumberFormat formatter = new DecimalFormat("#0");     
//		System.out.println(formatter.format(Double.parseDouble(amt)));
		
//		String data = "eyJwYXJ0bmVyTmFtZSI6IkNhc2gyNC52biIsInBhcnRuZXJEZXMiOiJUaGFuaCB0b8OhbiB2YXkgdGnDqnUgZMO5bmciLCJsb2dvVXJsIjoiaHR0cHM6Ly9kZXYtc3RjLnBheXNtYXJ0LmNvbS52bi9hcHAvcmVwYXltZW50L3JlcGF5bWVudC1sb2dvLWNhc2gyNC5wbmciLCJoaW50QW1vdW50SW5wdXQiOiJC4bqhbiBjw7MgdGjhu4MgdGhheSDEkeG7lWkgc+G7kSB0aeG7gW4gdGhhbmggdG/DoW4sIHPhu5EgdGnhu4FuIHRoYW5oIGtow7RuZyDEkcaw4bujYyBuaOG7jyBoxqFuIDUwLjAwMMSRIHbDoCBs4bubbiBoxqFuIDUwLjAwMC4wMDDEkSIsIm1pbnRBbW91bnQiOiI1MDAwMCIsIm1heEFtb3VudCI6IjUwMDAwMDAwIiwidXNlclBob25lTnVtYmVyIjoiMDk4ODMwMzAzNSIsImNhc2hiYWNrQW1vdW50IjoiNjAwMCIsImRldGFpbEluZm8iOlt7InR5cGUiOiJLZXkiLCJyb3dEZXRhaWwiOnsibGVmdCI6IlPhu5EgaOG7o3AgxJHhu5NuZyIsInJpZ2h0IjoiNzYyNDc1NjY5NjAwIn19LHsidHlwZSI6IktleSIsInJvd0RldGFpbCI6eyJsZWZ0IjoiSOG7jSB2w6AgdMOqbiIsInJpZ2h0IjoiTkdVWUVOIFRISSBESUVQIn19LHsidHlwZSI6IktleSIsInJvd0RldGFpbCI6eyJsZWZ0IjoiTmfDoHkgxJHhur9uIGjhuqFuIiwicmlnaHQiOiIyMDIwLTA3LTEzIn19LHsidHlwZSI6IktleSIsInJvd0RldGFpbCI6eyJsZWZ0IjoiU+G7kSB0aeG7gW4gxJHhur9uIGjhuqFuIHRoYW5oIHRvw6FuIiwicmlnaHQiOiIxNDc0NTAwMC4wMDAifX0seyJ0eXBlIjoiS2V5Iiwicm93RGV0YWlsIjp7ImxlZnQiOiJU4buVbmcgbuG7oyBjw7JuIGzhuqFpIGPhuqduIHRoYW5oIHRvw6FuIiwicmlnaHQiOjE3NzI1MDAwfX0seyJ0eXBlIjoiSGludCIsInJvd0RldGFpbCI6eyJsZWZ0IjoixJDDonkgbMOgIHPhu5EgdGnhu4FuIHThu5FpIMSRYSBi4bqhbiBjw7MgdGjhu4MgdGhhbmggdG/DoW4gxJHhu4MgdGhhbmggbMO9IHPhu5EgdGnhu4FuIG7DoHkifX1dfQ==";
//		String checksum = "1ca60570c532a199f3f717918d6fe2404b6dbf60a3d7130bea3dfdd68adaf0f8";
//		
//		System.out.println(verifyChecksum(data, checksum, ""));
		
//		Locale localeVN = new Locale("vi", "VN");
//	    NumberFormat currencyVN = NumberFormat.getCurrencyInstance(localeVN);
//	    String str1 = currencyVN.format(Double.parseDouble("50000"));
//	    System.out.println(str1.replace(" ", ""));
		}
	
	public static boolean verifyChecksum(String data, String checksum, String inOutKey) {
		 String encryptedSig = CryptoUtil.sha256(data + "|" + "a");
	    if (!encryptedSig.equals(checksum)) {
	    	return false;
	    }
	    return true;
	}
}
