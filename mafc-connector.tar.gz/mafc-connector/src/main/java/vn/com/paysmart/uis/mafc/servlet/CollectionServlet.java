package vn.com.paysmart.uis.mafc.servlet;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import vn.com.paysmart.common.uis.log.LogBuilder;
import vn.com.paysmart.common.uis.profiler.ProfilerLog;
import vn.com.paysmart.uis.mafc.client.MafcClient;
import vn.com.paysmart.uis.mafc.entity.HttpResponse;
import vn.com.paysmart.uis.mafc.utils.Const;
import vn.com.paysmart.uis.mafc.utils.ResponseCode;

public class CollectionServlet extends BaseServlet {

    private static final long serialVersionUID = -5225153110734626079L;

    @Override
    HttpResponse pMain(JsonObject reqData, LogBuilder logBuilder, ProfilerLog profilerLog) {
        HttpResponse response = new HttpResponse();
        response.setCode(ResponseCode.FAILED.name());
        /*
         * verify Request param
         */
        if (reqData.get(Const.AGN_ID) == null || StringUtils.isBlank(reqData.get(Const.AGN_ID).getAsString())) {
            response.setMessage("connector - missing " + Const.AGN_ID);
            return response;
        }
        profilerLog.doStartLog("getResponseFromPartner");
        MafcClient mafcClient = new MafcClient();
        String url = mafcClient.buildGetUrl(new String[]{reqData.get(Const.AGN_ID).getAsString()});
        JsonObject partnerData = mafcClient.collectionMafc(url, logBuilder, profilerLog);
        profilerLog.doEndLog("getResponseFromPartner");
        if (partnerData.get(Const.CODE).getAsInt() != HttpServletResponse.SC_OK) {
            response.setMessage(partnerData.get(Const.DATA).getAsString());
            return response;
        }
        /*
         * 1 - “success” = false                        |    Error with the detail of error from “errors”
         * 2 - “success” = true & “result” = []         |    ID/ agreement ID not exist
         * 3 - “success” = true & “result” = [data]     |    Successfully
         */
        try {
            JsonObject joData = new JsonParser().parse(partnerData.get(Const.DATA).getAsString()).getAsJsonObject();
            if (!joData.get(Const.SUCCESS).getAsBoolean()) {
                response.setMessage(joData.get(Const.ERRROS).toString());
                return response;
            }
            response.setMessage(Const.SUCCESS);
            if (joData.get(Const.RESULT).getAsJsonArray().size() < 1) {
                response.setMessage("ID/ agreement ID not exist");
            }
            response.setCode(ResponseCode.SUCCESS.name());
            JsonObject result = new JsonObject();
            result.add(Const.RESULT, joData.get(Const.RESULT));
            response.setData(result.toString());
            return response;
        } catch (Exception e) {
            response.setMessage("Can't read the response body");
            logBuilder.append("CollectionServlet_ex", ExceptionUtils.getStackTrace(e));
            return response;
        }
    }
}
