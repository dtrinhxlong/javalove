package vn.com.paysmart.uis.mafc.utils;

/**
 * @author tainguyen
 */
public class Const {

    public static final String X_CALLER = "X-Caller";

    //  public static final String X_API_KEY = "X-API-Key";
    public static final String X_REQUEST_ID = "X-Request-ID";

    public static final String REMOTE_ADDRESS = "remoteAddress";

    public static final String LOCAL_ADDRESS = "localAddress";

    public static final String DATE = "date";

    public static final String CODE = "code";

    public static final String DATA = "data";

    public static final String AGN_ID = "agnId";

    public static final String SUCCESS = "success";

    public static final String RESULT = "result";

    public static final String ERRROS = "errros";

    public static final String AUTHORIZATION = "Authorization";

    public static final String CONTENT_TYPE = "Content-Type";
    public static final String CONTENT_LENGTH = "Content-Length";

    public static final String CONTENT_TYPE_APP_JSON = "application/json;charset=UTF-8";

    public static final String REQ_URL = " [reqUrl]";

    public static final String REQ_DATA = " [reqData]";

    public static final String RES_DATA = " [resData]";

    public static final String WALLET_ID = "walletId";

    public static final String PHONE_NO = "phoneNo";

    public static final String SERVICE = "service";

    public static final String MAFC_CONFIG = "mafc_config";

    public static final String ACC_NO = "accNo";

    public static final String CUSTOMER_NAME = "customerName";

    public static final String REQUEST_ID = "requestId";

    public static final String REQUEST_TIME = "requestTime";

    public static final String TRANS_AMOUNT = "transAmount";

    public static final String TRANS_ID = "transId";

    public static final String AGREE_ID = "agreeid";

    public static final String AMOUNT = "amount";
    
    public static final String MIN_AMOUNT = "minAmount";
    public static final String OVERDUEAMOUNT = "overDueAmount";
    public static final String DUEDATE = "dueDate";
    public static final String COLLECTION_AMOUNT = "collectionAmount";
    public static final String EXPIREDATE = "expireDate";
    public static final String RRN = "rrn";
    
    public static final String REFNO = "refNo";

    public static final String TRANSACTION_ID = "transactionid";

    public static final String COLLECTOR = "collector";

    public static final String HOST = "host";

    public static final String PORT = "port";

    public static final String USERNAME = "username";

    public static final String PASSWORD = "password";

    public static final String QUEUE_NAME = "queue-name";

    public static final String THREAD_POOL_SIZE = "thread-pool-size";

    public static final String PREFETCH_SIZE = "prefetch-size";

    public static final String STATUS = "status";

    public static final String EXTRA_DATA = "extraData";

    public static final String CALLER = "caller";

    public static final String PROVIDER = "provider";

    public static final String TRANS_TIME = "transTime";
}
