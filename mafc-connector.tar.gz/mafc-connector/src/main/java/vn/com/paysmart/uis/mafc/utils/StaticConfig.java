package vn.com.paysmart.uis.mafc.utils;

import java.io.InputStream;
import java.security.PrivateKey;
import java.security.PublicKey;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import vn.com.paysmart.common.queue.QueueConfig;
import vn.com.paysmart.common.queue.RabbitMQConfig;
import vn.com.paysmart.common.uis.common.Config;
import vn.com.paysmart.uis.mafc.client.PoolingHttpClient;

/**
 *
 * @author longdo
 */
public class StaticConfig {

    private static final Logger LOGGER = LogManager.getLogger(StaticConfig.class);

    public static final int JETTY_MIN_THREADS;
    public static final int JETTY_MAX_THREADS;
    public static final int JETTY_MAX_QUEUED;
    public static final int JETTY_IDE_TIMEOUT;
    public static final String JETTY_NAME;

    public static final boolean APP_ENABLE_DEBUG;

    public static final String GIT_REVISION;
    public static final String GIT_COMMIT_ID;
    
    public static PoolingHttpClient POOLING_HTTP_CLIENT;

    static {
        int jettyMinThreads = 0;
        int jettyMaxThreads = 0;
        int jettyMaxQueued = 0;
        int jettyIdeTimeout = 0;
        String jettyName = null;

        boolean appEnableDebug = false;

        String gitRevision = null;
        String gitCommitId = null;

        try {
            String jetty = "jetty";
            jettyMinThreads = Config.getIntParam(jetty, "minthreads");
            jettyMaxThreads = Config.getIntParam(jetty, "maxthreads");
            jettyMaxQueued = Config.getIntParam(jetty, "maxqueued");
            jettyIdeTimeout = Config.getIntParam(jetty, "idetimeout");
            jettyName = Config.getParam(jetty, "name");

            String service = "service";
            appEnableDebug = Config.getIntParam(service, "enable-debug") == 1;

            InputStream is = Thread.currentThread().getContextClassLoader()
                    .getResourceAsStream("git.properties");
            java.util.Properties prop = new java.util.Properties();
            prop.load(is);
            gitRevision = prop.getProperty("git.branch");
            gitCommitId = prop.getProperty("git.commit.id");
            
            POOLING_HTTP_CLIENT = new PoolingHttpClient();

            LOGGER.info("Load config successfully.");
        } catch (Exception e) {
            LOGGER.error("Exception.msg=Load config failed. " + e.getMessage(), e);
        }

        JETTY_MIN_THREADS = jettyMinThreads;
        JETTY_MAX_THREADS = jettyMaxThreads;
        JETTY_MAX_QUEUED = jettyMaxQueued;
        JETTY_IDE_TIMEOUT = jettyIdeTimeout;
        JETTY_NAME = jettyName;

        APP_ENABLE_DEBUG = appEnableDebug;

        GIT_REVISION = gitRevision;
        GIT_COMMIT_ID = gitCommitId;
    }

    public static void initClassLoader() {
        LOGGER.info("Init class loader ...");
    }
}
