package vn.com.paysmart.uis.mafc.utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import vn.com.paysmart.common.uis.common.Config;
import vn.com.paysmart.common.uis.log.LogBuilder;
import vn.com.paysmart.logging.JsonLogBuilder;
import vn.com.paysmart.logging.LogMessage;
import vn.com.paysmart.logging.SingletonLogWriter;
import vn.com.paysmart.logging.kafka.LogWriter;
import vn.com.paysmart.logging.kafka.LogWriterConfig;

/**
 * @author tainguyen
 */
public class Log {

    private static final Logger LOGGER = LogManager.getLogger(Log.class);

    static {
        /*
         * Init kafka
         */
        try {
            String kafkaSec = "kafka";
            String kafkaServers = Config.getParam(kafkaSec, "servers");
            String kafkaClientId = Config.getParam(kafkaSec, "client-id");
            LogWriterConfig.Builder b = new LogWriterConfig.Builder()
                    .setClientId(kafkaClientId)
                    .setTopic(System.getProperty("application.name"));
            String[] serversArr = kafkaServers.split(",");
            for (String server : serversArr) {
                String[] s = server.split(":");
                b.addHostPort(s[0], Integer.parseInt(s[1]));
            }
            SingletonLogWriter.INSTANCE.register(new LogWriter(b.build()));
        } catch (Exception e) {
            LOGGER.info("############### INTI SINGLETON LOG WRITER ################");
            LOGGER.info("################### EXCEPTION MESSAGE ####################");
            LOGGER.error(e.getStackTrace());
        }
    }

    public static void logWriter(JsonLogBuilder jsonLogBuilder, String response, String respCode, LogBuilder logBuilder) {
        jsonLogBuilder.set(LogMessage.RESULT_FIELD, response);
        jsonLogBuilder.set(LogMessage.STATUS_FIELD, respCode);
        try {
            SingletonLogWriter.INSTANCE.write(jsonLogBuilder.
                    set(Const.DATA, vn.com.paysmart.json.JsonObject.parse(logBuilder.build())).build());
        } catch (Exception e) {
            LOGGER.info("############### EXCEPTION TO LOG SERVICE ################");
            LOGGER.info("#################### JSON_LOG_BUILDER ###################");
            LOGGER.info(jsonLogBuilder);
            LOGGER.info("################### EXCEPTION MESSAGE ####################");
            LOGGER.error(e.getStackTrace());
        }
    }
}
