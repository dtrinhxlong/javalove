package vn.com.paysmart.uis.mafc.client;

import static com.google.common.base.Preconditions.checkArgument;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import vn.com.paysmart.common.uis.log.LogBuilder;
import vn.com.paysmart.common.uis.profiler.ProfilerLog;

public class ConnectorThread extends Thread {
	private static final int DEFAULT_RETRY_COUNT = 2;
	private int retries = DEFAULT_RETRY_COUNT;

	private final CloseableHttpClient httpClient;
	private ProfilerLog profilerLog;
	private LogBuilder logBuilder;
	private String respData;
	private CloseableHttpResponse response;
	private HttpPost postMethod;
	private HttpGet getMethod;
	private HttpPut putMethod;

	public ConnectorThread(HttpPost postMethod, CloseableHttpClient httpClient, String name,
			ProfilerLog profilerLog, LogBuilder logBuilder) {
		super(name);
		this.httpClient = httpClient;
		this.profilerLog = profilerLog;
		this.logBuilder = logBuilder;
		this.postMethod = postMethod;
	}
	
	public ConnectorThread(HttpGet getMethod, CloseableHttpClient httpClient, String name,
			ProfilerLog profilerLog, LogBuilder logBuilder) {
		super(name);
		this.httpClient = httpClient;
		this.profilerLog = profilerLog;
		this.logBuilder = logBuilder;
		this.getMethod = getMethod;
	}
	
	public ConnectorThread(HttpPut putMethod, CloseableHttpClient httpClient, String name,
			ProfilerLog profilerLog, LogBuilder logBuilder) {
		super(name);
		this.httpClient = httpClient;
		this.profilerLog = profilerLog;
		this.logBuilder = logBuilder;
		this.putMethod = putMethod;
	}

	@Override
	public void run() {
		try {
			profilerLog.doStartLog("getResponseFromPartner");
			response = processMethod();
			logBuilder.append(Thread.currentThread().getName() + " " + super.getId(), "" + response.getStatusLine());
			int statusCode = response.getStatusLine().getStatusCode();
			if (statusCode == 200) {
				this.respData = readHttpResponse(response);
			}
		} catch (Exception e) {
			logBuilder.append("exception_http", ExceptionUtils.getStackTrace(e));
		} finally {
			if (response != null) {
				try {
					response.close();
				} catch (IOException e) {
					logBuilder.append("Fatal close error", e.getMessage());
				}
			}
			profilerLog.doEndLog("getResponseFromPartner");
		}
	}
	
	public CloseableHttpResponse processMethod() {
		CloseableHttpResponse response = null;
		try {
			if (postMethod != null) {
				response = execute(postMethod);
				postMethod.releaseConnection();
			} else {
				if (getMethod != null) {
					response = execute(getMethod);
					getMethod.releaseConnection();
				} else {
					response = execute(putMethod);
					putMethod.releaseConnection();
				}
			}
			return response;
		} catch (Exception e) {
			logBuilder.append("Fatal processMethod error", e.getMessage());
			return null;
		}
	}
	
	public String readHttpResponse(CloseableHttpResponse httpResponse) {
		try (BufferedReader reader = new BufferedReader(new InputStreamReader(httpResponse.getEntity().getContent()))) {

			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = reader.readLine()) != null) {
				response.append(inputLine);
			}
			
			return response.toString();
		} catch (Exception e) {
			logBuilder.append("Read resp error", e.getMessage());
			return null;
		} finally {
			EntityUtils.consumeQuietly(httpResponse.getEntity());
		}
	}

	public String getRespData() {
		return respData;
	}
	
	public static String processGetResponseCharset(String[] pair, String charset) {
		if (pair.length == 2) {
			if (!StringUtils.isEmpty(pair[1])) {
				charset = pair[1].trim();
			}
		}

		return charset;
	}

	public CloseableHttpResponse execute(HttpUriRequest request) throws IOException {
		CloseableHttpResponse response;
		int tries = ++retries;
		while (true) {
			tries--;
			try {
				response = httpClient.execute(request, HttpClientContext.create());
				break;
			} catch (IOException e) {
				if (tries < 1) {
					throw e;
				}
			} finally {
				 //abort the request
		        if (null != request && !request.isAborted()) {
		            request.abort();
		        }
			}
		}

		return response;
	}

	public int getRetryCount() {
		return retries;
	}

	public void setRetryCount(int retries) {
		checkArgument(retries >= 0);
		this.retries = retries;
	}
}
