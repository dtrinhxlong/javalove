package vn.com.paysmart.uis.mafc;

import org.apache.logging.log4j.Logger;
import vn.com.paysmart.common.uis.common.LogUtil;

import java.io.File;

/**
 * @author tainguyen
 */
public class Service {

    private static final Logger LOGGER = LogUtil.getLogger(Service.class.getSimpleName());

    public static void main(String[] args) {
        try {
            String pidFile = System.getProperty("pidfile");
            if (pidFile != null) {
                new File(pidFile).deleteOnExit();
            }
            LogUtil.init();
            
            WebServer webServer = new WebServer();
			webServer.start();
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
    }
}
