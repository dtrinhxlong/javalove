package vn.com.paysmart.uis.mafc.client;

import com.google.gson.JsonObject;
import org.apache.http.HttpHost;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.eclipse.jetty.util.StringUtil;

import vn.com.paysmart.common.uis.common.Config;
import vn.com.paysmart.common.uis.log.LogBuilder;
import vn.com.paysmart.common.uis.profiler.ProfilerLog;
import vn.com.paysmart.uis.mafc.utils.Const;
import vn.com.paysmart.uis.mafc.utils.StaticConfig;

import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.text.MessageFormat;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;

/**
 * @author tainguyen
 */
public class MafcClient {
	private static final Logger LOGGER = LogManager.getLogger(MafcClient.class);
	private final String token;
	private final String getInfoUrl;
	private final String payBillUrl;
	private final String cancelBillUrl;

	public MafcClient() {
		this.token = Config.getParam(Const.MAFC_CONFIG, "token");
		this.getInfoUrl = Config.getParam(Const.MAFC_CONFIG, "collectionmafc-url");
		this.payBillUrl = Config.getParam(Const.MAFC_CONFIG, "paybillmafc-url");
		this.cancelBillUrl = Config.getParam(Const.MAFC_CONFIG, "cancelbillmafc-url");
	}

	public JsonObject payBillMafc(String data, LogBuilder logBuilder, ProfilerLog profilerLog) {
		JsonObject result = new JsonObject();
		try {
			logBuilder.append(Thread.currentThread().getName(), "about to post something to " + this.payBillUrl);
			HttpPost httpPost = new HttpPost(this.payBillUrl);
			httpPost.setHeader(Const.CONTENT_TYPE, Const.CONTENT_TYPE_APP_JSON);
			httpPost.setHeader(Const.AUTHORIZATION, this.token);
			
			StringEntity data_send = new StringEntity(data, StandardCharsets.UTF_8);
			httpPost.setHeader(Const.CONTENT_LENGTH,""+data_send.toString().length());
			httpPost.setEntity(data_send);

			String resData = StaticConfig.POOLING_HTTP_CLIENT.doPost(httpPost, profilerLog, logBuilder);
			result = procesResponse(resData);
		} catch (Exception ex) {
			result.addProperty(Const.CODE, HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			result.addProperty(Const.DATA, "Exception -> CloseableHttpClient.createSystem(httpPost)");
			LOGGER.error(ex.getMessage(), ex);
		}
		
		logBuilder.append(Const.REQ_URL, this.payBillUrl);
		logBuilder.append(Const.REQ_DATA, data);
		logBuilder.append(Const.RES_DATA, result);
		return result;
	}

	public JsonObject collectionMafc(String url, LogBuilder logBuilder, ProfilerLog profilerLog) {
		JsonObject result = new JsonObject();
		try {
			HttpGet httpGet = new HttpGet(url);
			httpGet.setHeader(Const.CONTENT_TYPE, Const.CONTENT_TYPE_APP_JSON);
			httpGet.setHeader(Const.AUTHORIZATION, this.token);
			httpGet.setHeader(Const.CONTENT_LENGTH,"0");
			
			String resData = StaticConfig.POOLING_HTTP_CLIENT.doGet(httpGet, profilerLog, logBuilder);
			result = procesResponse(resData);
		} catch (Exception ex) {
			result.addProperty(Const.CODE, HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			result.addProperty(Const.DATA, "Exception -> CloseableHttpClient.createSystem(httpGet)");
			logBuilder.append("collectionMafc_ex", ExceptionUtils.getStackTrace(ex));
		}
		logBuilder.append(Const.REQ_URL, url);
		logBuilder.append(Const.RES_DATA, result);
		return result;
	}

	public JsonObject cancelMafc(String url, LogBuilder logBuilder, ProfilerLog profilerLog) {
		JsonObject result = new JsonObject();
		try {
			HttpPut HttpPut = new HttpPut(url);
			HttpPut.setHeader(Const.CONTENT_TYPE, Const.CONTENT_TYPE_APP_JSON);
			HttpPut.setHeader(Const.AUTHORIZATION, this.token);
			
			String resData = StaticConfig.POOLING_HTTP_CLIENT.doPut(HttpPut, profilerLog, logBuilder);
			result = procesResponse(resData);
		} catch (Exception ex) {
			result.addProperty(Const.CODE, HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			result.addProperty(Const.DATA, "Exception -> CloseableHttpClient.createSystem(httpGet)");
			logBuilder.append("collectionMafc_ex", ExceptionUtils.getStackTrace(ex));
		}
		logBuilder.append(Const.REQ_URL, url);
		logBuilder.append(Const.RES_DATA, result);
		return result;
	}
	
	public JsonObject procesResponse(String resData) {
		JsonObject result = new JsonObject();
		if (!StringUtil.isEmpty(resData)) {
			result.addProperty(Const.CODE, "200");
			result.addProperty(Const.DATA, resData);
		} else {
			result.addProperty(Const.CODE, HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			result.addProperty(Const.DATA, "Exception -> httpclient.execute(httpPost)");
		}
		
		return result;
	}

	public String buildGetUrl(String[] params) {
		return new MessageFormat(this.getInfoUrl).format(params);
	}

	public String buildPutUrl(String[] params) {
		return new MessageFormat(this.cancelBillUrl).format(params);
	}
}
