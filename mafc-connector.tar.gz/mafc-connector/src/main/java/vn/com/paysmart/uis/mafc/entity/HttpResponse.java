package vn.com.paysmart.uis.mafc.entity;

import com.google.gson.JsonObject;
import java.util.Base64;
import vn.com.paysmart.common.uis.utils.CryptoUtil;

/**
 * @author tainguyen
 */
public class HttpResponse {

    private String code;

    private String data;

    private String message;

    private String secretKey;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = Base64.getEncoder().encodeToString(data.getBytes());
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getSecretKey() {
        return secretKey;
    }

    public void setSecretKey(String secretKey) {
        this.secretKey = secretKey;
    }

    public String buildStrResponse() {
        JsonObject response = new JsonObject();
        response.addProperty("code", this.code);
        response.addProperty("data", this.data);
        response.addProperty("message", this.message);
        response.addProperty("signature", CryptoUtil.sha256(this.data + "|" + this.secretKey));
        return response.toString();
    }
}
