package vn.com.paysmart.uis.mafc.servlet;

import javax.servlet.http.HttpServletResponse;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import vn.com.paysmart.common.uis.log.LogBuilder;
import vn.com.paysmart.common.uis.profiler.ProfilerLog;
import vn.com.paysmart.uis.mafc.client.MafcClient;
import vn.com.paysmart.uis.mafc.entity.HttpResponse;
import vn.com.paysmart.uis.mafc.utils.Const;
import vn.com.paysmart.uis.mafc.utils.ResponseCode;

public class CancelBillServlet extends BaseServlet{
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = LogManager.getLogger(CancelBillServlet.class);
	
	@Override
	HttpResponse pMain(JsonObject reqData, LogBuilder logBuilder, ProfilerLog profilerLog) {
		HttpResponse response = new HttpResponse();
        response.setCode(ResponseCode.FAILED.name());
        /*
         * verify Request param
         */
        if (reqData.get(Const.TRANS_ID) == null || StringUtils.isBlank(reqData.get(Const.TRANS_ID).getAsString())) {
            response.setMessage("connector - missing " + Const.TRANS_ID);
            return response;
        }
        MafcClient mafcClient = new MafcClient();
        String url = mafcClient.buildPutUrl(new String[]{reqData.get(Const.TRANS_ID).getAsString()});
        LOGGER.info("about to post something to " + url);
		logBuilder.append("about to post something to", url);
		
        JsonObject partnerData = mafcClient.cancelMafc(url, logBuilder, profilerLog);
        if (partnerData.get(Const.CODE).getAsInt() != HttpServletResponse.SC_OK) {
            response.setMessage(partnerData.get(Const.DATA).getAsString());
            return response;
        }
        try {
            JsonObject joData = new JsonParser().parse(partnerData.get(Const.DATA).getAsString()).getAsJsonObject();
            response.setMessage(Const.ERRROS);
            if (joData.get(Const.SUCCESS).getAsBoolean()) {
            	response.setCode(ResponseCode.SUCCESS.name());
            	response.setMessage(Const.SUCCESS);
            }
            JsonObject result = new JsonObject();
            result.add(Const.RESULT, joData.get(Const.RESULT));
            response.setData(result.toString());
            return response;
        } catch (Exception e) {
            response.setMessage("Can't read the response body");
            logBuilder.append("CollectionServlet_ex", ExceptionUtils.getStackTrace(e));
            return response;
        }
	}
}