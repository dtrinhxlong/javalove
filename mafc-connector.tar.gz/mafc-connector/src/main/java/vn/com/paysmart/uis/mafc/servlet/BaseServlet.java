package vn.com.paysmart.uis.mafc.servlet;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import vn.com.paysmart.common.uis.common.Config;
import vn.com.paysmart.common.uis.log.DefaultLogBuilder;
import vn.com.paysmart.common.uis.log.LogBuilder;
import vn.com.paysmart.common.uis.profiler.ProfilerLog;
import vn.com.paysmart.common.uis.utils.DateTimeUtil;
import vn.com.paysmart.logging.JsonLogBuilder;
import vn.com.paysmart.logging.LogMessage;
import vn.com.paysmart.uis.mafc.entity.HttpRequest;
import vn.com.paysmart.uis.mafc.entity.HttpResponse;
import vn.com.paysmart.uis.mafc.utils.Const;
import vn.com.paysmart.uis.mafc.utils.Log;
import vn.com.paysmart.uis.mafc.utils.ResponseCode;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Base64;

/**
 * @author tainguyen
 */
public abstract class BaseServlet extends HttpServlet {

    private static final long serialVersionUID = 2407196437911574927L;

    private static final Logger LOGGER = LogManager.getLogger(BaseServlet.class);

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // this.out("Success", resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setCharacterEncoding("UTF-8");
        resp.addHeader(Const.CONTENT_TYPE, "application/json;charset=UTF-8");
        resp.addHeader(Const.X_CALLER, req.getHeader(Const.X_CALLER));
        resp.addHeader(Const.X_REQUEST_ID, req.getHeader(Const.X_REQUEST_ID));
        /*
         * init Log
         */
        JsonLogBuilder jsonLogBuilder = new JsonLogBuilder();
        ProfilerLog profilerLog = new ProfilerLog(true);
        LogBuilder logBuilder = new DefaultLogBuilder();
        initLogBuilder(req, logBuilder);
        /*
         * process Call Partner
         */
        HttpResponse response = process(req, jsonLogBuilder, logBuilder, profilerLog);
        /*
         * Response data to client
         */
        logBuilder.append("PROFILER_LOG", profilerLog.dumpScribeLog());
        out(response.buildStrResponse(),response.getCode(), resp, logBuilder, jsonLogBuilder);
    }

    private HttpResponse process(HttpServletRequest req, JsonLogBuilder jsonLogBuilder, LogBuilder logBuilder, ProfilerLog profilerLog) {
        try {
        	profilerLog.doStartLog("wholerequest");
            HttpRequest request = parseRequest(req);
            logBuilder.append(Const.REQUEST_ID, request.getRequestId());
            logBuilder.append(Const.CALLER, request.getCaller());
            String callerApiKey = Config.getParam(Const.SERVICE, request.getCaller());
            intJsonLogBuilder(jsonLogBuilder, request);

            /*
             * validate Header Request data
             */
            if (!validateHeader(request, logBuilder)) {
                HttpResponse response = new HttpResponse();
                response.setSecretKey(callerApiKey);
                response.setCode(ResponseCode.FAILED.name());
                response.setMessage("connector - invalid header");
                return response;
            }

            JsonParser parser = new JsonParser();
            JsonObject reqBody = parser.parse(request.getData()).getAsJsonObject();
            String stringData = new String(Base64.getDecoder().decode(reqBody.get(Const.DATA).getAsString()));
            JsonObject reqData = parser.parse(stringData).getAsJsonObject();
            logBuilder.append(Const.DATA + "_received", reqData);
            /*
             * add Header
             */
            reqData.addProperty(Const.REQUEST_TIME, DateTimeUtil.getCurrentDateTimeAsString(DateTimeUtil.DEFAULT_DATE_TIME_FORMAT));
            reqData.addProperty(Const.REQUEST_ID, request.getRequestId());
            reqData.addProperty(Const.CALLER, request.getCaller());
            /*
             * verify Request data
             */
            if (reqData.get(Const.WALLET_ID) == null
                    || StringUtils.isBlank(reqData.get(Const.WALLET_ID).toString())
                    || reqData.get(Const.PHONE_NO) == null
                    || StringUtils.isBlank(reqData.get(Const.PHONE_NO).toString())) {
                HttpResponse response = new HttpResponse();
                response.setSecretKey(callerApiKey);
                response.setCode(ResponseCode.FAILED.name());
                response.setMessage("connector - missing walletId/phone");
                return response;
            }
            /*
             * call main process
             */
            HttpResponse response = pMain(reqData, logBuilder, profilerLog);
            response.setSecretKey(callerApiKey);
            return response;
        } catch (Exception e) {
            HttpResponse response = new HttpResponse();
            response.setCode(ResponseCode.FAILED.name());
            response.setMessage("connector - error when processing");
            logBuilder.append("BaseServlet_process_ex", ExceptionUtils.getStackTrace(e));
            return response;
        } finally {
        	profilerLog.doEndLog("wholerequest");
		}
    }

    private HttpRequest parseRequest(HttpServletRequest req) {
        HttpRequest httpRequest = new HttpRequest();
        String caller = req.getHeader(Const.X_CALLER);
        String requestId = req.getHeader(Const.X_REQUEST_ID);
        //String apiKey = req.getHeader(Const.X_API_KEY);
        String data = null;
        try {
            data = IOUtils.toString(req.getReader());
        } catch (IOException ex) {
        }
        String[] a = req.getServletPath().split("/");
        String version = a[1];
        String apiName = a[2] + "_" + a[3];
        httpRequest.setModule(System.getProperty("application.name"));
        httpRequest.setVersion(version);
        httpRequest.setApiName(apiName);
        httpRequest.setRequestId(requestId);
        httpRequest.setCaller(caller);
        //httpRequest.setApiKey(apiKey);
        httpRequest.setData(data);
        return httpRequest;
    }

    private void initLogBuilder(HttpServletRequest req, LogBuilder logBuilder) {
        logBuilder.append(Const.DATE,
                DateTimeUtil.getCurrentDateTimeAsString(DateTimeUtil.DEFAULT_DATE_TIME_FORMAT));
        logBuilder.append(Const.REMOTE_ADDRESS, req.getRemoteAddr());
        logBuilder.append(Const.LOCAL_ADDRESS, req.getLocalAddr());
    }

    private void intJsonLogBuilder(JsonLogBuilder jsonLogBuilder, HttpRequest httpRequest) {
        jsonLogBuilder
                .set(LogMessage.START_FIELD, System.currentTimeMillis())
                .set(LogMessage.REQUEST_ID_FIELD, httpRequest.getRequestId())
                .set(LogMessage.CALLER_CODE_FIELD, httpRequest.getCaller())
                .set(LogMessage.OPERATION_FIELD, httpRequest.getApiName())
                .set(LogMessage.OPERATION_VERSION_FIELD, httpRequest.getVersion())
                .set(LogMessage.MODULE_FIELD, httpRequest.getModule());
    }

    private boolean validateHeader(HttpRequest httpRequest, LogBuilder logBuilder) {
        String callerApiKey = Config.getParam(Const.SERVICE, httpRequest.getCaller());
        if (StringUtils.isBlank(callerApiKey)
                || StringUtils.isBlank(httpRequest.getRequestId())) {
            logBuilder.append("[PROCESS] validateHeader", "ERROR");
            return false;
        }
        return true;
    }

    private void out(String response ,String respCode, HttpServletResponse resp, LogBuilder logBuilder, JsonLogBuilder jsonLogBuilder) {
        PrintWriter out = null;
        try {
            out = resp.getWriter();
            out.print(response);
            logBuilder.append("[PROCESS] " + PrintWriter.class.getSimpleName(), "DONE");
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            logBuilder.append("[PROCESS] " + PrintWriter.class.getSimpleName(), "Exception :: " + ExceptionUtils.getStackTrace(e));
        } finally {
            /*
             * Write Log
             */
            Log.logWriter(jsonLogBuilder, response,respCode,  logBuilder);
            if (out != null) {
                out.close();
            }
        }
    }

    abstract HttpResponse pMain(JsonObject rd, LogBuilder logBuilder, ProfilerLog profilerLog);

}
