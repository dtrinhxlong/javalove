package vn.com.paysmart.uis.mafc.utils;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import vn.com.paysmart.common.queue.QueueConfig;
import vn.com.paysmart.common.queue.RabbitMQConfig;
import vn.com.paysmart.common.queue.producer.QueueProducer;
import vn.com.paysmart.common.uis.common.Config;
import vn.com.paysmart.common.uis.log.LogBuilder;

public class Rabbitmq {

    private static final Logger LOGGER = LogManager.getLogger(Rabbitmq.class);

    private static final String RB_RECON = "recon-rabbitmq";

    private static String queueNameRecon;

    static {
        try {
            /*
             * Init RECON QUEUE
             */
            queueNameRecon = Config.getParam(RB_RECON, Const.QUEUE_NAME);
            RabbitMQConfig rbMQConfig1 = new RabbitMQConfig(
                    Config.getParam(RB_RECON, Const.HOST),
                    Config.getIntParam(RB_RECON, Const.PORT),
                    Config.getParam(RB_RECON, Const.USERNAME),
                    Config.getParam(RB_RECON, Const.PASSWORD),
                    "/",
                    Config.getIntParam(RB_RECON, Const.THREAD_POOL_SIZE),
                    false,
                    Config.getIntParam(RB_RECON, Const.PREFETCH_SIZE));
            QueueConfig.initConfig(RB_RECON, rbMQConfig1);
        } catch (Exception e) {
            LOGGER.info("############### INTI RABBITMQ ################");
            LOGGER.info("############ EXCEPTION MESSAGE ###############");
            LOGGER.error(e.getMessage(), e);
        }
    }

    public static void sendMessage(String data, LogBuilder logBuilder) {
        boolean result = false;
        try {
            QueueProducer producer = new QueueProducer(RB_RECON, queueNameRecon);
            producer.sendMessage(data);
            result = true;
        } catch (Exception e) {
            LOGGER.info("############### SEND TO QUEUE ################");
            LOGGER.info("#################### FAIL ###################");
            logBuilder.append("Rabbitmq_sendMessage_ex", ExceptionUtils.getMessage(e));
        }
        logBuilder.append("sendMessage", queueNameRecon + ", " + data + ", " + result);
    }
}
