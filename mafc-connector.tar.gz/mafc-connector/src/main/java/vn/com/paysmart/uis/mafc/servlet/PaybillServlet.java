package vn.com.paysmart.uis.mafc.servlet;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.Logger;
import vn.com.paysmart.common.uis.common.Config;
import vn.com.paysmart.common.uis.common.LogUtil;
import vn.com.paysmart.common.uis.log.LogBuilder;
import vn.com.paysmart.common.uis.profiler.ProfilerLog;
import vn.com.paysmart.uis.mafc.client.MafcClient;
import vn.com.paysmart.uis.mafc.entity.HttpResponse;
import vn.com.paysmart.uis.mafc.utils.Const;
import vn.com.paysmart.uis.mafc.utils.Rabbitmq;
import vn.com.paysmart.uis.mafc.utils.ResponseCode;

public class PaybillServlet extends BaseServlet {

    private static final long serialVersionUID = -1865613067226417795L;

    private static final Logger LOGGER = LogUtil.getLogger(PaybillServlet.class.getSimpleName());

    @Override
    HttpResponse pMain(JsonObject reqData, LogBuilder logBuilder, ProfilerLog profilerLog) {
        HttpResponse response = process(reqData, logBuilder, profilerLog);
        return response;
    }

    private HttpResponse process(JsonObject reqData, LogBuilder logBuilder, ProfilerLog profilerLog) {
        HttpResponse response = new HttpResponse();
        try {
            JsonObject partnerRequest = buildRequest(reqData, logBuilder);
            if (partnerRequest == null) {
                response.setMessage("connector - invalid parameter");
                response.setCode(ResponseCode.FAILED.name());
                return response;
            }
            MafcClient mafcClient = new MafcClient();
            JsonObject partnerResponse = mafcClient.payBillMafc(partnerRequest.toString(), logBuilder, profilerLog);
            int partnerCode = partnerResponse.get(Const.CODE).getAsInt();
            /*
             * SUCCESS
             */
            if (partnerCode == HttpServletResponse.SC_OK || partnerCode == HttpServletResponse.SC_CREATED) {
                return processOK(partnerResponse, logBuilder, response);
            }
            /*
             * PENDING
             */
            if (partnerCode == HttpServletResponse.SC_BAD_GATEWAY
                    || partnerCode == HttpServletResponse.SC_INTERNAL_SERVER_ERROR
                    || partnerCode == HttpServletResponse.SC_GATEWAY_TIMEOUT) {
                response.setMessage(partnerResponse.get(Const.DATA).getAsString());
                response.setCode(ResponseCode.TIMEOUT.name());
                return response;
            }
            /*
             * FAILED
             */
            LOGGER.info("process ERROR.");
            response.setCode(ResponseCode.FAILED.name());
            response.setMessage(partnerResponse.get(Const.DATA).getAsString());
            return response;

        } catch (Exception e) {
            response.setMessage("error");
            response.setCode(ResponseCode.PENDING.name());
            logBuilder.append("PaybillServlet_process_ex", ExceptionUtils.getStackTrace(e));
            return response;
        } finally {
            String buildMessage = buildMessage(reqData, response, logBuilder);
            logBuilder.append("data_recon_message", buildMessage);
            if (StringUtils.isNotBlank(buildMessage)) {
                Rabbitmq.sendMessage(buildMessage, logBuilder);
            }
        }
    }

    private HttpResponse processOK(JsonObject partnerResponse, LogBuilder logBuilder, HttpResponse response) {
        /*
	         * 1 - “success” = false                             |   Error with the detail of error from “errors”
	         * 2 - “success” = true & “result”.”v result” = “1”  |   Inserted Successfully
	         * 3 - “success” = true & “result”.”v_result” = “0”  |   Invalid Agreementid / Duplicate TransactionId
         */
        try {
            JsonObject joData = new JsonParser().parse(partnerResponse.get(Const.DATA).getAsString()).getAsJsonObject();
            JsonObject result = joData.get(Const.RESULT).getAsJsonObject();
            JsonObject resultData = new JsonObject();
            resultData.add(Const.RESULT, joData.get(Const.RESULT));
            response.setData(resultData.toString());

            if (joData.get(Const.SUCCESS).getAsBoolean() && "1".equals(result.get("v_result").getAsString())) {
                response.setCode(ResponseCode.SUCCESS.name());
                response.setMessage(result.get("v_message").getAsString());
                return response;
            }
            response.setCode(ResponseCode.FAILED.name());
            if (!joData.get(Const.ERRROS).isJsonNull()) {
                response.setMessage(joData.get(Const.ERRROS).toString());
            } else {
                response.setMessage(result.get("v_message").getAsString());
            }
            LOGGER.info("resp_ " + response.toString());
            return response;
        } catch (Exception e) {
            response.setMessage("Can't read the response body");
            response.setCode(ResponseCode.PENDING.name());
            logBuilder.append("PaybillServlet_process_ex1", ExceptionUtils.getStackTrace(e));
            return response;
        }
    }

    private String buildMessage(JsonObject reqData, HttpResponse response, LogBuilder logBuilder) {
        SimpleDateFormat DF = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        String transTime;
        try {
            long reqTransTime = reqData.get(Const.TRANS_TIME).getAsLong();
            if (reqTransTime > 0L) {
                transTime = DF.format(new Date(reqTransTime));
            } else {
                transTime = DF.format(new Date());
            }
        } catch (Exception e) {
            transTime = DF.format(new Date());
        }

        try {
            JsonObject joData = new JsonObject();
            joData.addProperty(Const.ACC_NO, reqData.get(Const.ACC_NO).getAsString());
            joData.addProperty(Const.CODE, (response.getCode().equals(ResponseCode.SUCCESS.name())) ? 200 : 1000);
            joData.addProperty(Const.OVERDUEAMOUNT, reqData.get(Const.COLLECTION_AMOUNT).getAsString());
            joData.addProperty(Const.CUSTOMER_NAME, reqData.get(Const.CUSTOMER_NAME).getAsString());
            joData.addProperty(Const.DUEDATE, reqData.get(Const.EXPIREDATE).getAsString());
            joData.addProperty(Const.MIN_AMOUNT, reqData.get(Const.MIN_AMOUNT).getAsString());
            joData.addProperty(Const.PHONE_NO, reqData.get(Const.PHONE_NO).getAsString());
            joData.addProperty(Const.REFNO, "");
            joData.addProperty(Const.REQUEST_ID, reqData.get(Const.REQUEST_ID).getAsString());
            joData.addProperty(Const.REQUEST_TIME, reqData.get(Const.REQUEST_TIME).getAsString());
            joData.addProperty(Const.STATUS, response.getCode());
            joData.addProperty(Const.TRANS_AMOUNT, reqData.get(Const.TRANS_AMOUNT).getAsString());
            joData.addProperty(Const.TRANS_ID, reqData.get(Const.TRANS_ID).getAsString());
            joData.addProperty(Const.WALLET_ID, reqData.get(Const.WALLET_ID).getAsString());
            joData.addProperty(Const.TRANS_TIME, transTime);
            joData.addProperty(Const.PROVIDER, "MAFC");
            joData.addProperty(Const.RRN, reqData.get(Const.RRN).getAsString());

            JsonObject extraData = new JsonObject();
            extraData.addProperty("from", reqData.get(Const.CALLER).getAsString());
            extraData.addProperty("message", response.getMessage());
            joData.add(Const.EXTRA_DATA, extraData);

            JsonObject jo = new JsonObject();
            jo.addProperty(Const.CALLER, reqData.get(Const.CALLER).getAsString());
            jo.addProperty("signature", "");
            jo.add(Const.DATA, joData);
            return jo.toString();
        } catch (Exception e) {
            LOGGER.info("buildMessage_ex_ " + ExceptionUtils.getStackTrace(e));
            logBuilder.append("buildMessage_ex", ExceptionUtils.getStackTrace(e));
            return null;
        }
    }

    private JsonObject buildRequest(JsonObject rd, LogBuilder logBuilder) {
        /*
         * verify Request param
         */
        try {
            logBuilder.append(Const.REQUEST_ID, rd.get(Const.REQUEST_ID).getAsString());
            logBuilder.append(Const.PHONE_NO, rd.get(Const.PHONE_NO).getAsString());
            logBuilder.append(Const.WALLET_ID, rd.get(Const.WALLET_ID).getAsString());
            logBuilder.append(Const.ACC_NO, rd.get(Const.ACC_NO).getAsString());
            logBuilder.append(Const.TRANS_AMOUNT, rd.get(Const.TRANS_AMOUNT).getAsString());
            logBuilder.append(Const.TRANS_ID, rd.get(Const.TRANS_ID).getAsString());

            if (StringUtils.isBlank(rd.get(Const.ACC_NO).getAsString())
                    || Double.parseDouble(rd.get(Const.TRANS_AMOUNT).getAsString()) < 1
                    || StringUtils.isBlank(rd.get(Const.TRANS_ID).getAsString())) {
                return null;
            }
            JsonObject result = new JsonObject();
            result.addProperty(Const.AGREE_ID, rd.get(Const.ACC_NO).getAsString());
            result.addProperty(Const.AMOUNT, Double.parseDouble(rd.get(Const.TRANS_AMOUNT).getAsString()));
            result.addProperty(Const.TRANSACTION_ID, rd.get(Const.TRANS_ID).getAsString());
            result.addProperty(Const.COLLECTOR, Config.getParam(Const.MAFC_CONFIG, Const.COLLECTOR));
            return result;
        } catch (Exception e) {
            logBuilder.append("buildRequest_ex", ExceptionUtils.getStackTrace(e));
            return null;
        }
    }
}
