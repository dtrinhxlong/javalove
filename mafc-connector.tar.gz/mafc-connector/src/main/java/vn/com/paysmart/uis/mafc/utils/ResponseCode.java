package vn.com.paysmart.uis.mafc.utils;

public enum ResponseCode {
    SUCCESS,
    FAILED,
    PENDING,
    TIMEOUT
}
