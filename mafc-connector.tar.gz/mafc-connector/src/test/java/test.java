import com.google.gson.JsonObject;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import java.nio.charset.StandardCharsets;

public class test {

    private static String caller = "MAFCService";

    private static String apiKey = "a";

    public static void main(String[] args) {
    	getInfo("88", "012182418742");
        // paybill("88", "012182418742");
    }

    private static void getInfo(String walletId, String phoneNo) {

//        String url = "https://dev-mafcc.paysmart.com.vn/v1.0/mafc/collectionmafc";
        String url = "http://localhost:96/v1.0/mafc/collectionmafc";
        String reqId = "" + System.nanoTime();
        JsonObject joReq = new JsonObject();
        joReq.addProperty("walletId", walletId);
        joReq.addProperty("phoneNo", phoneNo);
        joReq.addProperty("agnId", "1002447");
        httpPost(reqId, url, joReq.toString());
        System.out.println("---------");
    }

    private static void paybill(String walletId, String phoneNo) {
        String url = "http://127.0.0.1:100/v1.0/mafc/paybillmafc";
        String reqId = "" + System.nanoTime();
        JsonObject joReq = new JsonObject();
        joReq.addProperty("walletId", walletId);
        joReq.addProperty("phoneNo", phoneNo);
        joReq.addProperty("accNo", "762473004973");
        joReq.addProperty("transAmount", 50000);
        joReq.addProperty("transId", "123456789");
        httpPost(reqId, url, joReq.toString());
        System.out.println("---------");
    }


    private static void httpPost(String reqId, String url, String data) {
        System.out.println("req:");
        System.out.println("url:" + url);
        System.out.println("data:" + data);
        try (CloseableHttpClient httpclient = HttpClients.createDefault()) {
            HttpPost httpPost = new HttpPost(url);
            httpPost.setHeader("X-Request-ID", reqId);
            httpPost.setHeader("X-Caller", caller);
            httpPost.setHeader("X-API-Key", apiKey);
            httpPost.setHeader("Content-Type", "application/json;charset=UTF-8");
            httpPost.setEntity(new StringEntity(data, StandardCharsets.UTF_8));
            try (CloseableHttpResponse response = httpclient.execute(httpPost)) {
                int resCode = response.getStatusLine().getStatusCode();
                String resData = response.getEntity() != null
                        ? EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8) : null;
                System.out.println("resp:");
                System.out.println("" + resCode);
                System.out.println("" + resData);
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        } catch (Exception ex) {
            ex.printStackTrace(System.out);
        }
    }

}
