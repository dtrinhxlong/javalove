# **MAFC Connector Service**
---

## **Authors**
- [tuan.ho](mailto:tuan.ho@paysmart.com.vn)



#### *Database*
Run the database script if any
